/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Slot;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.AvaliabilityEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SlotSessionTest {
    
    public SlotSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createSlot method, of class SlotSession.
     */
    @Test
    public void testACreateSlot()  {
        try {
            System.out.println("createSlot");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");                        
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,8);
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            Date startTime = cal.getTime();
            
            cal.set(Calendar.HOUR_OF_DAY,9);
            Date endTime = cal.getTime();
            
            Slot slot = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
            
            Slot expResult = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);
            
            Slot result = instance.createSlot(slot);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testACreateSlot() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveSlotById method, of class SlotSession.
     */
    @Test
    public void testBRetrieveSlotById()  {
        try {
            System.out.println("retrieveSlotById");
            Long sId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");                        
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,8);
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            Date startTime = cal.getTime();
            
            cal.set(Calendar.HOUR_OF_DAY,9);
            Date endTime = cal.getTime();
            
            Slot expResult = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);
                        
            Slot result = instance.retrieveSlotById(sId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
            
        } catch (Exception ex) {
            fail("testBRetrieveSlotById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveSlotByAttributes method, of class SlotSession.
     */
    //problematic
    @Test
    public void testCRetrieveSlotByAttributes()  {
        try {
            System.out.println("retrieveSlotByAttributes");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");                        

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,8);
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            Date startTime = cal.getTime();
            
            cal.set(Calendar.HOUR_OF_DAY,9);
            Date endTime = cal.getTime();
            
            Slot slot = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);
            
            System.out.println("***** Slot "+ slot.getStartDate().toString() + " " + /* slot.getStartTime().toString() +*/ " *****");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
                        
            Slot expResult = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);
            Slot result = instance.retrieveSlotByAttributes(slot).get(0);
            result.setId(null);
            
            System.out.println("***** Slot 2 "+ result.getStartDate().toString() + " " +  /*result.getStartTime().toString() +*/ " *****");
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testCRetrieveSlotByAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllSlotForStaff method, of class SlotSession.
     */
    @Test
    public void testDRetrieveAllSlotForStaff()  {
        try {
            System.out.println("retrieveAllSlotForStaff");
                        
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");                        
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,8);
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            Date startTime = cal.getTime();
            
            cal.set(Calendar.HOUR_OF_DAY,9);
            Date endTime = cal.getTime();
            
            Slot expResult = new Slot(date, date,/* startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);

            Slot result = instance.retrieveAllSlotForStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testDRetrieveAllSlotForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateSlot method, of class SlotSession.
     */
    @Test
    public void testEUpdateSlot()  {
        try {
            System.out.println("updateSlot");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("13/12/2018");                        
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,8);
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            //Date startTime = cal.getTime();
            
            cal.set(Calendar.HOUR_OF_DAY,9);
            //Date endTime = cal.getTime();
            
            Slot slot = new Slot(date, date,/* startTime, endTime, */AvaliabilityEnum.AVAILABLE); 
            slot.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
            
            Slot expResult = new Slot(date, date, /*startTime, endTime,*/ AvaliabilityEnum.AVAILABLE);  
                        
            Slot result = instance.updateSlot(slot);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

            
        } catch (Exception ex) {
            fail("testEUpdateSlot() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteSlot method, of class SlotSession.
     */
    @Test
    public void testFDeleteSlot()  {
        try {
            System.out.println("deleteSlot");
            Long sId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            SlotSessionLocal instance = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
            instance.deleteSlot(sId);
            container.close();

        } catch (Exception ex) {
            fail("testFDeleteSlot() has failed. Error: " + ex.getMessage());
        }
    }
    
}
