/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Booking;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.BookingStatusEnum;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BookingSessionTest {
    
    public BookingSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createBooking method, of class BookingSession.
     */
    @Test
    public void testACreateBooking() {
        try 
        {
            System.out.println("createBooking");
            Booking booking = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);          
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            
            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
            
            Booking expResult = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);            
            
            Booking result = instance.createBooking(booking);
            result.setId(null);
            
            assertEquals(expResult, result);
            
            container.close();
        } 
        catch (Exception ex) 
        {
            fail("testACreateBooking() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveBookingById method, of class BookingSession.
     */
    @Test
    public void testBRetrieveBookingById(){
        
        try 
        {
            System.out.println("retrieveBookingById");
            Long bId = Long.valueOf("1");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
            
            Booking expResult = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);
            expResult.setId(null);
            
            Booking result = instance.retrieveBookingById(bId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } 
        catch (Exception ex) 
        {
             fail("testBRetrieveBookingById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllBookingForStaff method, of class BookingSession.
     */
    @Test
    public void testCRetrieveAllBookingForStaff(){
        try {
            System.out.println("retrieveAllBookingForStaff");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
            
            List<Booking> expResult = new ArrayList<Booking>();
            Booking booking = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);
            booking.setId(Long.valueOf("1"));
            expResult.add(booking);            
            
            List<Booking> result = instance.retrieveAllBookingForStaff();
            
            assertEquals(expResult, result);
            container.close();
        } 
        catch (Exception ex) 
        {
             fail("testCRetrieveAllBookingForStaff() has failed. Error: " + ex.getMessage());
        }
    }

//    /**
//     * Test of retrieveBookingsBySlotAttributes method, of class BookingSession.
//     */
//    @Test
//    public void testDRetrieveBookingsBySlotAttributes(){
//        try 
//        {
//            System.out.println("retrieveBookingsBySlotAttributes");            
//            
//            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//            Date date = sdf.parse("12/12/2018");                        
//            LocalTime time = LocalTime.parse("08:00");
//            
//            Slot slot = new Slot(date, date, time, time.plusHours(Long.valueOf("1")), AvaliabilityEnum.AVAILABLE);
//                        
//            
//            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
//            SlotSessionLocal instance2 = (SlotSessionLocal)container.getContext().lookup("java:global/classes/SlotSession");
//            
//            Booking booking = instance.retrieveBookingById(Long.valueOf(1));
//            Slot persistSlot = instance2.createSlot(slot);
//            booking.getSlots().add(persistSlot);
//            instance.updateBookingAttributes(booking);
//            
//                        
//            Booking expResult = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);
//            
//            Booking result = instance.retrieveBookingsBySlotAttributes(slot).get(0);
//            result.setId(null);
//            
//            assertEquals(expResult, result);
//            
//            result.setSlots(null);
//            persistSlot.setBooking(null);
//            
//            instance.updateBookingAttributes(booking);
//            instance2.updateSlot(slot);
//            
//            instance.deleteBooking(booking.getId());
//            instance2.deleteSlot(slot.getId());
//            
//            container.close();
//        } 
//        catch (Exception ex) 
//        {
//             fail("testDRetrieveBookingsBySlotAttributes() has failed. Error: " + ex.getMessage());
//        }
//    }

    /**
     * Test of retrieveBookingByQrCode method, of class BookingSession.
     */
    @Test
    public void testERetrieveBookingByQrCode() {
        try {
            System.out.println("retrieveBookingByQrCode");
            String qrCode = "TestCode";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
            
            Booking expResult = new Booking("TestCode", BookingStatusEnum.RESERVED, EntityStatusEnum.ACTIVATED);
            Booking result = instance.retrieveBookingByQrCode(qrCode);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             fail("testERetrieveBookingByQrCode() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateBookingAttributes method, of class BookingSession.
     */
    @Test
    public void testFUpdateBookingAttributes(){
        try {
            System.out.println("updateBookingAttributes");
            
            Booking booking =  new Booking("newTestCode", BookingStatusEnum.CHECKED_IN, EntityStatusEnum.ACTIVATED);
            booking.setId(Long.valueOf(1));
                        
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
            
            Booking expResult =  new Booking("newTestCode", BookingStatusEnum.CHECKED_IN, EntityStatusEnum.ACTIVATED);
            
            Booking result = instance.updateBookingAttributes(booking);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch(Exception ex) {
             fail("testFUpdateBookingAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteBooking method, of class BookingSession.
     */
//    @Test
//    public void testGDeleteBooking() {
//        try {
//            System.out.println("deleteBooking");
//            Long bId = Long.valueOf(1);
//            
//            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//            BookingSessionLocal instance = (BookingSessionLocal)container.getContext().lookup("java:global/classes/BookingSession");
//            
//            instance.deleteBooking(bId);
//            container.close();
//        } catch (Exception ex) {
//            fail("testGDeleteBooking() has failed. Error: " + ex.getMessage());
//        }
//    }
    
}
