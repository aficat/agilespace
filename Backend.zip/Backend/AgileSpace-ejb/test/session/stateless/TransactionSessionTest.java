/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.AgileSpaceTransaction;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.EntityStatusEnum;
import util.enumeration.TransactionTypeEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TransactionSessionTest {
    
    public TransactionSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createTransaction method, of class TransactionSession.
     */
    @Test
    public void testACreateTransaction()  {
        try {
            System.out.println("createTransaction");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");    
            
            AgileSpaceTransaction transaction = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            
            AgileSpaceTransaction expResult = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            AgileSpaceTransaction result = instance.createTransaction(transaction);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testACreateTransaction() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveTransactionById method, of class TransactionSession.
     */
    @Test
    public void testBRetrieveTransactionById()  {
        try {
            System.out.println("retrieveTransactionById");
            Long tId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");    

            AgileSpaceTransaction expResult = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            
            AgileSpaceTransaction result = instance.retrieveTransactionById(tId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testBRetrieveTransactionById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveByAttribute method, of class TransactionSession.
     */
    @Test
    public void testCRetrieveByAttribute()  {
        try {
            System.out.println("retrieveByAttribute");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");    
            
            AgileSpaceTransaction transaction = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            
            AgileSpaceTransaction expResult = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            AgileSpaceTransaction result = instance.retrieveByAttribute(transaction).get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testCRetrieveByAttribute() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllTransactionForStaff method, of class TransactionSession.
     */
    @Test
    public void testDRetrieveAllTransactionForStaff()  {
        try {
            System.out.println("retrieveAllTransactionForStaff");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("12/12/2018");    
            
            AgileSpaceTransaction expResult = new AgileSpaceTransaction(date, 1.20, TransactionTypeEnum.CREDIT, EntityStatusEnum.ACTIVATED);
            AgileSpaceTransaction result = instance.retrieveAllTransactionForStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testDRetrieveAllTransactionForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateTransaction method, of class TransactionSession.
     */
    @Test
    public void testEUpdateTransaction()  {
        try {
            System.out.println("updateTransaction");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse("13/12/2018");
            
            AgileSpaceTransaction transaction = new AgileSpaceTransaction(date, 2.20, TransactionTypeEnum.DEBIT, EntityStatusEnum.ACTIVATED);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            
            AgileSpaceTransaction expResult = new AgileSpaceTransaction(date, 2.20, TransactionTypeEnum.DEBIT, EntityStatusEnum.ACTIVATED);
            AgileSpaceTransaction result = instance.updateTransaction(transaction);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testEUpdateTransaction() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteTransaction method, of class TransactionSession.
     */
    @Test
    public void testFDeleteTransaction()  {
        try {
            System.out.println("deleteTransaction");
            Long tId = Long.valueOf(1);
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            TransactionSessionLocal instance = (TransactionSessionLocal)container.getContext().lookup("java:global/classes/TransactionSession");
            instance.deleteTransaction(tId);
            container.close();

        } catch (Exception ex) {
            fail("testFDeleteTransaction() has failed. Error: " + ex.getMessage());
        }
    }
    
}
