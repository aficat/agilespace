/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Staff;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.StaffAccessRightEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class StaffSessionTest {
    
    public StaffSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createStaff method, of class StaffSession.
     */
    @Test
    public void testACreateStaff()  {
        try {
            System.out.println("createStaff");
            Staff staff = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            Staff result = instance.createStaff(staff);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testACreateStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveStaffById method, of class StaffSession.
     */
    @Test
    public void testBRetrieveStaffById()  {
        try {
            System.out.println("retrieveStaffById");
            Long sId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            Staff result = instance.retrieveStaffById(sId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testBRetrieveStaffById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveStaffByEmail method, of class StaffSession.
     */
    @Test
    public void testCRetrieveStaffByEmail()  {
        try {
            System.out.println("retrieveStaffByEmail");
            String email = "testEmail";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            Staff result = instance.retrieveStaffByEmail(email);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testCRetrieveStaffByEmail() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveStaffByDepartment method, of class StaffSession.
     */
    @Test
    public void testDRetrieveStaffByDepartment()  {
        try {
            System.out.println("retrieveStaffByDepartment");
            StaffAccessRightEnum staffAccessRightEnum = StaffAccessRightEnum.MANAGER;
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            Staff result = instance.retrieveStaffByDepartment(staffAccessRightEnum).get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testDRetrieveStaffByDepartment() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllStaff method, of class StaffSession.
     */
    @Test
    public void testERetrieveAllStaff()  {
        try {
            System.out.println("retrieveAllStaff");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("testEmail", "password", StaffAccessRightEnum.MANAGER);
            Staff result = instance.retrieveAllStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testERetrieveAllStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateStaff method, of class StaffSession.
     */
    @Test
    public void testFUpdateStaff()  {
        try {
            System.out.println("updateStaff");
            
            Staff staff = new Staff("newTestEmail", "newPassword", StaffAccessRightEnum.MANAGER);
            staff.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("newTestEmail", "newPassword", StaffAccessRightEnum.MANAGER);
            Staff result = instance.updateStaff(staff);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testFUpdateStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteStaff method, of class StaffSession.
     */
    @Test
    public void testHDeleteStaff()  {
        try {
            System.out.println("deleteStaff");
            Long sId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            instance.deleteStaff(sId);
            container.close();

        } catch (Exception ex) {
            fail("testHDeleteStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of login method, of class StaffSession.
     */
    @Test
    public void testGLogin()  {
        try {
            System.out.println("login");
            String email = "newTestEmail";
            String password = "newPassword";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            StaffSessionLocal instance = (StaffSessionLocal)container.getContext().lookup("java:global/classes/StaffSession");
            
            Staff expResult = new Staff("newTestEmail", "newPassword", StaffAccessRightEnum.MANAGER);
            Staff result = instance.login(email, password);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testGLogin() has failed. Error: " + ex.getMessage());
        }
    }
    
}
