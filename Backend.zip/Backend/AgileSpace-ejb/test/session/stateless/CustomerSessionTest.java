/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Customer;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CustomerSessionTest {
    
    public CustomerSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createCustomer method, of class CustomerSession.
     */
    @Test
    public void testACreateCustomer(){
        try {
            System.out.println("createCustomer");
            Customer customer = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            Customer result = instance.createCustomer(customer);
            result.setId(null);
            
            assertEquals(expResult, result);
            
        } catch (Exception ex) {
             System.out.println("testACreateCustomer has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveCustomerById method, of class CustomerSession.
     */
    @Test
    public void testBRetrieveCustomerById(){
        try {
            System.out.println("retrieveCustomerById");
            Long cId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            Customer result = instance.retrieveCustomerById(cId);
            result.setId(null);
            
            assertEquals(expResult, result);
            
            container.close();
        } catch (Exception ex) {
             System.out.println("testBRetrieveCustomerById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveCustomerByEmail method, of class CustomerSession.
     */
    @Test
    public void testCRetrieveCustomerByEmail(){
        try {
            System.out.println("retrieveCustomerByEmail");
            String email = "testEmail";
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            Customer expResult = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            Customer result = instance.retrieveCustomerByEmail(email);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
             System.out.println("testCRetrieveCustomerByEmail() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveCustomerByAttributes method, of class CustomerSession.
     */
    @Test
    public void testDRetrieveCustomerByAttributes(){
        try {
            System.out.println("retrieveCustomerByAttributes");
            Customer customer = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            Customer result = instance.retrieveCustomerByAttributes(customer).get(0);           
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
             System.out.println("testDRetrieveCustomerByAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllActiveCustomers method, of class CustomerSession.
     */
    @Test
    public void testERetrieveAllActiveCustomers() {
        try {
            System.out.println("retrieveAllActiveCustomers");
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("testEmail", "testPassword", "testFirstName", "testLastName", "testPhoneNumber");
            
            Customer result = instance.retrieveAllActiveCustomers().get(0);
            result.setId(null);
                       
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testERetrieveAllActiveCustomers() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllCustomersForStaff method, of class CustomerSession.
     */
    @Test
    public void testFRetrieveAllCustomersForStaff() {
        try {
            System.out.println("retrieveAllCustomersForStaff");
            
            Customer customer = new Customer("testEmail2", "testPassword2", "testFirstName2", "testLastName2", "testPhoneNumber2");
            customer.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            instance.createCustomer(customer);
            
            Integer expResult = 2;
            Integer result = instance.retrieveAllCustomersForStaff().size();
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
             System.out.println("testFRetrieveAllCustomersForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateCustomer method, of class CustomerSession.
     */
    @Test
    public void testGUpdateCustomer(){
        try {
            System.out.println("updateCustomer");
            Customer customer = new Customer("newTestEmail2", "newTestPassword2", "newTestFirstName2", "newTestLastName2", "newTestPhoneNumber2");
            customer.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            Customer expResult = new Customer("newTestEmail2", "newTestPassword2", "newTestFirstName2", "newTestLastName2", "newTestPhoneNumber2");
            
            Customer result = instance.updateCustomer(customer);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testGUpdateCustomer() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteCustomer method, of class CustomerSession.
     */
    @Test
    public void testKDeleteCustomer(){
        try {
            System.out.println("deleteCustomer");
            Long cId = Long.valueOf(1);
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            instance.deleteCustomer(cId);
            container.close();
        } catch (Exception ex) {
            System.out.println("testKDeleteCustomer() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of login method, of class CustomerSession.
     */
    @Test
    public void testHLogin() {
        try {
            System.out.println("login");
            String email = "newTestEmail2";
            String password = "newTestPassword2";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("newTestEmail2", "newTestPassword2", "newTestFirstName2", "newTestLastName2", "newTestPhoneNumber2");
            Customer result = instance.login(email, password);
            
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testHLogin() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of addPhotoUrlToCustomer method, of class CustomerSession.
     */
    @Test
    public void testIAddPhotoUrlToCustomer(){
        try {
            System.out.println("addPhotoUrlToCustomer");
            Long cId = Long.valueOf(1);
            String url = "testUrl";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            
            Customer expResult = new Customer("newTestEmail2", "newTestPassword2", "newTestFirstName2", "newTestLastName2", "newTestPhoneNumber2");
            expResult.getPhotoUrls().add(url);
            
            Customer result = instance.addPhotoUrlToCustomer(cId, url);
            
            assertEquals(expResult.getPhotoUrls().get(0), result.getPhotoUrls().get(0));
            container.close();
        } catch (Exception ex) {
             System.out.println("testIAddPhotoUrlToCustomer() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of removePhotoUrlToCustomer method, of class CustomerSession.
     */
    @Test
    public void testJRemovePhotoUrlToCustomer(){
        try {
            System.out.println("removePhotoUrlToCustomer");
            
            Long cId = Long.valueOf(1);
            String url = "testUrl";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            CustomerSessionLocal instance = (CustomerSessionLocal)container.getContext().lookup("java:global/classes/CustomerSession");
            Customer expResult = new Customer("newTestEmail2", "newTestPassword2", "newTestFirstName2", "newTestLastName2", "newTestPhoneNumber2");
            
            Customer result = instance.removePhotoUrlToCustomer(cId, url);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
             System.out.println("testJRemovePhotoUrlToCustomer() has failed. Error: " + ex.getMessage());
        }

    }
    
}
