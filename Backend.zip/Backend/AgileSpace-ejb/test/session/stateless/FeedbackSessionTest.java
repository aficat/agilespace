/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Feedback;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.embeddable.EJBContainer;
import javax.naming.NamingException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.FeedbackTypeEnum;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FeedbackSessionTest {
    
    public FeedbackSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createFeedback method, of class FeedbackSession.
     */
    @Test
    public void testACreateFeedback(){
        try {
            System.out.println("createFeedback");
            
            Calendar c = new GregorianCalendar();
            c.set(2018, 11, 1, 23, 0, 0);                       
            
            Feedback feedback = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            
            Feedback expResult = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            
            Feedback result = instance.createFeedback(feedback);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testACreateFeedback() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveFeedbackbyId method, of class FeedbackSession.
     */
    @Test
    public void testBRetrieveFeedbackbyId()  {
        try {
            System.out.println("retrieveFeedbackbyId");
                        
            Long fId = Long.valueOf(1);
            
            Calendar c = new GregorianCalendar();
            c.set(2018, 11, 1, 23, 0, 0);              
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            Feedback expResult = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            
            Feedback result = instance.retrieveFeedbackbyId(fId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } 
        catch (Exception ex) 
        {
             System.out.println("testBRetrieveFeedbackbyId() has failed. Error: " + ex.getMessage());
        }

    }

    /**
     * Test of retrieveFeedbackByAttributes method, of class FeedbackSession.
     */
    @Test
    public void testCRetrieveFeedbackByAttributes()  {
        try {
            System.out.println("retrieveFeedbackByAttributes");
            
            Calendar c = new GregorianCalendar();
            c.set(2018, 11, 1, 23, 0, 0);              
            
            Feedback feedback = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            Feedback expResult = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            
            Feedback result = instance.retrieveFeedbackByAttributes(feedback).get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testCRetrieveFeedbackByAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllFeedbackForStaff method, of class FeedbackSession.
     */
    @Test
    public void testDRetrieveAllFeedbackForStaff()  {
        try {
            System.out.println("retrieveAllFeedbackForStaff");
            
            Calendar c = new GregorianCalendar();
            c.set(2018, 11, 1, 23, 0, 0);  
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            Feedback expResult = new Feedback(5, FeedbackTypeEnum.LISTING, "testRemarks", c.getTime());
            Feedback result = instance.retrieveAllFeedbackForStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testDRetrieveAllFeedbackForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateFeedback method, of class FeedbackSession.
     */
    @Test
    public void testEUpdateFeedback()  {
        try {
            System.out.println("updateFeedback");
            
            Calendar c = new GregorianCalendar();
            c.set(2018, 11, 1, 23, 0, 0);  
                        
            Feedback feedback = new Feedback(5, FeedbackTypeEnum.CUSTOMER, "newTestRemarks", c.getTime());
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            Feedback expResult = new Feedback(5, FeedbackTypeEnum.CUSTOMER, "newTestRemarks", c.getTime());
            
            Feedback result = instance.updateFeedback(feedback);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             System.out.println("testEUpdateFeedback() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteFeedback method, of class FeedbackSession.
     */
    @Test
    public void testFDeleteFeedback()  {
        try {
            System.out.println("deleteFeedback");
            Long fId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            FeedbackSessionLocal instance = (FeedbackSessionLocal)container.getContext().lookup("java:global/classes/FeedbackSession");
            
            instance.deleteFeedback(fId);
            container.close();

        } catch (Exception ex) {
             System.out.println("testFDeleteFeedback() has failed. Error: " + ex.getMessage());
        }
    }
    
}
