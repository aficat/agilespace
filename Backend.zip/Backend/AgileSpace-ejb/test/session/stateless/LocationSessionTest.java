/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Location;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LocationSessionTest {
    
    public LocationSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createLocation method, of class LocationSession.
     */
    @Test
    public void testACreateLocation()  {
        try {
            System.out.println("createLocation");
            Location location = new Location("testAddress", "postalCode", 11.22, 11.33);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            
            Location expResult = new Location("testAddress", "postalCode", 11.22, 11.33);
            
            Location result = instance.createLocation(location);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testACreateLocation() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveLocationById method, of class LocationSession.
     */
    @Test
    public void testBRetrieveLocationById()  {
        try {
            System.out.println("retrieveLocationById");
            
            Long lId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            
            Location expResult = new Location("testAddress", "postalCode", 11.22, 11.33);
            Location result = instance.retrieveLocationById(lId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testBretrieveLocationById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveByAttributes method, of class LocationSession.
     */
    //problematic
    @Test
    public void testCRetrieveByAttributes()  {
        try {
            System.out.println("retrieveByAttributes");
            Location location = new Location("testAddress", "postalCode", 11.22, 11.33);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            
            Location expResult = new Location("testAddress", "postalCode", 11.22, 11.33);
            Location result = instance.retrieveByAttributes(location).get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testCRetrieveByAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllLocationForStaff method, of class LocationSession.
     */
    @Test
    public void testDRetrieveAllLocationForStaff()  {
        try {
            System.out.println("retrieveAllLocationForStaff");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            
            Location expResult = new Location("testAddress", "postalCode", 11.22, 11.33);
            Location result = instance.retrieveAllLocationForStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testDRetrieveAllLocationForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateLocation method, of class LocationSession.
     */
    @Test
    public void testEUpdateLocation()  {
        try {
            System.out.println("updateLocation");
            Location location = new Location("newTestAddress", "postalCode", 11.22, 11.33);
            location.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            
            Location expResult = new Location("newTestAddress", "postalCode", 11.22, 11.33);
            Location result = instance.updateLocation(location);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
            fail("testEUpdateLocation() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteLocation method, of class LocationSession.
     */
    @Test
    public void testFDeleteLocation()  {
        try {
            System.out.println("deleteLocation");
            Long lId = Long.valueOf(1);
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            LocationSessionLocal instance = (LocationSessionLocal)container.getContext().lookup("java:global/classes/LocationSession");
            instance.deleteLocation(lId);
            container.close();

        } catch (Exception ex) {
            fail("testFDeleteLocation() has failed. Error: " + ex.getMessage());
        }
    }
    
}
