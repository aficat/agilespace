/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.HostDoorSystem;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class HostDoorSystemSessionTest {
    
    public HostDoorSystemSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createHostDoorSystemAccount method, of class HostDoorSystemSession.
     */
    @Test
    public void testACreateHostDoorSystemAccount()  {
        try {
            System.out.println("createHostDoorSystemAccount");
            HostDoorSystem hostDoorSystem = new HostDoorSystem("hostDoorSystemEmail", "password", "masterQRCode");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult = new HostDoorSystem("hostDoorSystemEmail", "password", "masterQRCode");
            
            HostDoorSystem result = instance.createHostDoorSystemAccount(hostDoorSystem);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
                        
        } catch (Exception ex) {
              fail("testACreateHostDoorSystemAccount() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveHostDoorSystemAccountById method, of class HostDoorSystemSession.
     */
    @Test
    public void testBRetrieveHostDoorSystemAccountById()  {
        try {
            System.out.println("retrieveHostDoorSystemAccountById");
            Long hId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult = new HostDoorSystem("hostDoorSystemEmail", "password", "masterQRCode");
            
            HostDoorSystem result = instance.retrieveHostDoorSystemAccountById(hId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
             fail("testBRetrieveHostDoorSystemAccountById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveHostDoorSystemAccountByEmail method, of class HostDoorSystemSession.
     */
    @Test
    public void testCRetrieveHostDoorSystemAccountByEmail()  {
        try {
            System.out.println("retrieveHostDoorSystemAccountByEmail");
            String email = "hostDoorSystemEmail";
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult = new HostDoorSystem("hostDoorSystemEmail", "password", "masterQRCode");
            HostDoorSystem result = instance.retrieveHostDoorSystemAccountByEmail(email);
            result.setId(null);
            
            assertEquals(expResult, result);
            
            container.close();

        } catch (Exception ex) {
              fail("testCRetrieveHostDoorSystemAccountByEmail() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllHostDoorSystemAccount method, of class HostDoorSystemSession.
     */
    @Test
    public void testDRetrieveAllHostDoorSystemAccount()  {
        try {
            System.out.println("retrieveAllHostDoorSystemAccount");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult = new HostDoorSystem("hostDoorSystemEmail", "password", "masterQRCode");
            
            HostDoorSystem result = instance.retrieveAllHostDoorSystemAccount().get(0);            
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
        } catch (Exception ex) {
              fail("testDRetrieveAllHostDoorSystemAccount()  has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateHostDoorSystemAccount method, of class HostDoorSystemSession.
     */
    @Test
    public void testEUpdateHostDoorSystemAccount()  {
        try {
            System.out.println("updateHostDoorSystemAccount");
            HostDoorSystem hostDoorSystem = new HostDoorSystem("newHostDoorSystemEmail", "newPassword", "masterQRCode");
            hostDoorSystem.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult = new HostDoorSystem("newHostDoorSystemEmail", "newPassword", "masterQRCode");
            HostDoorSystem result = instance.updateHostDoorSystemAccount(hostDoorSystem);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
              fail("testEUpdateHostDoorSystemAccount() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteHostDoorSystemAccount method, of class HostDoorSystemSession.
     */
    @Test
    public void testGDeleteHostDoorSystemAccount()  {
        try {
            System.out.println("deleteHostDoorSystemAccount");
            Long hId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            instance.deleteHostDoorSystemAccount(hId);
            
            container.close();
        } catch (Exception ex) {
              fail("testGDeleteHostDoorSystemAccount() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of login method, of class HostDoorSystemSession.
     */
    @Test
    public void testFLogin()  {
        try {
            System.out.println("login");
            String email = "newHostDoorSystemEmail";
            String password = "newPassword";
           
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            HostDoorSystemSessionLocal instance = (HostDoorSystemSessionLocal)container.getContext().lookup("java:global/classes/HostDoorSystemSession");
            
            HostDoorSystem expResult =  new HostDoorSystem("newHostDoorSystemEmail", "newPassword", "masterQRCode");
            HostDoorSystem result = instance.login(email, password);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
              fail("testFLogin() has failed. Error: " + ex.getMessage());
        }
    }
    
}
