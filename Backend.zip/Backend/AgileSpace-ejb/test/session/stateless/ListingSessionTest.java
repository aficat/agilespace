/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Listing;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import util.enumeration.BuildingTypeEnum;

/**
 *
 * @author vincentyeo
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ListingSessionTest {
    
    public ListingSessionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createListing method, of class ListingSession.
     */
    @Test
    public void testACreateListing() {
        try {
            System.out.println("createListing");
            Listing listing = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            
            Listing expResult = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            Listing result = instance.createListing(listing);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testACreateListing() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveListingById method, of class ListingSession.
     */
    @Test
    public void testBRetrieveListingById() {
        try {
            System.out.println("retrieveListingById");
            Long lId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            
            Listing expResult = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            Listing result = instance.retrieveListingById(lId);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testBRetrieveListingById() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveListingByAttributes method, of class ListingSession.
     */
    @Test
    public void testCRetrieveListingByAttributes() {
        try {
            System.out.println("retrieveListingByAttributes");
            Listing listing = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            
            Listing expResult = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            Listing result = instance.retrieveListingByAttributes(listing).get(0);
            result.setId(null);

            assertEquals(expResult, result);
            container.close();
            
        } catch (Exception ex) {
            fail("testCRetrieveListingByAttributes() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of retrieveAllListingForStaff method, of class ListingSession.
     */
    @Test
    public void testDRetrieveAllListingForStaff() {
        try {
            System.out.println("retrieveAllListingForStaff");
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            
            Listing expResult = new Listing(BuildingTypeEnum.OFFICE, "testHeader", "testDescription", 1.00, null, "1", "1-32");
            Listing result = instance.retrieveAllListingForStaff().get(0);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();

        } catch (Exception ex) {
            fail("testDRetrieveAllListingForStaff() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of updateListing method, of class ListingSession.
     */
    @Test
    public void testEUpdateListing() {
        try {
            System.out.println("updateListing");
            
            Listing listing = new Listing(BuildingTypeEnum.OFFICE, "newTestHeader", "newTestDescription", 1.00, null, "2", "2-32");
            listing.setId(Long.valueOf(1));
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            
            Listing expResult = new Listing(BuildingTypeEnum.OFFICE, "newTestHeader", "newTestDescription", 1.00, null, "2", "2-32");
            Listing result = instance.updateListing(listing);
            result.setId(null);
            
            assertEquals(expResult, result);
            container.close();
            
        } catch (Exception ex) {
            fail("testEUpdateListing() has failed. Error: " + ex.getMessage());
        }
    }

    /**
     * Test of deleteListing method, of class ListingSession.
     */
    @Test
    public void testFDeleteListing() {
        try {
            System.out.println("deleteListing");
            Long lId = Long.valueOf(1);
            
            EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
            ListingSessionLocal instance = (ListingSessionLocal)container.getContext().lookup("java:global/classes/ListingSession");
            instance.deleteListing(lId);
            
            container.close();

        } catch (Exception ex) {
            fail("testFDeleteListing() has failed. Error: " + ex.getMessage());
        }
    }
    
}
