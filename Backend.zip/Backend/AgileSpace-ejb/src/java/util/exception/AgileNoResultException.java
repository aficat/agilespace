/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author vincentyeo
 */
public class AgileNoResultException extends Exception 
{

    /**
     * Creates a new instance of <code>NoResultException</code> without detail
     * message.
     */
    public AgileNoResultException() {
    }

    /**
     * Constructs an instance of <code>NoResultException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public AgileNoResultException(String msg) {
        super(msg);
    }
}
