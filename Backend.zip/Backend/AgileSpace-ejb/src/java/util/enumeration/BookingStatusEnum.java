/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.enumeration;

/**
 *
 * @author vincentyeo
 */
public enum BookingStatusEnum {
    RESERVED,   //Customer has paid and reserved the slot
    CHECKED_IN, //Customer has used the facility
    NOSHOW     //Customer has booking but did not come
}
