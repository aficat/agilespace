
package session.singleton;

import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Location;
import entity.Slot;
import entity.Staff;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import session.stateless.CustomerSessionLocal;
import session.stateless.HostDoorSystemSessionLocal;
import session.stateless.ListingSessionLocal;
import session.stateless.LocationSessionLocal;
import session.stateless.SlotSessionLocal;
import session.stateless.StaffSessionLocal;
import util.enumeration.AvaliabilityEnum;
import util.enumeration.BuildingTypeEnum;
import util.enumeration.StaffAccessRightEnum;


/**
 *
 * @author vincentyeo
 */
@Singleton
@LocalBean
@Startup
public class DataInitializationSession 
{    
    
    @EJB
    private StaffSessionLocal staffSessionLocal;
    @EJB
    private CustomerSessionLocal customerSessionLocal;
    @EJB
    private ListingSessionLocal listingSessionLocal;
    @EJB
    private LocationSessionLocal locationSessionLocal;       
    @EJB
    private HostDoorSystemSessionLocal hostDoorSystemSessionLocal;
    @EJB
    private SlotSessionLocal slotSessionLocal;            
    
    
    public DataInitializationSession()
    {
    }
    
    @PostConstruct
    public void postConstruct()
    {
        System.out.println("*** DataInitializationSession Bean ***\n");
        
        try
        {                            
            staffSessionLocal.retrieveStaffById(Long.valueOf(1));
        }
        catch(Exception ex)
        {
            initializeData();
        }
    }
    
    private void initializeData()
    {
        //....implement creation objects here
            Staff manager = new Staff("manager@agileSpace.com", "password", StaffAccessRightEnum.MANAGER);
            
            staffSessionLocal.createStaff(manager);
            
            System.out.println("Created Staff at dataInitisationBean\n");
                        
            Customer[] customers = new Customer[5];
            
            Listing[] listings = new Listing[5];
            
            Location[] locations = new Location[5];
            
            Feedback[] feedbacks = new Feedback[4]; //2 listing, 2 customers
            
            HostDoorSystem[] hostDoorSystems = new HostDoorSystem[5];
                                    
//            Booking[] bookings = new Booking[5];
            
            customers[0] = new Customer("alice@gmail.com", "aliceIsCool", "Alice", "Tan", "67891234");
            customers[1] = new Customer("bob@gmail.com", "bobIsCool", "Bob", "Lim", "67891235");            
            customers[2] = new Customer("peter@gmail.com", "peterIsCool", "Peter", "Tan", "6789126");
            customers[3] = new Customer("fate@gmail.com", "fateIsCool", "Fate", "Min", "67891235");              
            customers[4] = new Customer("frame@gmail.com", "frameIsCool", "Frame", "Win", "67891235"); 
            
            listings[0] = new Listing(BuildingTypeEnum.OFFICE, 
                        "11 North Buona Vista Drive, Singapore", 
                        "The advertised office space is perfect for a team of 1. If that's not quite right, we have ready-to-use workspaces of all sizes all over the world and our free service will help you find the perfect solution for your needs.",
                        5.00, 
                        null, //photoUrl
                        "5", //unit Level
                        "27");//unit Number           
            
            listings[1] = new Listing(BuildingTypeEnum.OFFICE, 
                        "15 Beach Road, Singapore", 
                        "The advertised office space is perfect for a team of 6. If that's not quite right, we have ready-to-use workspaces of all sizes all over the world and our free service will help you find the perfect solution for your needs.",
                        15.00, 
                        null, //photoUrl
                        "27", 
                        "190"); 
            
            listings[2] = new Listing(BuildingTypeEnum.OFFICE, 
                        "59 New Bridge Road, Singapore", 
                        "The advertised office space is perfect for a team of 6. If that's not quite right, we have ready-to-use workspaces of all sizes all over the world and our free service will help you find the perfect solution for your needs.",
                        25.00, 
                        null, //photoUrl
                        "2", 
                        "150"); 
            
            listings[3] = new Listing(BuildingTypeEnum.OFFICE, 
                        "299 Tanglin Road, Singapore", 
                        "The advertised office space is perfect for a team of 2. If that's not quite right, we have ready-to-use workspaces of all sizes all over the world and our free service will help you find the perfect solution for your needs.",
                        29.00, 
                        null, //photoUrl
                        "2", 
                        "9");    
            listings[4] = new Listing(BuildingTypeEnum.OFFICE, 
                        "1 Fusionopolis Place, Singapore", 
                        "The advertised office space is perfect for a team of 1. If that's not quite right, we have ready-to-use workspaces of all sizes all over the world and our free service will help you find the perfect solution for your needs.",
                        10.00, 
                        null, //photoUrl
                        "5", 
                        "27");  
            
            locations[0] = new Location("11 North Buona Vista Drive",//address
                                        "138589", 
                                        1.304968, 
                                        103.791438);
            
            locations[1] = new Location("15 Beach Road",//address
                                        "189677", 
                                        1.2958604, 
                                        103.7855073);
            
            locations[2] = new Location("59 New Bridge Rd, Singapore ",//address
                                        "059405", 
                                        1.2880209,
                                        103.84479);
    
            locations[3] = new Location("299 Tanglin Rd, Singapore",//address
                                        "247949", 
                                        1.3018883,
                                        103.819326);
            
            locations[4] = new Location("1 North Buona Vista Dr, Singapore ",//address
                                        "138675", 
                                        1.304968,
                                        103.7914136); 
            
            hostDoorSystems[0] = new HostDoorSystem(createHostDoorEmail(customers[0], listings[0], locations[0]), //email
                                                    "defaultPassword", //password
                                                    createHostDoorMasterQRCode(customers[0], listings[0])); //masterQRCode
            
            hostDoorSystems[1] = new HostDoorSystem(createHostDoorEmail(customers[1], listings[1], locations[1]), //email
                                                    "defaultPassword", //password
                                                    createHostDoorMasterQRCode(customers[1], listings[1])); //masterQRCode
            
            hostDoorSystems[2] = new HostDoorSystem(createHostDoorEmail(customers[2], listings[2], locations[2]), //email
                                                    "defaultPassword", //password
                                                    createHostDoorMasterQRCode(customers[2], listings[2])); //masterQRCode
            
            hostDoorSystems[3] = new HostDoorSystem(createHostDoorEmail(customers[3], listings[3], locations[3]), //email
                                                    "defaultPassword", //password
                                                    createHostDoorMasterQRCode(customers[3], listings[3])); //masterQRCode
            
            hostDoorSystems[4] = new HostDoorSystem(createHostDoorEmail(customers[4], listings[4], locations[4]), //email
                                                    "defaultPassword", //password
                                                    createHostDoorMasterQRCode(customers[4], listings[4])); //masterQRCode
            
            List<Slot> slots = new ArrayList<Slot>();
            List<Date> timeSlots = get24HourSlots();
            
            String startDateStr = "20/10/2018";
            String endDateStr = "20/10/2018";
            
            List<Date> dates = getListOfDates(startDateStr, endDateStr);
            
            for (Date date : dates) {
                System.out.println("date: " + date.toString());            
            }
            
            for(Date d : dates)
            {
                for(Date t: timeSlots)
                {
                    Calendar cal = Calendar.getInstance(); // creates calendar    
                    //setting of the date                                        
                    cal.setTime(t); // sets calendar time/date
                    cal.add(Calendar.HOUR_OF_DAY, 1); // adds one hour
                    slots.add(new Slot(d, d,/* cal.getTime(), cal.getTime(),*/ AvaliabilityEnum.AVAILABLE));
                }
            }
                                                                                            
            for(int i=0; i<customers.length; i++)
            {
                customers[i] = customerSessionLocal.createCustomer(customers[i]);
            }
            
            for(int i=0; i<listings.length; i++)
            {
                listings[i] = listingSessionLocal.createListing(listings[i]);
            }
            
            for(int i=0; i<locations.length; i++)
            {
                locations[i] = locationSessionLocal.createLocation(locations[i]);
            }
            
            for(int i=0; i<hostDoorSystems.length; i++)
            {
                hostDoorSystems[i] = hostDoorSystemSessionLocal.createHostDoorSystemAccount(hostDoorSystems[i]);
            }
            
            for(Slot s: slots)
            {
                slotSessionLocal.createSlot(s);
                System.out.println("s.toString() :" + s.toString());
            }
            
            //association
            for(int i=0; i<customers.length ; i++)
            {
                try 
                {                    
                    customerSessionLocal.addHostDoorSystem(customers[i].getId(), hostDoorSystems[i]);
                    hostDoorSystemSessionLocal.assignCustomer(hostDoorSystems[i].getId(), customers[i]);
                } 
                catch (Exception ex) {
                    Logger.getLogger(DataInitializationSession.class.getName()).log(Level.SEVERE, null, ex);
                }                
            }            
            
            for(int i=0; i<listings.length ; i++)
            {
                try 
                {                    
                    listingSessionLocal.assignLocation(listings[i].getId(), locations[i]);
                    locationSessionLocal.assignListing(locations[i].getId(), listings[i]);
                    
                    listingSessionLocal.assignHostDoorSystem(listings[i].getId(), hostDoorSystems[i]);
                    hostDoorSystemSessionLocal.assignListing(hostDoorSystems[i].getId(), listings[i]);
                } 
                catch (Exception ex) {
                    Logger.getLogger(DataInitializationSession.class.getName()).log(Level.SEVERE, null, ex);
                }                
            }
                      
            for(int i=0; i<1 ; i++)
            {
                try 
                {                    
                    for(Slot s: slots)
                    {
                        listingSessionLocal.addSlot(listings[i].getId(), s);
                        slotSessionLocal.assignListing(s.getId(), listings[i]);
                    }
                } 
                catch (Exception ex) {
                    Logger.getLogger(DataInitializationSession.class.getName()).log(Level.SEVERE, null, ex);
                }                
            }
            
            
            for(int i=0; i<customers.length ; i++)
            {
                try 
                {
                    customerSessionLocal.addListingToCustomer(customers[i].getId(), listings[i]);
                    listingSessionLocal.assignCustomer(listings[i].getId(), customers[i]);
                    
                } 
                catch (Exception ex) {
                    Logger.getLogger(DataInitializationSession.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            

    }
    
    private String createHostDoorEmail(Customer c, Listing l, Location loc)
    {
        String[] sp  = loc.getAddress().split(" ");
        
        return c.getFirstName().toLowerCase() + sp[1].toLowerCase() + l.getUnitLevel() + l.getUnitNumber() + "@agilespace.com";
    }
    
    private String createHostDoorMasterQRCode(Customer c, Listing l)
    {
        double randomNum = (Math.random() + Math.random() + Math.random()) * 1000;
        Date today = new Date();
                        
        return c.getFirstName().toLowerCase() + l.getUnitLevel() + l.getUnitNumber() + randomNum + today.toString().trim();
    }
    
    private List<Date> get24HourSlots()
    {
            List<Date> timeSlots = new ArrayList<Date>();
            
            //create slots for the whole day()
            Calendar cal = Calendar.getInstance();
            
            cal.set(Calendar.MINUTE,0);
            cal.set(Calendar.SECOND,0);
            cal.set(Calendar.MILLISECOND,0);
            
            for(int i=0; i<24; i++)
            {
                cal.set(Calendar.HOUR_OF_DAY,i);
                timeSlots.add(cal.getTime());
                
                System.out.println("i: " + i + " cal.getTime(): " + cal.getTime());
            }
            
            return timeSlots;
    }
    
    private List<Date> getListOfDates(String startDateStr, String endDateStr)
    {
            //create a list of dates between two dates()  
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            List<Date> dates = new ArrayList<Date>();

            Date startDate = null; 
            Date endDate = null;   
            
            try {
                startDate = (Date) sdf.parse(startDateStr);
                endDate = (Date) sdf.parse(endDateStr); 
            } catch (ParseException ex) {
                ex.printStackTrace();
            }                       

            long interval = 24*1000 * 60 * 60; // 1 hour in millis            
            
            long endTime = endDate.getTime() ; // create your endtime here, possibly using Calendar or Date
            long curTime = startDate.getTime();
            while (curTime <= endTime) {
                dates.add(new Date(curTime));
                curTime += interval;
            }   
            
        return dates; 
    }


}
