
package session.stateless;

import entity.Customer;
import entity.Feedback;
import entity.Listing;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class FeedbackSession implements FeedbackSessionLocal {
    
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;
    
    @Override
    public Feedback createFeedback(Feedback feedback) {
        
        em.persist(feedback);
        em.flush();
        em.refresh(feedback);
        
        return feedback;
    }

    @Override
    public Feedback retrieveFeedbackbyId(Long fId) throws AgileNoResultException {
        
        Feedback feedback = em.find(Feedback.class, fId);
        
        if(feedback != null)
        {
            return feedback;
        }
        else
        {
            throw new AgileNoResultException("Feedback with id: " + fId + " does not exist!");
        } 
    }

    @Override
    public List<Feedback> retrieveFeedbackByAttributes(Feedback feedback){
        
        Query q = em.createQuery("SELECT f FROM Feedback f WHERE (f.rating = :inRating OR f.feedbackTypeEnum =:inFeedbackTypeEnum OR LOWER(f.remarks) Like :inRemarks) " +
                                 "AND f.entityStatusEnum = :inEntityStatusEnum"); //to double check with this whether the LIKE works


        q.setParameter("inFeedbackTypeEnum", feedback.getFeedbackTypeEnum());
        q.setParameter("inRating", feedback.getRating());
        q.setParameter("inRemarks", "%" + feedback.getRemarks().toLowerCase() + "%");
        q.setParameter("inEntityStatusEnum", feedback.getEntityStatusEnum());
        

        return q.getResultList();  
    }

    @Override
    public List<Feedback> retrieveAllFeedbackForStaff() {
        
        Query query = em.createQuery("SELECT f FROM Feedback f");
        
        return query.getResultList(); 
    }

    @Override
    public Feedback updateFeedback(Feedback feedback) throws Exception{
        
        try
        {
            Feedback oldFeedback = retrieveFeedbackbyId(feedback.getId());
            
            if(feedback.getRating() != null)
            {
               oldFeedback.setRating(feedback.getRating());
            }
            
            if(feedback.getRemarks() != null)
            {
               oldFeedback.setRemarks(feedback.getRemarks()); 
            }
            
            if(feedback.getFeedbackTypeEnum() != null)
            {
               oldFeedback.setFeedbackTypeEnum(feedback.getFeedbackTypeEnum());
            }
             
            if(feedback.getPostingDateTime() != null)
            {
                oldFeedback.setPostingDateTime(feedback.getPostingDateTime());
            }
            
            if(feedback.getEntityStatusEnum() != null)
            {
                oldFeedback.setEntityStatusEnum(feedback.getEntityStatusEnum());
            }
   
            return oldFeedback;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public void deleteFeedback(Long fId) throws AgileNoResultException, Exception {
        
        try
        {
            Feedback feedback = retrieveFeedbackbyId(fId);
            
//            feedback.setFeedbacker(null);
//            feedback.setListing(null);           
//            
//            feedback.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            em.remove(feedback);
            
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }   
    }
    
    @Override
    public Feedback assignFeedbacker(Long fId, Customer customer) throws Exception{
        try
        {
            Feedback feedback = retrieveFeedbackbyId(fId);
            
            if(feedback.getFeedbacker() == null)
            {               
                feedback.setFeedbacker(customer);
                
                return feedback;
            }
            else
            {
                throw new DuplicateEntryException("This feedback already has a feedbacker assigned");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Feedback removeCustomer(Long fId, Customer customer) throws Exception {
        
        try
        {
            Feedback feedback = em.find(Feedback.class, fId);
        
            //disassociate the customer          
            feedback.setFeedbacker(null); 
            
            return feedback;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Feedback assignListing(Long fId, Listing listing) throws Exception {
       try
        {
            Feedback feedback = retrieveFeedbackbyId(fId);
            
            if(feedback.getListing() == null)
            {               
                feedback.setListing(listing);
                
                return feedback;
            }
            else
            {
                throw new DuplicateEntryException("This feedback already has a listing assigned");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Feedback removeListing(Long fId, Listing listing) throws Exception {
        
        try
        {
            Feedback feedback = em.find(Feedback.class, fId);
        
            //disassociate the customer          
            feedback.setListing(null); 
            
            return feedback;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }
}
