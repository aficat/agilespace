/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.AgileSpaceTransaction;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface AgileSpaceTransactionSessionLocal 
{
    public AgileSpaceTransaction createTransaction(AgileSpaceTransaction transaction);

    public AgileSpaceTransaction retrieveTransactionById(Long tId) throws AgileNoResultException;     
    
    public List<AgileSpaceTransaction> retrieveByAttribute(AgileSpaceTransaction transaction);
    
    public List<AgileSpaceTransaction> retrieveAllTransactionForStaff();

    public AgileSpaceTransaction updateTransaction(AgileSpaceTransaction transaction) throws Exception;

    public void deleteTransaction(Long tId) throws Exception; 
    
    
}
