
package session.stateless;

import entity.Listing;
import entity.Location;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class LocationSession implements LocationSessionLocal {

    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;

    @Override
    public Location createLocation(Location location) {
        
        em.persist(location);
        em.flush();
        em.refresh(location);
        
        return location;  
    }

    @Override
    public Location retrieveLocationById(Long lId) throws AgileNoResultException {
        
        Location location = em.find(Location.class, lId);
        
        if(location != null)
        {
            return location;
        }
        else
        {
            throw new AgileNoResultException("Location with id: " + lId + " does not exist!");
        }     
    }

    @Override
    public List<Location> retrieveByAttributes(Location location) {
        Query q1 = em.createQuery("SELECT l FROM Location l " + 
                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.postalCode = :inPostalCode");
        
        q1.setParameter("inAddress", "%" + location.getAddress().toLowerCase() + "%");
        q1.setParameter("inEntityStatusEnum", location.getEntityStatusEnum());
        
        Query q2 = em.createQuery("SELECT l FROM Location l " + 
                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND LOWER(l.address) LIKE :inAddress"); 

        q2.setParameter("inPostalCode", location.getPostalCode());
        q2.setParameter("inEntityStatusEnum", location.getEntityStatusEnum());
        
        Query q3 = em.createQuery("SELECT l FROM Location l " + 
                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.longitude = :inLongitude");
        
        q3.setParameter("inLongitude", location.getLongitude());
        q3.setParameter("inEntityStatusEnum", location.getEntityStatusEnum());
        
        Query q4 = em.createQuery("SELECT l FROM Location l " + 
                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.latitude = :inLatitude");
        
        q4.setParameter("inLatitude", location.getLatitude());
        q4.setParameter("inEntityStatusEnum", location.getEntityStatusEnum());

        List<Location> list = new ArrayList<>();
        
        if(!q1.getResultList().isEmpty())
        {
            for(Object o: q1.getResultList())
            {
                if(!list.contains((Location) o))
                {
                    list.add((Location) o);
                }
            }       
        }
        
        if(!q2.getResultList().isEmpty())
        {
            for(Object o: q2.getResultList())
            {
                if(!list.contains((Location) o))
                {
                    list.add((Location) o);
                }
            } 
        }     
        
        if(!q3.getResultList().isEmpty())
        {
            for(Object o: q3.getResultList())
            {
                if(!list.contains((Location) o))
                {
                    list.add((Location) o);
                }
            }          
        }   

        if(!q4.getResultList().isEmpty())
        {
            for(Object o: q4.getResultList())
            {
                if(!list.contains((Location) o))
                {
                    list.add((Location) o);
                }
            }          
        } 
        
        return list;      
    }

    @Override
    public List<Location> retrieveAllLocationForStaff() {
        Query query = em.createQuery("SELECT l FROM Location l");
        
        return query.getResultList();      
    }

    @Override
    public Location updateLocation(Location location) throws Exception {
        try
        {   
            Location oldLocation = retrieveLocationById(location.getId());
            
            if(location.getAddress()!= null)
            {
               oldLocation.setAddress(location.getAddress()); 
            }                   

            if(location.getPostalCode()!= null)
            {
               oldLocation.setPostalCode(location.getPostalCode()); 
            }
                        
            if(location.getLongitude() != null)
            {
               oldLocation.setLongitude(location.getLongitude());  
            } 
                 
            if(location.getLatitude() != null)
            {
               oldLocation.setLatitude(location.getLatitude());  
            } 
            
            if(location.getEntityStatusEnum() != null)
            {
               oldLocation.setEntityStatusEnum(location.getEntityStatusEnum());  
            }  
            
            return location;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }           
    }

    @Override
    public void deleteLocation(Long lId) throws Exception {
        try
        {
            Location location = retrieveLocationById(lId);
                        
            em.remove(location);
//            location.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);            
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }
    @Override
    public Location assignListing(Long lId, Listing listing) throws Exception {
        
        try
        {
            Location location = retrieveLocationById(lId);
            
            if(location.getListing() != null)
            {
                throw new DuplicateEntryException("Location already has an assigned listing.");
            }
           
            //associate the new one
//            listingSessionLocal.assignLocation(listing.getId(),location);
            
            location.setListing(listing);
        
            return location;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }      
    }

    @Override
    public Location removeListing(Long lId, Listing listing) throws Exception {
        try
        {
            Location location = retrieveLocationById(lId); 
            
            if(location.getListing() == null)
            {
                throw new AgileNoResultException("Location does not have that assigned listing.");
            }
           
            //disassociate the new one
//            listingSessionLocal.removeLocation(listing.getId(), location);            
            location.setListing(null);
        
            return location;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    } 
    
}
