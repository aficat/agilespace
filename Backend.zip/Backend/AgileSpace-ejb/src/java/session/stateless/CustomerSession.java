
package session.stateless;

import entity.Booking;
import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.EntityStatusEnum;
import util.exception.DuplicateEntryException;
import util.exception.InvalidLoginCredentialException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class CustomerSession implements CustomerSessionLocal {
    
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;
    
    @Override
    //check if email is unique, in the manager, change eamil to small caps.
    public Customer createCustomer(Customer customer) {
        System.out.println("*** Create Customer Started ***\n");
        
        em.persist(customer);
        em.flush();
        em.refresh(customer);
        
        System.out.println("*** Create Customer Ended ***\n");
        
        return customer;
    }

    @Override
    public Customer retrieveCustomerById(Long cId) throws AgileNoResultException {
        System.out.println("*** Retrieve Customer By Id Started ***\n");
        
        Customer customer = em.find(Customer.class, cId);
        
        if(customer != null)
        {
            System.out.println("*** Retrieve Customer By Id Ended ***\n");
            
            return customer;
        }
        else
        {
            throw new AgileNoResultException("Customer with id: " + cId + " does not exist!");
        } 
    }

    @Override
    public Customer retrieveCustomerByEmail(String email) throws AgileNoResultException {

        System.out.println("*** Retrieve Customer By Email Started ***\n");
        
        Query q = em.createQuery("SELECT c FROM Customer c WHERE LOWER(c.email) = :inEmail");
        
        q.setParameter("inEmail", email.toLowerCase());
        
        if(q.getSingleResult() != null)
        {
            System.out.println("*** Retrieve Customer By Email Ended ***\n");
            return (Customer) q.getSingleResult();
        }
        else
        {
            System.out.println("*** Retrieve Customer Exception Thrown ***\n");
//            throw new AgileNoResultException("Customer with email: " + email + " does not exist!");
            return null;
        }  
    }

    @Override
    public List<Customer> retrieveCustomerByAttributes(Customer customer){
        System.out.println("*** Retrieve Customer By Attributes Started ***\n");       
        
        Query q1 = em.createQuery("SELECT c1 FROM Customer c1 WHERE LOWER(c1.firstName) LIKE :inFirstName " + 
                                 "AND c1.entityStatusEnum = :inEntityStatusEnum");
       
        q1.setParameter("inFirstName", "%" + customer.getFirstName().toLowerCase() + "%");
        q1.setParameter("inEntityStatusEnum", EntityStatusEnum.ACTIVATED);
        
        Query q2 = em.createQuery("SELECT c2 FROM Customer c2 WHERE LOWER(c2.lastName) LIKE :inLastName " +                                  
                                 "AND c2.entityStatusEnum = :inEntityStatusEnum");   
        
        q2.setParameter("inLastName", "%" + customer.getLastName().toLowerCase() + "%");
        q2.setParameter("inEntityStatusEnum", EntityStatusEnum.ACTIVATED);
  
        Query q3 = em.createQuery("SELECT c3 FROM Customer c3 WHERE c3.phoneNum LIKE :inPhoneNum " +                                  
                                 "AND c3.entityStatusEnum = :inEntityStatusEnum");
        
        q3.setParameter("inPhoneNum", "%" + customer.getPhoneNum() + "%");        
        q3.setParameter("inEntityStatusEnum", EntityStatusEnum.ACTIVATED);    
        
        List<Customer> list = new ArrayList<>();
        
        if(!q1.getResultList().isEmpty())
        {
            for(Object o: q1.getResultList())
            {
                if(!list.contains((Customer) o))
                {
                    list.add((Customer) o);
                }
            }       
        }
        
        if(!q2.getResultList().isEmpty())
        {
            for(Object o: q2.getResultList())
            {
                if(!list.contains((Customer) o))
                {
                    list.add((Customer) o);
                }
            } 
        }     
        
        if(!q3.getResultList().isEmpty())
        {
            for(Object o: q3.getResultList())
            {
                if(!list.contains((Customer) o))
                {
                    list.add((Customer) o);
                }
            }          
        }                   
        
        System.out.println("*** Retrieve Customer By Attributes Ended ***\n");
        return list;   
    }

    @Override
    public List<Customer> retrieveAllActiveCustomers(){
        
        System.out.println("*** Retrieve All Active Customers Started ***\n");
        
        Query q = em.createQuery("SELECT c FROM Customer c WHERE c.entityStatusEnum = :inEntityStatusEnum");
        
        q.setParameter("inEntityStatusEnum", EntityStatusEnum.ACTIVATED);
        
        System.out.println("*** Retrieve All Active Customers Ended ***\n");
        return q.getResultList();
    }

    @Override
    public List<Customer> retrieveAllCustomersForStaff() {
        System.out.println("*** Retrieve All Customers For Staff Started ***\n");
        
        Query query = em.createQuery("SELECT c FROM Customer c");
        
        System.out.println("*** Retrieve All Customers For Staff Ended ***\n");
        return query.getResultList();  
    }

    @Override
    //need to check if email is not already is used.
    public Customer updateCustomer(Customer customer) throws Exception {
     
        System.out.println("*** Update Customer Started ***\n");
        
        try
        {
            Customer oldCustomer = retrieveCustomerById(customer.getId());
            
            if(customer.getEmail() != null)
            {
               oldCustomer.setEmail(customer.getEmail()); 
            }
            
            if(customer.getPassword() != null)
            {
               oldCustomer.setPassword(customer.getPassword()); 
            }
            
            if(customer.getFirstName() != null)
            {
               oldCustomer.setFirstName(customer.getFirstName());
            }
            
            if(customer.getLastName() != null)
            {
                oldCustomer.setLastName(customer.getLastName());
            }
            
            if(customer.getPhoneNum()!= null)
            {
                oldCustomer.setPhoneNum(customer.getPhoneNum());
            }
            
            if(customer.getEntityStatusEnum() != null)
            {
                oldCustomer.setEntityStatusEnum(customer.getEntityStatusEnum());
            }
            
            if(customer.getRating() != null)
            {
                oldCustomer.setRating(customer.getRating());
            }
            
            System.out.println("*** Update Customer Ended ***\n");
            
            return oldCustomer;
        }
        catch(Exception ex)
        {
            throw new AgileNoResultException(ex.getMessage());
        }
    }

    @Override
    //auto dissociate the associated entity
    public void deleteCustomer(Long cId) throws Exception {
        
        System.out.println("*** Delete Customer Started ***\n");
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
//            customer.setListings(null);
//            customer.setBookings(null);
//            customer.setFeedbacks(null);
//            
//            customer.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            em.remove(customer);
            
             System.out.println("*** Delete Customer Ended ***\n");
        } 
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Customer login(String email, String password) throws Exception {
        
        System.out.println("*** Login Started ***\n");
        
        try
        {
            Customer customer = retrieveCustomerByEmail(email.toLowerCase());
            
            if(customer.getPassword().equals(password))
            {
                System.out.println("*** Login Ended ***\n");
                
                return customer;
            }
            else
            {
                throw new InvalidLoginCredentialException("Username does not exist or invalid password!");
            }
        }
        catch(Exception ex)
        {
            throw new InvalidLoginCredentialException("Username does not exist or invalid password!");
        }
    }
    
    @Override
    public Customer addPhotoUrlToCustomer(Long cId, String url) throws Exception 
    {
         System.out.println("*** Add PhotoUrl To Customer Started ***\n");
         System.out.println("url is " + url);
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getPhotoUrls().contains(url);
            System.out.println("hasExist is " + hasExist);
             
            if(!hasExist)
            {                
                customer.getPhotoUrls().add(url);
                
                System.out.println("*** Add PhotoUrl To Customer Ended ***\n");
                return customer;
            }
            else
            {
                throw new DuplicateEntryException("This photo has already been added");
            }
            
    }

    @Override
    public Customer removePhotoUrlToCustomer(Long cId, String url) throws Exception 
    {
        System.out.println("*** Remove PhotoUrl To Customer Started ***\n");
        System.out.println("url: " + url);
        
        
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getPhotoUrls().contains(url);
            
            System.out.println("hasExist is " + hasExist);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Customer does not have that photo");
            }
            else
            {              
                customer.getPhotoUrls().remove(url);
                 
                System.out.println("*** Remove PhotoUrl To Customer Ended ***\n");
                
                return customer;
            } 
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    } 
    
    @Override
    public Customer addListingToCustomer(Long cId, Listing listing) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getListings().contains(listing);
            
            if(!hasExist)
            {
                System.out.println("Listing is about to be added");
                customer.getListings().add(listing);
                System.out.println("Listing is added");
                return customer;
            }
            else
            {
                throw new DuplicateEntryException("This Listing (id:" + listing.getId() + ") has already been added");
            }
        }
        catch(AgileNoResultException ex)
        {
            throw new AgileNoResultException(ex.getMessage());
        }
    }

    @Override
    public Customer removeListing(Long cId, Listing listing) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getListings().contains(listing);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Customer does not have that listing");
            }
            else
            {             
                customer.getListings().remove(listing);
                 
                return customer;
            } 
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    }

    @Override
    public Customer addBooking(Long cId, Booking booking) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getBookings().contains(booking);
            
            if(!hasExist)
            {                
                customer.getBookings().add(booking);
                
                return customer;
            }
            else
            {
                throw new DuplicateEntryException("This booking (id:" + booking.getId() + ") has already been added");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Customer removeBooking(Long cId, Booking booking) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getBookings().contains(booking);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Customer does not have that booking");
            }
            else
            {                
                customer.getBookings().remove(booking);
                 
                return customer;
            }
          
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    }

    @Override
    public Customer addFeedback(Long cId, Feedback feedback) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getFeedbacks().contains(feedback);
            
            if(!hasExist)
            {                
                customer.getFeedbacks().add(feedback);
                
                return customer;
            }
            else
            {
                throw new DuplicateEntryException("This feedback (id:" + feedback.getId() + ") has already been added");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Customer removeFeedback(Long cId, Feedback feedback) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getFeedbacks().contains(feedback);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Customer does not have that feedback");
            }
            else
            {               
                customer.getFeedbacks().remove(feedback);
                 
                return customer;
            }
          
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    }

    @Override
    public Customer addHostDoorSystem(Long cId, HostDoorSystem hostDoorSystem) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getHostDoorSystems().contains(hostDoorSystem);
            
            if(!hasExist)
            {
                customer.getHostDoorSystems().add(hostDoorSystem);
                
                return customer;
            }
            else
            {
                throw new DuplicateEntryException("This host door system (id:" + hostDoorSystem.getId() + ") has already been added");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Customer removeHostDoorSystem(Long cId, HostDoorSystem hostDoorSystem) throws Exception {
        try
        {
            Customer customer = retrieveCustomerById(cId);
            
            Boolean hasExist = customer.getHostDoorSystems().contains(hostDoorSystem);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Customer does not have that host door system");
            }
            else
            {               
                customer.getHostDoorSystems().remove(hostDoorSystem);
                 
                return customer;
            }  
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    }    
}
