/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Booking;
import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface CustomerSessionLocal 
{
   public Customer createCustomer(Customer customer);
   
   public Customer retrieveCustomerById(Long cId) throws AgileNoResultException;
   
   public Customer retrieveCustomerByEmail(String email) throws AgileNoResultException;
   
   public List<Customer> retrieveCustomerByAttributes(Customer customer);   
   
   public List<Customer> retrieveAllActiveCustomers();
   
   public List<Customer> retrieveAllCustomersForStaff();
   
   public Customer updateCustomer (Customer customer) throws Exception;
   
   public void deleteCustomer(Long cId) throws Exception;
   
   public Customer login(String email, String password) throws Exception;

   public Customer addPhotoUrlToCustomer(Long cId, String url) throws Exception;
   
   public Customer removePhotoUrlToCustomer(Long cId, String url) throws Exception;      

   public Customer addListingToCustomer(Long cId, Listing listing) throws Exception;
   
   public Customer removeListing(Long cId, Listing listing) throws Exception;
   
   public Customer addBooking(Long cId, Booking booking) throws Exception;
   
   public Customer removeBooking(Long cId, Booking booking) throws Exception;
   
   public Customer addFeedback(Long cId, Feedback feedback) throws Exception;
   
   public Customer removeFeedback(Long cId, Feedback feedback) throws Exception; 
   
   public Customer addHostDoorSystem(Long cId, HostDoorSystem hostDoorSystem) throws Exception;
   
   public Customer removeHostDoorSystem(Long cId, HostDoorSystem hostDoorSystem) throws Exception;

}
