/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Customer;
import entity.HostDoorSystem;
import entity.Listing;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface HostDoorSystemSessionLocal 
{
    public HostDoorSystem createHostDoorSystemAccount(HostDoorSystem hostDoorSystem);

    public HostDoorSystem retrieveHostDoorSystemAccountById(Long hId) throws AgileNoResultException;

    public HostDoorSystem retrieveHostDoorSystemAccountByEmail(String email) throws AgileNoResultException;

    public List<HostDoorSystem> retrieveAllHostDoorSystemAccount();

    public HostDoorSystem updateHostDoorSystemAccount(HostDoorSystem hostDoorSystem) throws Exception;

    public void deleteHostDoorSystemAccount(Long hId) throws Exception;
    
    public HostDoorSystem login(String email, String password) throws Exception;

    public HostDoorSystem assignCustomer(Long hId, Customer customer) throws Exception;
    
    public HostDoorSystem removeCustomer(Long hId, Customer customer) throws Exception;
    
    public HostDoorSystem assignListing(Long hId, Listing listing) throws Exception;
    
    public HostDoorSystem removeListing(Long hId, Listing listing) throws Exception;
}
