/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Staff;
import java.util.List;
import javax.ejb.Local;
import util.enumeration.StaffAccessRightEnum;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface StaffSessionLocal {
    
    public Staff createStaff(Staff staff);
 
    public Staff retrieveStaffById(Long sId) throws AgileNoResultException;

    public Staff retrieveStaffByEmail(String email) throws AgileNoResultException;
    
    public List<Staff> retrieveStaffByDepartment(StaffAccessRightEnum staffAccessRightEnum) throws AgileNoResultException;

    public List<Staff> retrieveAllStaff();

    public Staff updateStaff(Staff staff) throws Exception;

    public void deleteStaff(Long sId) throws Exception;
    
    public Staff login(String email, String password) throws Exception;
}
