/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Location;
import entity.Slot;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.EntityStatusEnum;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class ListingSession implements ListingSessionLocal {

    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;

    @Override
    //check if location of the listing is unique that no other listing has that location.
    public Listing createListing(Listing listing) {
        em.persist(listing);
        em.flush();
        em.refresh(listing);

        return listing;
    }

    @Override
    public Listing retrieveListingById(Long lId) throws AgileNoResultException {

        Listing listing = em.find(Listing.class, lId);

        if (listing != null) {
            return listing;
        } else {
            throw new AgileNoResultException("Listing with id: " + lId + " does not exist!");
        }
    }

    @Override
    public List<Listing> retrieveListingByAttributes(Listing listing) {

        System.out.println("*** Retrieve Listing By Attributes Started ***\n");

        Query q1 = em.createQuery("SELECT l FROM Listing l "
                + "WHERE l.entityStatusEnum = :inEntityStatusEnum AND LOWER(l.header) LIKE :inHeader");

        q1.setParameter("inHeader", "%" + listing.getHeader().toLowerCase() + "%");
        q1.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());

        Query q2 = em.createQuery("SELECT l FROM Listing l "
                + "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.buildingTypeEnum = :inBuildingTypeEnum");

        q2.setParameter("inBuildingTypeEnum", listing.getBuildingTypeEnum());
        q2.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());

        Query q3 = em.createQuery("SELECT l FROM Listing l "
                + "WHERE l.entityStatusEnum = :inEntityStatusEnum AND LOWER(l.description) LIKE :inDescription");

        q3.setParameter("inDescription", "%" + listing.getDescription().toLowerCase() + "%");
        q3.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());

//        Query q4 = em.createQuery("SELECT l FROM Listing l " + 
//                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.price = :inPrice");
//        
//        q4.setParameter("inPrice",  listing.getPrice());
//        q4.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());
//        
//        Query q5 = em.createQuery("SELECT l FROM Listing l " + 
//                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.unitLevel = :inUnitLevel");
//        
//        q5.setParameter("inUnitLevel", "%" + listing.getUnitLevel() + "%");        
//        q5.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());        
//
//        Query q6 = em.createQuery("SELECT l FROM Listing l " + 
//                                 "WHERE l.entityStatusEnum = :inEntityStatusEnum AND l.unitNumber = :inUnitNumber");              
//        q6.setParameter("inUnitNumber", "%" + listing.getUnitNumber() + "%");
//        q6.setParameter("inEntityStatusEnum", listing.getEntityStatusEnum());       
        List<Listing> list = new ArrayList<>();

        if (!q1.getResultList().isEmpty()) {
            System.out.println("q1.getResultList()");
            for (Object o : q1.getResultList()) {
                if (!list.contains((Listing) o)) {
                    System.out.println(o.toString());
                    list.add((Listing) o);
                }
            }
        }

        if (!q2.getResultList().isEmpty()) {
            System.out.println("q2.getResultList()");
            for (Object o : q2.getResultList()) {
                if (!list.contains((Listing) o)) {
                    System.out.println(o.toString());
                    list.add((Listing) o);
                }
            }
        }

        if (!q3.getResultList().isEmpty()) {
            System.out.println("q3.getResultList()");
            for (Object o : q3.getResultList()) {
                if (!list.contains((Listing) o)) {
                    System.out.println(o.toString());
                    list.add((Listing) o);
                }
            }
        }

//        if(!q4.getResultList().isEmpty())
//        {
//            for(Object o: q4.getResultList())
//            {
//                if(!list.contains((Listing) o))
//                {
//                    list.add((Listing) o);
//                }
//            }       
//        }
//        
//        if(!q5.getResultList().isEmpty())
//        {
//            for(Object o: q5.getResultList())
//            {
//                if(!list.contains((Listing) o))
//                {
//                    list.add((Listing) o);
//                }
//            } 
//        }     
//        
//        if(!q6.getResultList().isEmpty())
//        {
//            for(Object o: q6.getResultList())
//            {
//                if(!list.contains((Listing) o))
//                {
//                    list.add((Listing) o);
//                }
//            }          
//        }          
        System.out.println("*** Retrieve Listing By Attributes Ended ***\n");
        return list;
    }

    @Override
    public List<Listing> retrieveAllListingForStaff() {
        Query query = em.createQuery("SELECT l FROM Listing l");

        return query.getResultList();
    }

    @Override
    public Listing updateListing(Listing listing) throws Exception {
        try {
            Listing oldListing = retrieveListingById(listing.getId());

            if (listing.getBuildingTypeEnum() != null) {
                oldListing.setBuildingTypeEnum(listing.getBuildingTypeEnum());
            }

            if (listing.getHeader() != null) {
                oldListing.setHeader(listing.getHeader());
            }

            if (listing.getDescription() != null) {
                oldListing.setDescription(listing.getDescription());
            }

            if (listing.getPrice() != null) {
                oldListing.setPrice(listing.getPrice());
            }

            if (listing.getUnitLevel() != null) {
                oldListing.setUnitLevel(listing.getUnitLevel());
            }

            if (listing.getUnitNumber() != null) {
                oldListing.setUnitNumber(listing.getUnitNumber());
            }

            if (listing.getEntityStatusEnum() != null) {
                oldListing.setEntityStatusEnum(listing.getEntityStatusEnum());
            }

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public void deleteListing(Long lId) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);
//            
//            listing.setListingOwner(null);
//            listing.setFeedbacks(null);
//            listing.setAvaliableSlots(null);
//            listing.setHostDoorSystem(null);
//            listing.setLocation(null);
//            
//            listing.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);            
            em.remove(listing);
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing assignCustomer(Long lId, Customer customer) throws Exception {

        try {
            Listing listing = retrieveListingById(lId);

            if (listing.getListingOwner() != null) {
                throw new DuplicateEntryException("Listing already has an assigned owner.");
            }

            //associate the new one
            listing.setListingOwner(customer);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing removeCustomer(Long lId, Customer customer) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            if (listing.getListingOwner() == null) {
                throw new AgileNoResultException("Listing does not have that assigned owner.");
            }

            //disassociate the new one
//            customerSessionLocal.removeListing(customer.getId(), listing);            
            listing.setListingOwner(null);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing addFeedback(Long lId, Feedback feedback) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            Boolean hasExist = listing.getFeedbacks().contains(feedback);

            if (!hasExist) {
//                feedbackSessionLocal.assignListing(feedback.getId(), listing);

                listing.getFeedbacks().add(feedback);

                return listing;
            } else {
                throw new DuplicateEntryException("This feedback has already been added");
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing removeFeedback(Long lId, Feedback feedback) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            Boolean hasExist = listing.getFeedbacks().contains(feedback);

            if (!hasExist) {
                throw new AgileNoResultException("Listing does not have that feedback");
            } else {
                listing.getFeedbacks().remove(feedback);

                return listing;
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing addSlot(Long lId, Slot slot) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            Boolean hasExist = listing.getAvaliableSlots().contains(slot);

            if (!hasExist) {
                listing.getAvaliableSlots().add(slot);

                return listing;
            } else {
                throw new DuplicateEntryException("This slot has already been added");
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing removeSlot(Long lId, Slot slot) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            Boolean hasExist = listing.getAvaliableSlots().contains(slot);

            if (!hasExist) {
                throw new AgileNoResultException("Listing does not have that slot");
            } else {
                listing.getAvaliableSlots().remove(slot);

                return listing;
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing assignHostDoorSystem(Long lId, HostDoorSystem hostDoorSystem) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

//            if (listing.getHostDoorSystem() != null) {
//                throw new DuplicateEntryException("Listing already has an assigned host door system.");
//            }

            //associate the new one           
            listing.setHostDoorSystem(hostDoorSystem);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing removeHostDoorSystem(Long lId, HostDoorSystem hostDoorSystem) throws Exception {
        try {
            Listing listing = retrieveListingById(lId);

            if (listing.getHostDoorSystem() == null) {
                throw new AgileNoResultException("Listing does not have that assigned host door system.");
            }

            //disassociate the new one
            listing.setHostDoorSystem(null);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing assignLocation(Long lId, Location location) throws Exception, Exception {
        try {
            Listing listing = retrieveListingById(lId);

            if (listing.getLocation() != null) {
                throw new DuplicateEntryException("Listing already has an assigned location.");
            }

            //associate the new one        
            listing.setLocation(location);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Listing removeLocation(Long lId, Location location) throws Exception {

        try {
            Listing listing = retrieveListingById(lId);

            if (listing.getListingOwner() == null) {
                throw new AgileNoResultException("Listing does not have that assigned location.");
            }

            //disassociate the new one          
            listing.setLocation(null);

            return listing;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }
}
