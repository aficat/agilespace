/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Listing;
import entity.Location;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface LocationSessionLocal 
{
    public Location createLocation(Location location);
    
    public Location retrieveLocationById(Long lId) throws AgileNoResultException;
       
    public List<Location> retrieveByAttributes(Location location);
    
    public List<Location> retrieveAllLocationForStaff();
    
    public Location updateLocation(Location location) throws Exception;
    
    public void deleteLocation(Long lId) throws Exception;
    
    public Location assignListing(Long lId, Listing listing) throws Exception;
    
    public Location removeListing(Long lId, Listing listing) throws Exception;    
}
