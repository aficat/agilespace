/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Booking;
import entity.Listing;
import entity.Location;
import entity.Slot;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class SlotSession implements SlotSessionLocal {
    
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;

    @Override
    //check if time slot has already been created.
    public Slot createSlot(Slot slot) {
        
        em.persist(slot);
        em.flush();
        em.refresh(slot);
        
        return slot;    
    }

    @Override
    public Slot retrieveSlotById(Long sId) throws AgileNoResultException {
        Slot slot = em.find(Slot.class, sId);
        
        if(slot != null)
        {
            return slot;
        }
        else
        {
            throw new AgileNoResultException("Slot with id: " + sId + " does not exist!");
        }   
    }

    @Override
    public List<Slot> retrieveSlotByAttributes(Slot slot) {
        Query q1 = em.createQuery("SELECT s FROM Slot s " + 
                                    "WHERE s.entityStatusEnum = :inEntityStatusEnum " +
                                    "AND s.startDate = :inStartDate");

        q1.setParameter("inStartDate", slot.getStartDate());
        q1.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());
        
        Query q2 = em.createQuery("SELECT s FROM Slot s " + 
                                    "WHERE s.entityStatusEnum = :inEntityStatusEnum " +
                                    "AND s.endDate = :inEndDate");
        q2.setParameter("inEndDate", slot.getEndDate()); 
        q2.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());
        /*
        Query q3 = em.createQuery("SELECT s FROM Slot s " + 
                                    "WHERE s.entityStatusEnum = :inEntityStatusEnum " +
                                    "AND s.startTime = :inStartTime");
        q3.setParameter("inStartTime", slot.getStartTime()); 
        q3.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());
        
        Query q4 = em.createQuery("SELECT s FROM Slot s " + 
                                    "WHERE s.entityStatusEnum = :inEntityStatusEnum " +
                                    "AND s.endTime = :inEndTime");
        q4.setParameter("inEndTime", slot.getEndTime()); 
                
        q4.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());
        */
        Query q5 = em.createQuery("SELECT s FROM Slot s " + 
                                    "WHERE s.entityStatusEnum = :inEntityStatusEnum " +
                                    "AND s.avaliabilityEnum = :inAvaliabilityEnum");
        
        q5.setParameter("inAvaliabilityEnum", slot.getAvaliabilityEnum());        
        q5.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());                      

        List<Slot> list = new ArrayList<>();
        
        if(!q1.getResultList().isEmpty())
        {
            for(Object o: q1.getResultList())
            {
                if(!list.contains((Slot) o))
                {
                    list.add((Slot) o);
                }
            }       
        }
        
        if(!q2.getResultList().isEmpty())
        {
            for(Object o: q2.getResultList())
            {
                if(!list.contains((Slot) o))
                {
                    list.add((Slot) o);
                }
            } 
        }     
        /*
        if(!q3.getResultList().isEmpty())
        {
            for(Object o: q3.getResultList())
            {
                if(!list.contains((Slot) o))
                {
                    list.add((Slot) o);
                }
            }          
        }   

        if(!q4.getResultList().isEmpty())
        {
            for(Object o: q4.getResultList())
            {
                if(!list.contains((Slot) o))
                {
                    list.add((Slot) o);
                }
            }          
        } 
        */
        if(!q5.getResultList().isEmpty())
        {
            for(Object o: q5.getResultList())
            {
                if(!list.contains((Slot) o))
                {
                    list.add((Slot) o);
                }
            }          
        }         
        
        return list;  
    }

    @Override
    public List<Slot> retrieveAllSlotForStaff() {
        Query query = em.createQuery("SELECT s FROM Slot s");
        
        return query.getResultList();  
    }

    @Override
    public Slot updateSlot(Slot slot) throws Exception {
        try
        {   
            Slot oldSlot = retrieveSlotById(slot.getId());
            
            if(slot.getStartDate()!= null)
            {
               oldSlot.setStartDate(slot.getStartDate()); 
            }                   

            if(slot.getEndDate()!= null)
            {
               oldSlot.setEndDate(slot.getEndDate()); 
            }
            /*
            if(slot.getStartTime()!= null)
            {
               oldSlot.setStartTime(slot.getStartTime()); 
            }                   

            if(slot.getEndTime()!= null)
            {
               oldSlot.setEndTime(slot.getEndTime()); 
            }            
            */ 
            if(slot.getAvaliabilityEnum()!= null)
            {
               oldSlot.setAvaliabilityEnum(slot.getAvaliabilityEnum());  
            }          
            
            if(slot.getEntityStatusEnum() != null)
            {
               oldSlot.setEntityStatusEnum(slot.getEntityStatusEnum());  
            }  
            
            return slot;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }           
    }

    @Override
    public void deleteSlot(Long sId) throws Exception {
        
        try 
        {
            Slot slot = retrieveSlotById(sId);
            
//            slot.setListing(null);            
//            slot.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            
            em.remove(slot);
            
        } 
        catch (Exception ex) 
        {
            throw new Exception(ex.getMessage());
        }
    }
    @Override
    public Slot assignListing(Long sId, Listing listing) throws Exception {
        try
        {
            Slot slot = retrieveSlotById(sId);
            
            if(slot.getListing() != null)
            {
                throw new DuplicateEntryException("Slot already has an assigned listing.");
            }
           
            //associate the new one            
            slot.setListing(listing);
            
            return slot;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }    
    }

    @Override
    public Slot removeListing(Long sId, Listing listing) throws Exception {
        try
        {
            Slot slot = retrieveSlotById(sId);  
            
            if(slot.getListing() == null)
            {
                throw new AgileNoResultException("Slot does not have that assigned listing.");
            }
           
            //disassociate the new one
//            listingSessionLocal.removeSlot(listing.getId(), slot);            
            slot.setListing(null);
        
            return slot;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }   
    }

    @Override
    public Slot assignBooking(Long sId, Booking booking) throws Exception {
        try
        {
            Slot slot = retrieveSlotById(sId);
            
            if(slot.getBooking() != null)
            {
                throw new DuplicateEntryException("Slot already has an assigned booking.");
            }
           
            //associate the new one
            
            slot.setBooking(booking);
            
            return slot;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    }

    @Override
    public Slot removeBooking(Long sId, Booking booking) throws Exception {
        try
        {
            Slot slot = retrieveSlotById(sId);  
            
            if(slot.getBooking()== null)
            {
                throw new AgileNoResultException("Slot does not have that assigned booking.");
            }
           
            //disassociate the new one
//            bookingSessionLocal.removeSlot(booking.getId(), slot);            
            slot.setBooking(null);
        
            return slot;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    }    
}
