/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Location;
import entity.Slot;
import java.util.List;
import javax.ejb.Local;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface ListingSessionLocal 
{
    public Listing createListing(Listing listing);
    
    public Listing retrieveListingById(Long lId) throws AgileNoResultException;
   
    public List<Listing> retrieveListingByAttributes(Listing listing);
    
    public List<Listing> retrieveAllListingForStaff();

    public Listing updateListing(Listing listing) throws Exception;

    public void deleteListing(Long lId) throws Exception;    

    public Listing assignCustomer(Long lId, Customer customer) throws Exception;
   
    public Listing removeCustomer(Long lId, Customer customer) throws Exception;

    public Listing addFeedback(Long lId, Feedback feedback) throws Exception;

    public Listing removeFeedback(Long lId, Feedback feedback) throws Exception;
    
    public Listing addSlot(Long lId, Slot slot) throws Exception;

    public Listing removeSlot(Long lId, Slot slot) throws Exception;
    
    public Listing assignHostDoorSystem(Long lId, HostDoorSystem hostDoorSystem) throws Exception;
   
    public Listing removeHostDoorSystem(Long lId, HostDoorSystem hostDoorSystem) throws Exception;
    
    public Listing assignLocation(Long lId, Location location) throws Exception;
   
    public Listing removeLocation(Long lId, Location location) throws Exception;
}
