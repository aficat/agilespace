/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Booking;
import entity.Customer;
import entity.Listing;
import entity.Slot;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface BookingSessionLocal 
{
    public Booking createBooking(Booking booking);

    public Booking retrieveBookingById(Long bId) throws AgileNoResultException;
    
    //for admin to view all booking records
    public List<Booking> retrieveAllBookingForStaff() throws AgileNoResultException;
    
    //if user wants to find by specific fields, else to find asscoiated booking, can use search by id
    public List<Booking> retrieveBookingsBySlotAttributes(Slot slot);
    
    //this maybe the verify QR code
    //QRCode is unique to each Booking
    public Booking retrieveBookingByQrCode(String qrCode);
    
    public Booking updateBookingAttributes(Booking booking) throws Exception;   

    public void deleteBooking(Long bId) throws Exception;
    
    public Listing getListingByQrCode(Long lId, String qrCode) throws Exception;
    
    //can assign or change the present Customer object
    public Booking assignCustomer(Long bId, Customer customer) throws Exception;
   
    public Booking removeCustomer(Long bId, Customer customer) throws Exception;
     
    public Booking addSlot(Long bId, Slot slot) throws Exception;
   
    public Booking removeSlot(Long bId, Slot slot) throws Exception;
}
