
package session.stateless;

import entity.Customer;
import entity.HostDoorSystem;
import entity.Listing;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.DuplicateEntryException;
import util.exception.InvalidLoginCredentialException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class HostDoorSystemSession implements HostDoorSystemSessionLocal {
            
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;
    
    @Override
    public HostDoorSystem createHostDoorSystemAccount(HostDoorSystem hostDoorSystem) {
        em.persist(hostDoorSystem);
        em.flush();
        em.refresh(hostDoorSystem);
        
        return hostDoorSystem;
    }

    @Override
    public HostDoorSystem retrieveHostDoorSystemAccountById(Long hId) throws AgileNoResultException{
        
        HostDoorSystem hostDoorSystem= em.find(HostDoorSystem.class, hId);
        
        if(hostDoorSystem != null)
        {
            return hostDoorSystem;
        }
        else
        {
            throw new AgileNoResultException("HostDoorSystem with id: " + hId + " does not exist!");
        }     
    }

    @Override
    public HostDoorSystem retrieveHostDoorSystemAccountByEmail(String email) throws AgileNoResultException{
        Query q = em.createQuery("SELECT h FROM HostDoorSystem h WHERE h.email = :inEmail");
        
        q.setParameter("inEmail", email);
        
        if(q.getSingleResult() != null)
        {
            return (HostDoorSystem)q.getSingleResult();
        }
        else
        {
            throw new AgileNoResultException("HostDoorSystem with email: " + email + " does not exist!");
        } 
    }

    @Override
    public List<HostDoorSystem> retrieveAllHostDoorSystemAccount() {
        
        Query query = em.createQuery("SELECT h FROM HostDoorSystem h");
        
        return query.getResultList();  
    }

    @Override
    public HostDoorSystem updateHostDoorSystemAccount(HostDoorSystem hostDoorSystem) throws Exception{
        try
        {
            HostDoorSystem oldHostDoorSystem = retrieveHostDoorSystemAccountById(hostDoorSystem.getId());
            
            if(hostDoorSystem.getEmail() != null)
            {
               oldHostDoorSystem.setEmail(hostDoorSystem.getEmail()); 
            }
            
            if(hostDoorSystem.getPassword() != null)
            {
               oldHostDoorSystem.setPassword(hostDoorSystem.getPassword()); 
            }
            
            if(hostDoorSystem.getMasterQrCode() != null)
            {
               oldHostDoorSystem.setMasterQrCode(hostDoorSystem.getMasterQrCode()); 
            }  
            return oldHostDoorSystem;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public void deleteHostDoorSystemAccount(Long hId) throws Exception{
        try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountById(hId);            
            
//            hostDoorSystem.setOwner(null);
//            hostDoorSystem.setListing(null); 
//            
//            hostDoorSystem.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            em.remove(hostDoorSystem);

        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public HostDoorSystem login(String email, String password) throws Exception {
        
        try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountByEmail(email);
            
            if(hostDoorSystem.getPassword().equals(password))
            {
                return hostDoorSystem;
            }
            else
            {
                throw new InvalidLoginCredentialException("Username does not exist or invalid password!");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }
    
    @Override
    public HostDoorSystem assignCustomer(Long hId, Customer customer) throws Exception{
        
        try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountById(hId); 
            
            if(hostDoorSystem.getOwner() != null)
            {
                throw new DuplicateEntryException("HostDoorSystem already has an assigned owner.");
            }           
            
            hostDoorSystem.setOwner(customer);
        
            return hostDoorSystem;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }    
    }

    @Override
    public HostDoorSystem removeCustomer(Long hId, Customer customer) throws Exception{

        try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountById(hId); 
            
            if(hostDoorSystem.getOwner() == null)
            {
                throw new AgileNoResultException("HostDoorSystem does not has that assigned owner.");
            }
           
            //disassociate the new one         
            hostDoorSystem.setOwner(null);
        
            return hostDoorSystem;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    }

    @Override
    public HostDoorSystem assignListing(Long hId, Listing listing) throws Exception{
        try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountById(hId); 
            
            if(hostDoorSystem.getListing() != null)
            {
                throw new DuplicateEntryException("HostDoorSystem already has an assigned listing.");
            }
           
            //associate the new one
            
            hostDoorSystem.setListing(listing);
        
            return hostDoorSystem;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }    
    }

    @Override
    public HostDoorSystem removeListing(Long hId, Listing listing) throws Exception{
       try
        {
            HostDoorSystem hostDoorSystem = retrieveHostDoorSystemAccountById(hId); 
            
            if(hostDoorSystem.getListing() == null)
            {
                throw new AgileNoResultException("HostDoorSystem does not has that assigned listing.");
            }
           
            //disassociate the new one          
            hostDoorSystem.setListing(null);
        
            return hostDoorSystem;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    }    
}
