/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Booking;
import entity.Listing;
import entity.Slot;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface SlotSessionLocal 
{
    public Slot createSlot(Slot slot);
 
    public Slot retrieveSlotById(Long sId) throws AgileNoResultException;
    
    public List<Slot> retrieveSlotByAttributes(Slot slot);
    
    public List<Slot> retrieveAllSlotForStaff();

    public Slot updateSlot(Slot slot) throws Exception;

    public void deleteSlot(Long sId) throws Exception; 
    
    public Slot assignListing(Long sId, Listing listing) throws Exception;
    
    public Slot removeListing(Long sId, Listing listing) throws Exception;
    
    public Slot assignBooking(Long sId, Booking booking) throws Exception;
    
    public Slot removeBooking(Long sId, Booking booking) throws Exception;    
}
