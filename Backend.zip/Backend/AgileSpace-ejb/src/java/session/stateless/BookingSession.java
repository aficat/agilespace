
package session.stateless;

import entity.Booking;
import entity.Customer;
import entity.Listing;
import entity.Slot;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.EntityStatusEnum;
import util.exception.DuplicateEntryException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class BookingSession implements BookingSessionLocal 
{               
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;
    
    @Override
    public Booking createBooking(Booking booking) {
        
        em.persist(booking);
        em.flush();
        em.refresh(booking);
        
        return booking;
    }

    @Override
    public Booking retrieveBookingById(Long bId) throws AgileNoResultException {
        
        Booking booking = em.find(Booking.class, bId);
        
        if(booking != null)
        {
            return booking;
        }
        else
        {
            throw new AgileNoResultException("Booking with id: " + bId + " does not exist!");
        } 
    }

    @Override
    public List<Booking> retrieveAllBookingForStaff() throws AgileNoResultException {
        
        Query q = em.createQuery("SELECT b FROM Booking b"); 
        
        return q.getResultList();   
    }

    @Override
    public List<Booking> retrieveBookingsBySlotAttributes(Slot slot) {
        Query q = em.createQuery("SELECT b FROM Booking b, Slot slot WHERE slots MEMBER OF b.slots " + 
                                 "AND (slot.startDate = :inStartDate OR slot.endDate = :inEndDate " +
                                 //"OR slot.startTime = :inStartTime OR slot.endTime = :inEndTime " + 
                                 "OR slot.avaliabilityEnum = :inAvaliability) AND slot.entityStatusEnum = :inEntityStatusEnum");

        q.setParameter("inStartDate", slot.getStartDate());
        q.setParameter("inEndDate", slot.getEndDate());
        //q.setParameter("inStartTime", slot.getStartTime());
        //q.setParameter("inEndTime", slot.getEndTime());
        q.setParameter("inAvaliability", slot.getAvaliabilityEnum());
        q.setParameter("inEntityStatusEnum", slot.getEntityStatusEnum());

        return q.getResultList();    
    }

    @Override
    public Booking retrieveBookingByQrCode(String qrCode) {
        
        Query q = em.createQuery("SELECT b FROM Booking b WHERE b.qrCode = :inQrCode");
        
        q.setParameter("inQrCode", qrCode);
        
        return (Booking)q.getSingleResult();
    }

    //to improve the method of update whereby it can update the association.
    @Override
    public Booking updateBookingAttributes(Booking booking) throws Exception{       

        try
        {
            Booking oldBooking = retrieveBookingById(booking.getId());
            
            if(booking.getQrCode() != null)
            {
               oldBooking.setQrCode(booking.getQrCode()); 
            }                   

            if(booking.getBookingStatusEnum() != null)
            {
               oldBooking.setBookingStatusEnum(booking.getBookingStatusEnum()); 
            }
            
            if(booking.getEntityStatusEnum() != null)
            {
               oldBooking.setEntityStatusEnum(booking.getEntityStatusEnum());  
            }                   
            return booking;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }       
    }
    
    @Override
    //excute this after customerSessionLocal remove the booking
    public void deleteBooking(Long bId) throws Exception {

        try
        {
            Booking booking = retrieveBookingById(bId);
                        
//            booking.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            em.remove(booking);
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }
    
    //to test this method whether can pull this or not
    @Override
    public Listing getListingByQrCode(Long lId, String qrCode) throws Exception {

        Query q = em.createQuery("SELECT l FROM Listing l, Slot s, Booking b WHERE s MEMBER OF b.slots AND s MEMBER OF l.avaliableSlots AND b.qrCode = :inQrCode");
        q.setParameter("inQrCode", qrCode);
        
        Listing l = (Listing) q.getSingleResult();
        System.out.println(l.toString());

//        if(q.getSingleResult() == null)
//        {
//            throw new Exception("Listing not found");
//        }
        
        return l;
    }    
    
    @Override
    public Booking addSlot(Long bId, Slot slot) throws Exception 
    {
        try
        {
            Booking booking = retrieveBookingById(bId);
            
            Boolean hasExist = booking.getSlots().contains(slot);
            
            if(!hasExist)
            {     
                booking.getSlots().add(slot);
                
                return booking;
            }
            else
            {
                throw new DuplicateEntryException("This Booking (id:" + bId + ") already has the slot");
            }
        }        
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
      
    }

    @Override
    public Booking removeSlot(Long bId, Slot slot) throws Exception 
    {
        try
        {
            Booking booking = retrieveBookingById(bId);
            
            Boolean hasExist = booking.getSlots().contains(slot);
            
            if(!hasExist)
            {
                throw new AgileNoResultException("Booking does not have that slot");
            }
            else
            {
                //to also disassoicate on the Slot side
                 booking.getSlots().remove(slot);
                 
                 return booking;
            }
          
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }   
    }

    @Override
    //Assign New Customer only; not allowed to change Customer
    public Booking assignCustomer(Long bId, Customer customer) throws Exception{
        
        try
        {
            Booking booking = retrieveBookingById(bId); 
            
            if(booking.getGuest() != null)
            {
                throw new DuplicateEntryException("Booking already has a guest.");
            }
           
            //associate the new one
//            customerSessionLocal.addBooking(customer.getId(), booking);
            
            booking.setGuest(customer);
        
            return booking;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    
    @Override
    //Customer is being deleted and booking is to be removed with the slots
    public Booking removeCustomer(Long bId, Customer customer) throws Exception {
        
        try
        {
            Booking booking = retrieveBookingById(bId);
        
            booking.setGuest(null);

//            for(Slot s: booking.getSlot())
//            {
//                slotSessionLocal.removeBooking(s.getId(), booking);            
//                slotSessionLocal.deleteSlot(s.getId()); //for listing will be executed first, so only slotSessionLocal will call delete here.
//            }

            booking.setSlots(null);

            booking.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);

            return booking;    
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
 
    }


}
