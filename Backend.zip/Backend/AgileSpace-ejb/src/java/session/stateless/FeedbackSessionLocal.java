/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Customer;
import entity.Feedback;
import entity.Listing;
import java.util.List;
import javax.ejb.Local;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Local
public interface FeedbackSessionLocal 
{
    public Feedback createFeedback(Feedback feedback);

    public Feedback retrieveFeedbackbyId(Long fId) throws AgileNoResultException;
    
    public List<Feedback> retrieveFeedbackByAttributes(Feedback feedback);
    
    //for both active and non-active feedback
    public List<Feedback> retrieveAllFeedbackForStaff();

    public Feedback updateFeedback(Feedback feedback) throws Exception;

    public void deleteFeedback(Long fId) throws Exception; 
 
    public Feedback assignFeedbacker(Long fId, Customer customer) throws Exception;
    
    public Feedback removeCustomer(Long fId, Customer customer) throws Exception;
    
    public Feedback assignListing(Long fId, Listing listing) throws Exception;
    
    public Feedback removeListing(Long fId, Listing listing) throws Exception;     
}
