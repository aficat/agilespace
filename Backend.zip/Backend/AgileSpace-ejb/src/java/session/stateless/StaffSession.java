/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.Staff;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.StaffAccessRightEnum;
import util.exception.InvalidLoginCredentialException;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class StaffSession implements StaffSessionLocal {
    
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;
    
    @Override
    public Staff createStaff(Staff staff) {
        System.out.println("createStaff");
        em.persist(staff);
        em.flush();
        em.refresh(staff);
        System.out.println("createStaffEnd");
        
        return staff;
    }

    @Override
    public Staff retrieveStaffById(Long sId) throws AgileNoResultException {
        
        Staff staff = em.find(Staff.class, sId);
        
        if(staff != null)
        {
            return staff;
        }
        else
        {
            throw new AgileNoResultException("Staff with id: " + sId + " does not exist!");
        }  
    }

    @Override
    public Staff retrieveStaffByEmail(String email) throws AgileNoResultException {
        
        Query q = em.createQuery("SELECT s FROM Staff s WHERE s.email = :inEmail");
        
        q.setParameter("inEmail", email.toLowerCase());
        
        List<Staff> staffs = q.getResultList(); 
        if(staffs.isEmpty()){
           throw new AgileNoResultException("Staff with email: " + email + " does not exist!"); 
        }else{
            return staffs.get(0); 
        }
        /*
        if(staffs.get(0) != null)
        {
            return staffs.get(0);
        }
        else
        {
            throw new AgileNoResultException("Staff with email: " + email + " does not exist!");
        }    
                */
    }

    @Override
    public List<Staff> retrieveStaffByDepartment(StaffAccessRightEnum staffAccessRightEnum) throws AgileNoResultException {
        
        Query q = em.createQuery("SELECT s FROM Staff s WHERE s.staffAccessRightEnum = :inStaffAccessRightEnum");
        
        q.setParameter("inStaffAccessRightEnum", staffAccessRightEnum);
      
        return q.getResultList();  
    }

    @Override
    public List<Staff> retrieveAllStaff() {
        
        Query query = em.createQuery("SELECT s FROM Staff s");
        
        return query.getResultList();    
    }

    @Override
    public Staff updateStaff(Staff staff) throws Exception {
        try
        {
            Staff oldStaff = retrieveStaffById(staff.getId());
            
            if(staff.getEmail() != null)
            {
               oldStaff.setEmail(staff.getEmail()); 
            }
            
            if(staff.getPassword() != null)
            {
               oldStaff.setPassword(staff.getPassword()); 
            }
            
            if(staff.getStaffAccessRightEnum()!= null)
            {
                oldStaff.setStaffAccessRightEnum(staff.getStaffAccessRightEnum());
            }
            
            if(staff.getEntityStatusEnum() != null)
            {
                oldStaff.setEntityStatusEnum(staff.getEntityStatusEnum());
            }

            return oldStaff;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public void deleteStaff(Long sId) throws Exception {
        try
        {
            Staff staff = retrieveStaffById(sId);
            
//            staff.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);
            em.remove(staff); 
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }  
    }

    @Override
    public Staff login(String email, String password) throws Exception {
        
        try
        {
            Staff staff = retrieveStaffByEmail(email);
            
            if(staff.getPassword().equals(password))
            {
                return staff;
            }
            else
            {
                throw new InvalidLoginCredentialException("Username does not exist or invalid password!");
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }    
    }

    public void persist(Object object) {
        em.persist(object);
    }
    
    
}
