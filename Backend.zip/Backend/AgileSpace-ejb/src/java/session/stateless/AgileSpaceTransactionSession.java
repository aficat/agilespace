/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session.stateless;

import entity.AgileSpaceTransaction;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.EntityStatusEnum;
import util.exception.AgileNoResultException;

/**
 *
 * @author vincentyeo
 */
@Stateless
public class AgileSpaceTransactionSession implements AgileSpaceTransactionSessionLocal {
            
    @PersistenceContext(unitName = "AgileSpace-ejbPU")
    private EntityManager em;

    @Override
    public AgileSpaceTransaction createTransaction(AgileSpaceTransaction transaction) {
        em.persist(transaction);
        em.flush();
        em.refresh(transaction);
        
        return transaction;  
    }

    @Override
    public AgileSpaceTransaction retrieveTransactionById(Long tId) throws AgileNoResultException {

       AgileSpaceTransaction transaction = em.find(AgileSpaceTransaction.class, tId);
        
        if(transaction != null)
        {
            return transaction;
        }
        else
        {
            throw new AgileNoResultException("HostDoorSystem with id: " + tId + " does not exist!");
        } 
    }

    @Override
    public List<AgileSpaceTransaction> retrieveByAttribute(AgileSpaceTransaction transaction) {

        Query q = em.createQuery("SELECT t FROM AgileSpaceTransaction t WHERE  t.transactionDate =:inTransactionDate AND t.totalAmount = :inTotalAmount AND t.transactionTypeEnum = :inTransactionTypeEnum AND t.entityStatusEnum = :inEntityStatusEnum");
        q.setParameter("inTransactionDate", transaction.getTransactionDate());
        q.setParameter("inTotalAmount", transaction.getTotalAmount());
        q.setParameter("inTransactionTypeEnum", transaction.getTransactionTypeEnum());
        q.setParameter("inEntityStatusEnum", transaction.getEntityStatusEnum());
        //System.out.println(q.getResultList().size()+" q.resultListsize "); 
        return q.getResultList(); 
    }

    @Override
    public List<AgileSpaceTransaction> retrieveAllTransactionForStaff() {
        
        Query query = em.createQuery("SELECT t FROM AgileSpaceTransaction t");
        
        return query.getResultList();  
    }

    @Override
    public AgileSpaceTransaction updateTransaction(AgileSpaceTransaction transaction) throws Exception {
        try
        {   
            AgileSpaceTransaction oldTransaction = retrieveTransactionById(transaction.getId());
            
            if(transaction.getTransactionDate()!= null)
            {
               oldTransaction.setTransactionDate(transaction.getTransactionDate()); 
            }                   

            if(transaction.getTotalAmount() != null)
            {
               oldTransaction.setTotalAmount(transaction.getTotalAmount()); 
            }
                        
            if(transaction.getTransactionTypeEnum()!= null)
            {
               oldTransaction.setTransactionTypeEnum(transaction.getTransactionTypeEnum());  
            } 
            
            if(transaction.getEntityStatusEnum() != null)
            {
               oldTransaction.setEntityStatusEnum(transaction.getEntityStatusEnum());  
            }  
            
            return oldTransaction;
        }
        catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        } 
    }

    @Override
    public void deleteTransaction(Long tId) throws Exception {
        
        try 
        {
            AgileSpaceTransaction transaction = retrieveTransactionById(tId);
            em.remove(transaction);
//            transaction.setEntityStatusEnum(EntityStatusEnum.DEACTIVATED);            
        } 
        catch (Exception ex) 
        {
            throw new Exception(ex.getMessage());
        }
    }

}
