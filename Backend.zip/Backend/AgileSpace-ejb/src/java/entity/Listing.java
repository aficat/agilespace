
package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import util.enumeration.BuildingTypeEnum;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@Entity
public class Listing implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lId;
    @Enumerated(EnumType.STRING)
    private BuildingTypeEnum buildingTypeEnum;
    private String header;
    private String description;
        
    private Double price;
    private List<String> photoUrls;
    private String unitLevel;
    private String unitNumber;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
            
    //mapping
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer listingOwner;
    
    @OneToOne(mappedBy="listing", fetch = FetchType.EAGER)
    private HostDoorSystem hostDoorSystem;
    
    @OneToOne(fetch = FetchType.EAGER)
    private Location location;
    
    @OneToMany(mappedBy = "listing", fetch = FetchType.EAGER)
    private List<Feedback> feedbacks;
    
    @OneToMany(mappedBy = "listing", fetch = FetchType.EAGER)
    private List<Slot> avaliableSlots;

    public Listing() {
    }

    public Listing(BuildingTypeEnum buildingTypeEnum, String header, String description, Double price, List<String> photoUrls, String unitLevel, String unitNumber) {
        this.buildingTypeEnum = buildingTypeEnum;
        this.header = header;
        this.description = description;
        this.price = price;
        this.photoUrls = photoUrls;
        this.unitLevel = unitLevel;
        this.unitNumber = unitNumber;
        this.entityStatusEnum = entityStatusEnum.ACTIVATED;
        this.listingOwner = null;
        this.hostDoorSystem = null;
        this.location = null;
        this.feedbacks = new ArrayList<Feedback>();
        this.avaliableSlots = new ArrayList<Slot>();
    }    

    public Long getId() {
        return lId;
    }

    public void setId(Long id) {
        this.lId = id;
    }

    public BuildingTypeEnum getBuildingTypeEnum() {
        return buildingTypeEnum;
    }

    public void setBuildingTypeEnum(BuildingTypeEnum buildingTypeEnum) {
        this.buildingTypeEnum = buildingTypeEnum;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public List<String> getPhotoUrls() {
        return photoUrls;
    }

    public void setPhotoUrls(List<String> photoUrls) {
        this.photoUrls = photoUrls;
    }

    public String getUnitLevel() {
        return unitLevel;
    }

    public void setUnitLevel(String unitLevel) {
        this.unitLevel = unitLevel;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public Customer getListingOwner() {
        return listingOwner;
    }

    public void setListingOwner(Customer listingOwner) {
        this.listingOwner = listingOwner;
    }

    public HostDoorSystem getHostDoorSystem() {
        return hostDoorSystem;
    }

    public void setHostDoorSystem(HostDoorSystem hostDoorSystem) {
        this.hostDoorSystem = hostDoorSystem;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public List<Feedback> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<Feedback> feedbacks) {
        this.feedbacks = feedbacks;
    }

    public List<Slot> getAvaliableSlots() {
        return avaliableSlots;
    }

    public void setAvaliableSlots(List<Slot> avaliableSlots) {
        this.avaliableSlots = avaliableSlots;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (lId != null ? lId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the lId fields are not set
        if (!(object instanceof Listing)) {
            return false;
        }
        Listing other = (Listing) object;
        if ((this.lId == null && other.lId != null) || (this.lId != null && !this.lId.equals(other.lId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Listing[ id=" + lId + 
                               " buildingTypeEnum=" + buildingTypeEnum +
                               " header=" + header +
                               " description=" + description +
                               " price=" + price +
                               " unitLevel=" + unitLevel +
                               " unitNumber=" + unitNumber +
                               " entityStatusEnum=" + entityStatusEnum +
                               " ]";
    }
    
}
