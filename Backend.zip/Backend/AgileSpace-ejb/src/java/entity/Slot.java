
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import util.enumeration.AvaliabilityEnum;
import util.enumeration.EntityStatusEnum;
import java.sql.Timestamp;

/**
 *
 * @author vincentyeo
 */
@Entity
public class Slot implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    
    /*
    @Temporal(TemporalType.TIME)
    private Date startTime;
    
    @Temporal(TemporalType.TIME)
    private Date endTime;
    */
    @Enumerated(EnumType.STRING)
    private AvaliabilityEnum avaliabilityEnum;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
    //mapping
    @ManyToOne(fetch = FetchType.EAGER)
    private Booking booking;
    
    @ManyToOne(fetch = FetchType.EAGER)
    private Listing listing;
    
    public Slot()
    {
        
    }

    public Slot(Date startDate, Date endDate,AvaliabilityEnum avaliabilityEnum) {
        this.startDate = startDate; 
        this.endDate = endDate;
        //this.startTime = startTime;
        //this.endTime = endTime;
        this.avaliabilityEnum = avaliabilityEnum;
        this.entityStatusEnum = EntityStatusEnum.ACTIVATED;
        this.booking = null;
        this.listing = null;
    }
        

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
/*
    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
*/
    public AvaliabilityEnum getAvaliabilityEnum() {
        return avaliabilityEnum;
    }

    public void setAvaliabilityEnum(AvaliabilityEnum avaliabilityEnum) {
        this.avaliabilityEnum = avaliabilityEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public Listing getListing() {
        return listing;
    }

    public void setListing(Listing listing) {
        this.listing = listing;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Slot)) {
            return false;
        }
        Slot other = (Slot) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Slot[ id=" + id + " startDate=" + startDate.toString() + " endDate=" + endDate.toString() +/* " startTime= " + startTime.toString() +" endTime="+ endTime.toString()+*/" ]";
    }
    
}
