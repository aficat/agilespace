
package entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@Entity
public class HostDoorSystem implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long hId; 
    private String email;
    private String password;
    private String masterQrCode; //for emergency unlocking
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
    //mapping
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer owner;
    
    @OneToOne(fetch = FetchType.EAGER)
    private Listing listing;

    public HostDoorSystem() {
    }

    public HostDoorSystem(String email, String password, String masterQrCode) {
        this.email = email;
        this.password = password;
        this.masterQrCode = masterQrCode;
        this.entityStatusEnum = entityStatusEnum.ACTIVATED;
        this.owner = null;
        this.listing = null;
    }
       
    public Long getId() {
        return hId;
    }

    public void setId(Long id) {
        this.hId = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMasterQrCode() {
        return masterQrCode;
    }

    public void setMasterQrCode(String masterQrCode) {
        this.masterQrCode = masterQrCode;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public Customer getOwner() {
        return owner;
    }

    public void setOwner(Customer owner) {
        this.owner = owner;
    }

    public Listing getListing() {
        return listing;
    }

    public void setListing(Listing listing) {
        this.listing = listing;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (hId != null ? hId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the hId fields are not set
        if (!(object instanceof HostDoorSystem)) {
            return false;
        }
        HostDoorSystem other = (HostDoorSystem) object;
        if ((this.hId == null && other.hId != null) || (this.hId != null && !this.hId.equals(other.hId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.HostDoorSystem[ id=" + hId + 
                                       "email=" + email +
                                       " password=" + password +
                                       " masterQrCode=" + masterQrCode +
                                       " entityStatusEnum=" + entityStatusEnum +
                                       " ]";
    }
    
}
