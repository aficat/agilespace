/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import util.enumeration.EntityStatusEnum;
import util.enumeration.FeedbackTypeEnum;

/**
 *
 * @author vincentyeo
 */
@Entity
public class Feedback implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long fId;
    private Integer rating;
    @Enumerated(EnumType.STRING)
    private FeedbackTypeEnum feedbackTypeEnum;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    private String remarks;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date postingDateTime;
   
    //mapping
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer feedbacker; //one giving the feedback
    
    @ManyToOne(fetch = FetchType.EAGER)
    private Listing listing;

    public Feedback() {
    }

    public Feedback(Integer rating, FeedbackTypeEnum feedbackTypeEnum, String remarks, Date postingDateTime) {
        this.rating = rating;
        this.feedbackTypeEnum = feedbackTypeEnum;
        this.entityStatusEnum = entityStatusEnum.ACTIVATED;
        this.remarks = remarks;
        this.postingDateTime = postingDateTime;
        this.feedbacker = null;
        this.listing = null;
    }          
    
    public Long getId() {
        return fId;
    }

    public void setId(Long id) {
        this.fId = id;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public FeedbackTypeEnum getFeedbackTypeEnum() {
        return feedbackTypeEnum;
    }

    public void setFeedbackTypeEnum(FeedbackTypeEnum feedbackTypeEnum) {
        this.feedbackTypeEnum = feedbackTypeEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public Date getPostingDateTime() {
        return postingDateTime;
    }

    public void setPostingDateTime(Date postingDateTime) {
        this.postingDateTime = postingDateTime;
    }

    public Customer getFeedbacker() {
        return feedbacker;
    }

    public void setFeedbacker(Customer feedbacker) {
        this.feedbacker = feedbacker;
    }

    public Listing getListing() {
        return listing;
    }

    public void setListing(Listing listing) {
        this.listing = listing;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fId != null ? fId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the fId fields are not set
        if (!(object instanceof Feedback)) {
            return false;
        }
        Feedback other = (Feedback) object;
        if ((this.fId == null && other.fId != null) || (this.fId != null && !this.fId.equals(other.fId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Feedback[ id=" + fId + 
                                " rating=" + rating +
                                " feedbackTypeEnum=" + feedbackTypeEnum +
                                " entityStatusEnum=" + entityStatusEnum +
                                " remarks=" + remarks +
                                " postingDateTime=" + postingDateTime.toString() +
                                " ]";
    }
    
}
