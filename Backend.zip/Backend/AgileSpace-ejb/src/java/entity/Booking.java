
package entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import util.enumeration.BookingStatusEnum;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@Entity
public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bId;
    private String qrCode;
    @Enumerated(EnumType.STRING)
    private BookingStatusEnum bookingStatusEnum;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
    //mapping
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer guest;
    
    @OneToMany(mappedBy = "booking", fetch = FetchType.EAGER)
    private List<Slot> slots;

    public Booking() {
    }

    public Booking(String qrCode, BookingStatusEnum bookingStatusEnum, EntityStatusEnum entityStatusEnum) {
        this.qrCode = qrCode;
        this.bookingStatusEnum = bookingStatusEnum;
        this.entityStatusEnum = entityStatusEnum.ACTIVATED;
        this.guest = null;
        this.slots = null;
    }      

    public Long getId() {
        return bId;
    }

    public void setId(Long id) {
        this.bId = id;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public BookingStatusEnum getBookingStatusEnum() {
        return bookingStatusEnum;
    }

    public void setBookingStatusEnum(BookingStatusEnum bookingStatusEnum) {
        this.bookingStatusEnum = bookingStatusEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public Customer getGuest() {
        return guest;
    }

    public void setGuest(Customer guest) {
        this.guest = guest;
    }

    public List<Slot> getSlots() {
        return slots;
    }

    public void setSlots(List<Slot> slots) {
        this.slots = slots;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bId != null ? bId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the bId fields are not set
        if (!(object instanceof Booking)) {
            return false;
        }
        Booking other = (Booking) object;
        if ((this.bId == null && other.bId != null) || (this.bId != null && !this.bId.equals(other.bId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Booking[ id=" + bId + 
                               " qrCode=" + qrCode +   
                               " bookingStatusEnum=" + bookingStatusEnum +
                               " entityStatusEnum=" + entityStatusEnum + " ]";
    }
    
}
