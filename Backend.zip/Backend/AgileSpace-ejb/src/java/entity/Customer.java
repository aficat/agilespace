
package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@Entity
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cId;    
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String phoneNum;
    private List<String> photoUrls;
    private Integer rating;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
    //mapping
    @OneToMany(mappedBy = "listingOwner", fetch = FetchType.EAGER)
    private List<Listing> listings;
    
    @OneToMany(mappedBy = "guest", fetch = FetchType.EAGER)
    private List<Booking> bookings;
    
    @OneToMany(mappedBy = "feedbacker", fetch = FetchType.EAGER)
    private List<Feedback> feedbacks;
    
//    @OneToMany(mappedBy = "customer")
//    private List<Transaction> transactions;
    
    @OneToMany(mappedBy = "owner", fetch = FetchType.EAGER)
    private List<HostDoorSystem> hostDoorSystems;

    public Customer() {
    }

    public Customer(String email, String password, String firstName, String lastName, String phoneNum) {
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNum = phoneNum;
        this.photoUrls = new ArrayList<>();       
        this.entityStatusEnum = entityStatusEnum.ACTIVATED;
        this.listings = new ArrayList<Listing>();
        this.bookings = new ArrayList<Booking>();
        this.feedbacks = new ArrayList<Feedback>();
        this.hostDoorSystems = new ArrayList<HostDoorSystem>();
        this.rating = getRating();
    }        

    public Long getId() {
        return cId;
    }

    public void setId(Long cid) {
        this.cId = cid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public List<String> getPhotoUrls() {
        return photoUrls;
    }

    public void setPhotoUrls(List<String> photoUrls) {
        this.photoUrls = photoUrls;
    }    

    public Integer getRating() {
        rating = 0;
        
        if(feedbacks != null || !feedbacks.isEmpty())
        {
            for (Feedback f : feedbacks) {            
                rating += f.getRating();
            }
        
            if(this.feedbacks.size() != 0)
            {
               rating /= this.feedbacks.size();  
            }        
        }
               
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public List<Listing> getListings() {
        return listings;
    }

    public void setListings(List<Listing> listings) {
        this.listings = listings;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    public List<Feedback> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<Feedback> feedbacks) {
        this.feedbacks = feedbacks;
    }

    public List<HostDoorSystem> getHostDoorSystems() {
        return hostDoorSystems;
    }

    public void setHostDoorSystems(List<HostDoorSystem> hostDoorSystems) {
        this.hostDoorSystems = hostDoorSystems;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cId != null ? cId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the cId fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.cId == null && other.cId != null) || (this.cId != null && !this.cId.equals(other.cId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Customer[ id=" + cId +
                               " email=" + email +
                               " password=" + password +
                               " firstName=" + firstName +
                               " lastName=" + lastName +
                               " phoneNum=" + phoneNum +       
                               " entityStatusEnum=" + entityStatusEnum +
                               " rating=" + rating +                 
                               " ]";
    }
    
}
