
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import util.enumeration.EntityStatusEnum;
import util.enumeration.TransactionTypeEnum;

@Entity
public class AgileSpaceTransaction implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date transactionDate;
    
    private Double totalAmount;
    @Enumerated(EnumType.STRING)
    private TransactionTypeEnum transactionTypeEnum;
    @Enumerated(EnumType.STRING)
    private EntityStatusEnum entityStatusEnum;
    
    @ManyToOne(fetch = FetchType.EAGER)
    private Customer customer;
    
    @OneToOne(fetch = FetchType.EAGER)
    private Booking booking;

    public AgileSpaceTransaction() {
    }

    public AgileSpaceTransaction(Date transactionDate, Double totalAmount, TransactionTypeEnum transactionTypeEnum, EntityStatusEnum entityStatusEnum) {
        this.transactionDate = transactionDate;
        this.totalAmount = totalAmount;
        this.transactionTypeEnum = transactionTypeEnum;
        this.entityStatusEnum = entityStatusEnum;
        this.customer = null;
        this.booking = null;
    }
        
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public TransactionTypeEnum getTransactionTypeEnum() {
        return transactionTypeEnum;
    }

    public void setTransactionTypeEnum(TransactionTypeEnum transactionTypeEnum) {
        this.transactionTypeEnum = transactionTypeEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AgileSpaceTransaction)) {
            return false;
        }
        AgileSpaceTransaction other = (AgileSpaceTransaction) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Transaction[ id=" + id + 
                                   " transactionDate = " + transactionDate +
                                   " totalAmount = " + totalAmount +
                                   " transactionTypeEnum = " + transactionTypeEnum +
                                   " entityStatusEnum = " + entityStatusEnum + " ]";
    }
    
}
