/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Customer;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Location;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.CustomerSessionLocal;
import session.stateless.HostDoorSystemSessionLocal;
import session.stateless.ListingSessionLocal;
import util.enumeration.EntityStatusEnum;
import util.exception.AgileNoResultException;
import webservices.restful.datamodel.customerRsp;
import webservices.restful.datamodel.hostDoorSystemsRsp;
import webservices.restful.datamodel.listingRsp;


/**
 * REST Web Service
 *
 * @author aw chin siong
 */
@Path("hostDoorSystems")
public class HostDoorSystemsResource {

    @EJB
    private HostDoorSystemSessionLocal hostDoorSystemSessionLocal;
    @EJB
    private CustomerSessionLocal customerSessionLocal;
    @EJB
    private ListingSessionLocal listingSessionLocal; 
    
    @POST
    @Path("/customer/{customerid}/listing/{listingsId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createHostDoorSystemAccount(@PathParam("customerid") Long cId, @PathParam("listingsId") Long lId, HostDoorSystem h) {
       try{

            h.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
            Customer cust = customerSessionLocal.retrieveCustomerById(cId);
            Listing list = listingSessionLocal.retrieveListingById(lId);

            //generate email 
            String email = createHostDoorEmail(cust, list, list.getLocation());
            h.setEmail(email.toLowerCase());
            //generate password 
            String password = randomGenerator(9);
            h.setPassword(password.trim());
            //generate qrCode 
            String qrCode = qrCodeGenerator(cust, list, list.getLocation());
            h.setMasterQrCode(qrCode);

            HostDoorSystem hostDoor = hostDoorSystemSessionLocal.createHostDoorSystemAccount(h);

            hostDoor = hostDoorSystemSessionLocal.assignCustomer(hostDoor.getId(), cust);
            hostDoor = hostDoorSystemSessionLocal.assignListing(hostDoor.getId(), list);

            customerSessionLocal.addHostDoorSystem(cId, hostDoor);
            listingSessionLocal.assignHostDoorSystem(lId, hostDoor);

            hostDoorSystemsRsp hostDoorSystem = wrapHostDoorSystem(hostDoor);
            return Response.status(200).entity(hostDoorSystem).build();
        } catch (Exception ex) {
            JsonObject exception = Json.createObjectBuilder().add("error", ex.getMessage()).build();
             return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
         }
    } 
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getHostDoorSystemAccount(@PathParam("id") Long hId) {
        try {
            HostDoorSystem h = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountById(hId);
            
            hostDoorSystemsRsp hostDoorSystem = wrapHostDoorSystem(h);
        
        return Response.status(200).entity(hostDoorSystem).build();
        } catch (AgileNoResultException e) {
            JsonObject exception = Json.createObjectBuilder().add("error", "HostDoorSystem Not found").build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllHostDoorSystem() {
       //System.out.println("enter");
        List<HostDoorSystem> results = hostDoorSystemSessionLocal.retrieveAllHostDoorSystemAccount();

        List<hostDoorSystemsRsp> hostDoorSystems = wrapHostDoorSystems(results);

        GenericEntity<List<hostDoorSystemsRsp>> entity = new GenericEntity<List<hostDoorSystemsRsp>>(hostDoorSystems) {
        };
        //System.out.println("finish");
        return Response.status(200).entity(entity).build();
    } //end getAllHostDoorSystem

    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response retrieveHostDoorSystem(@QueryParam("email") String hEmail) {
        if (!hEmail.isEmpty()) {
            try {
            HostDoorSystem h = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountByEmail(hEmail.trim().toLowerCase());
                hostDoorSystemsRsp hostDoorSystem = wrapHostDoorSystem(h);

                return Response.status(200).entity(hostDoorSystem).build();
            } catch (AgileNoResultException e) {
                JsonObject exception = Json.createObjectBuilder().add("error", "HostDoorSystem Not found").build();
                return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
            }
        }else{
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "No query conditions")
                    .build();
            return Response.status(400).entity(exception).build();
        }
    }

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response hostDoorSystemLogin(HostDoorSystem h) {
        if (h != null && !h.getEmail().trim().isEmpty() && !h.getPassword().trim().isEmpty()) {
            try {
                //valid here

                HostDoorSystem host = hostDoorSystemSessionLocal.login(h.getEmail().trim().toLowerCase(), h.getPassword().trim());
                hostDoorSystemsRsp hostDoorSystem = wrapHostDoorSystem(host);

                return Response.status(200).entity(hostDoorSystem).build();
            } catch (Exception ex) {
                JsonObject exception = Json.createObjectBuilder()
                        .add("error", ex.getMessage())
                        .build();

                return Response.status(400).entity(exception).build();
            }
        } else {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "No fields supplied")
                    .build();

            return Response.status(400).entity(exception).build();
        }

    }    
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editHostDoorSystem(@PathParam("id") Long hId, HostDoorSystem h) {
        h.setId(hId);
        try {
            if (h.getEmail() != null || h.getEmail().length() != 0) {
               
                h.setEmail(h.getEmail().trim().toLowerCase());
            }
            if (h.getPassword() != null || h.getPassword().length() != 0) {
                h.setPassword(h.getPassword().trim());
            }
            hostDoorSystemSessionLocal.updateHostDoorSystemAccount(h);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Not found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end editHostDoorSystem
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteHostDoorSystem(@PathParam("id") Long hId) {
        try {
            HostDoorSystem host = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountById(hId);
            Customer owner = host.getOwner();
            Listing list = host.getListing();
            if (owner != null) {
                if (owner.getHostDoorSystems() != null) {
                    customerSessionLocal.removeHostDoorSystem(owner.getId(), host);
                }
                hostDoorSystemSessionLocal.removeCustomer(hId, owner);
            }
            if (list != null){
                if(list.getHostDoorSystem() != null) {
                    listingSessionLocal.removeHostDoorSystem(list.getId(), host);
                }
                hostDoorSystemSessionLocal.removeListing(hId, list);
            }            
            hostDoorSystemSessionLocal.deleteHostDoorSystemAccount(hId);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Not found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteHostDoorSystem
    @DELETE
    @Path("/{hostDoorSystem_id}/customer/{customer_id}")
     @Produces(MediaType.APPLICATION_JSON)
     public Response removeCustomer(@PathParam("hostDoorSystem_id") Long hId,
           @PathParam("customer_id") Long cId) {
       try {
             //Remove Customer from hostDoorSystem 
           //System.out.println("start");
             Customer customer = customerSessionLocal.retrieveCustomerById(cId);
          
           //System.out.println("after retrieve");
           hostDoorSystemSessionLocal.removeCustomer(hId, customer);
           //System.out.println("after remove");
             //Remove hostDoorSystem            
           //System.out.println("before hostDoor");
           HostDoorSystem hostDoor = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountById(hId);
           //System.out.println("get hostDoor");
           customerSessionLocal.removeHostDoorSystem(cId, hostDoor);
           //System.out.println("remove hostDoor");
             return Response.status(204).build();

       } catch (Exception e) {
             JsonObject exception = Json.createObjectBuilder()
                   .add("error", e.getMessage())
                     .build();
             return Response.status(404).entity(exception)
                     .type(MediaType.APPLICATION_JSON).build();
         }
     }

    @DELETE
    @Path("/{hostDoorSystem_id}/listing/{listing_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeListing(@PathParam("hostDoorSystem_id") Long hId,
            @PathParam("listing_id") Long lId){
        try{  
            //Retrieve host Door system and listing 
            HostDoorSystem hostDoor = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountById(hId);
            Listing listing = listingSessionLocal.retrieveListingById(lId); 
           
            //Remove listing from hostDoor  
            hostDoorSystemSessionLocal.removeListing(hId, hostDoor.getListing());
            //Remove hostDoor from listing 
            listingSessionLocal.removeHostDoorSystem(lId, hostDoor); 
            
            //Since HostDoor is one to one with listing, delete listing 
            listingSessionLocal.deleteListing(listing.getId());
            
            return Response.status(204).build();
        }catch(Exception e){
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Not found")
                    .build();
            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    }

    private List<hostDoorSystemsRsp> wrapHostDoorSystems(List<HostDoorSystem> results)
    {
        List<hostDoorSystemsRsp> hostDoorSystems = new ArrayList<>();
        results.forEach((hostDoor) -> {
              hostDoorSystemsRsp h= wrapHostDoorSystem(hostDoor);
              hostDoorSystems.add(h);
        });      

        return hostDoorSystems;        
    }   
    
    private hostDoorSystemsRsp wrapHostDoorSystem(HostDoorSystem hostDoorSystem)
    {
        customerRsp customer = null;
        listingRsp listing = null;
        
        if(hostDoorSystem.getOwner() != null)
        {
            customer = new customerRsp(hostDoorSystem.getOwner().getId(),
                    hostDoorSystem.getOwner().getEmail(),
                    hostDoorSystem.getOwner().getPassword(),
                    hostDoorSystem.getOwner().getFirstName(),
                    hostDoorSystem.getOwner().getLastName(),
                    hostDoorSystem.getOwner().getPhoneNum(),
                    hostDoorSystem.getOwner().getRating(),
                    hostDoorSystem.getOwner().getEntityStatusEnum()
            );
        }
        
        if(hostDoorSystem.getListing() != null)
        {
            listing = new listingRsp(hostDoorSystem.getListing().getId(),
                                    hostDoorSystem.getListing().getBuildingTypeEnum(),
                                    hostDoorSystem.getListing().getHeader(),
                                    hostDoorSystem.getListing().getDescription(),
                                    hostDoorSystem.getListing().getPrice(),
                                    hostDoorSystem.getListing().getUnitLevel(),
                                    hostDoorSystem.getListing().getUnitNumber(),
                                    hostDoorSystem.getListing().getEntityStatusEnum()
            );
        }
        
        hostDoorSystemsRsp hostDoor = new hostDoorSystemsRsp(hostDoorSystem.getId(), hostDoorSystem.getEmail(), hostDoorSystem.getPassword(), hostDoorSystem.getMasterQrCode(), hostDoorSystem.getEntityStatusEnum());
        hostDoor.setOwner(customer);
        hostDoor.setListing(listing);
        
        return hostDoor;
    } 
    private String createHostDoorEmail(Customer c, Listing l, Location loc) {
        //Combine c.firstname, unit level, unit number, postalCode and concat @agileSpace.com 
        String email = "qr";
        if (c != null && c.getFirstName() != null) {
            email = email.concat(c.getFirstName());
        }
        if (l != null && l.getUnitLevel() != null) {
            email = email.concat(l.getUnitLevel());
        }
        if (l != null && l.getUnitNumber() != null) {
            email = email.concat(l.getUnitNumber());
        }
        if (loc != null && loc.getPostalCode() != null) {
            email = email.concat(loc.getPostalCode());
        }
        String word = randomGenerator(5);
        email = email.concat(word);
        email = email.concat("@agilespace.com");

        return email.trim();

    }

    private String randomGenerator(int number) {
        String ALPHA_NUMERIC_STRING = "abcdefghijklmnopqrsntuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~!@#$%^&*(){}";
        StringBuilder word = new StringBuilder();
        for (int i = 0; i < number; i++) {            
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            word.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return word.toString();
    }

    private String qrCodeGenerator(Customer c, Listing l, Location loc) {
        {
            //Combine c.firstname, unit level, unit number, postalCode and date 
            String email = "qr";
            if (c != null && c.getFirstName() != null) {
                email = email.concat(c.getFirstName());
            }
            String word1 = randomGenerator(5);
            email = email.concat(word1);
            if (l != null && l.getUnitLevel() != null) {
                email = email.concat(l.getUnitLevel());
            }
            String word2 = randomGenerator(5);
            email = email.concat(word2);
            if (l != null && l.getUnitNumber() != null) {
                email = email.concat(l.getUnitNumber());
            }
            String word3 = randomGenerator(5);
            email = email.concat(word3);
            if (loc != null && loc.getPostalCode() != null) {
                email = email.concat(loc.getPostalCode());
            }
            String word4 = randomGenerator(5);
            email = email.concat(word4);
            Date currDate = new Date();
            email = email.concat(currDate.toString());

            return email.trim();

        }
    }    
}
