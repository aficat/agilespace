/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;


import entity.Customer;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.BuildingTypeEnum;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "listingRsp", propOrder = {
    "lId",
    "buildingTypeEnum",
    "header",
    "description",
    "price",
    "unitLevel",
    "unitNumber",
    "entityStatusEnum",
    "photoUrls",
    "listingOwner",
    "hostDoorSystem",
    "location",
    "feedbacks",
    "avaliableSlots"
})
public class listingRsp {
    private Long lId;
    private BuildingTypeEnum buildingTypeEnum;
    private String header;
    private String description;        
    private Double price;     
    private String unitLevel;
    private String unitNumber;
    private EntityStatusEnum entityStatusEnum;
    private List<String> photoUrls;
    private customerRsp listingOwner;
    private hostDoorSystemsRsp hostDoorSystem;
    private locationRsp location;
    private List<feedbackRsp> feedbacks;
    private List<slotRsp> avaliableSlots;    
    
    public listingRsp() {
    }

    public listingRsp(Long lId, BuildingTypeEnum buildingTypeEnum, String header, String description, Double price, String unitLevel, String unitNumber, EntityStatusEnum entityStatusEnum) {
        this.lId = lId;
        this.buildingTypeEnum = buildingTypeEnum;
        this.header = header;
        this.description = description;
        this.price = price;
        this.unitLevel = unitLevel;
        this.unitNumber = unitNumber;
        this.entityStatusEnum = entityStatusEnum;
    }
    
    public Long getlId() {
        return lId;
    }

    public void setlId(Long lId) {
        this.lId = lId;
    }

    public BuildingTypeEnum getBuildingTypeEnum() {
        return buildingTypeEnum;
    }

    public void setBuildingTypeEnum(BuildingTypeEnum buildingTypeEnum) {
        this.buildingTypeEnum = buildingTypeEnum;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getUnitLevel() {
        return unitLevel;
    }

    public void setUnitLevel(String unitLevel) {
        this.unitLevel = unitLevel;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public List<String> getPhotoUrls() {
        return photoUrls;
    }

    public void setPhotoUrls(List<String> photoUrls) {
        this.photoUrls = photoUrls;
    }

    public customerRsp getListingOwner() {
        return listingOwner;
    }

    public void setListingOwner(customerRsp  listingOwner) {
        this.listingOwner = listingOwner;
    }

    public hostDoorSystemsRsp getHostDoorSystem() {
        return hostDoorSystem;
    }

    public void setHostDoorSystem(hostDoorSystemsRsp hostDoorSystem) {
        this.hostDoorSystem = hostDoorSystem;
    }

    public locationRsp getLocation() {
        return location;
    }

    public void setLocation(locationRsp location) {
        this.location = location;
    }

    public List<feedbackRsp> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<feedbackRsp> feedbacks) {
        this.feedbacks = feedbacks;
    }

    public List<slotRsp> getAvaliableSlots() {
        return avaliableSlots;
    }

    public void setAvaliableSlots(List<slotRsp> avaliableSlots) {
        this.avaliableSlots = avaliableSlots;
    }
    
    
}
