/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.BookingStatusEnum;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "bookingRsp", propOrder = {
    "bId",
    "qrCode",
    "bookingStatusEnum",
    "entityStatusEnum",
    "guest",
    "slots"
})
public class bookingRsp {
    private Long bId;
    private String qrCode;
    private BookingStatusEnum bookingStatusEnum;
    private EntityStatusEnum entityStatusEnum;
    private customerRsp guest;
    private List<slotRsp> slots;    

    public bookingRsp() {
    }
   
    public bookingRsp(Long bId, String qrCode, BookingStatusEnum bookingStatusEnum, EntityStatusEnum entityStatusEnum) {
        this.bId = bId;
        this.qrCode = qrCode;
        this.bookingStatusEnum = bookingStatusEnum;
        this.entityStatusEnum = entityStatusEnum;
    }

    public Long getbId() {
        return bId;
    }

    public void setbId(Long bId) {
        this.bId = bId;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public BookingStatusEnum getBookingStatusEnum() {
        return bookingStatusEnum;
    }

    public void setBookingStatusEnum(BookingStatusEnum bookingStatusEnum) {
        this.bookingStatusEnum = bookingStatusEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public customerRsp getGuest() {
        return guest;
    }

    public void setGuest(customerRsp guest) {
        this.guest = guest;
    }

    public List<slotRsp> getSlots() {
        return slots;
    }

    public void setSlots(List<slotRsp> slots) {
        this.slots = slots;
    }
    
    
}
