/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "hostDoorSystemsRsp", propOrder = {
    "hId",
    "email",
    "password",
    "masterQrCode",
    "entityStatusEnum",
    "owner",
    "listing"
})
public class hostDoorSystemsRsp {
    private Long hId; 
    private String email;
    private String password;
    private String masterQrCode; //for emergency unlocking
    private EntityStatusEnum entityStatusEnum;
    private customerRsp owner;
    private listingRsp listing;

    public hostDoorSystemsRsp() {
    }

    public hostDoorSystemsRsp(Long hId, String email, String password, String masterQrCode, EntityStatusEnum entityStatusEnum) {
        this.hId = hId;
        this.email = email;
        this.password = password;
        this.masterQrCode = masterQrCode;
        this.entityStatusEnum = entityStatusEnum;
    }

    public Long gethId() {
        return hId;
    }

    public void sethId(Long hId) {
        this.hId = hId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMasterQrCode() {
        return masterQrCode;
    }

    public void setMasterQrCode(String masterQrCode) {
        this.masterQrCode = masterQrCode;
    }

//    public EntityStatusEnum getEntityStatusEnum() {
//        return entityStatusEnum;
//    }
//
//    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
//        this.entityStatusEnum = entityStatusEnum;
//    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public customerRsp getOwner() {
        return owner;
    }

    public void setOwner(customerRsp owner) {
        this.owner = owner;
    }

    public listingRsp getListing() {
        return listing;
    }

    public void setListing(listingRsp listing) {
        this.listing = listing;
    }
        
}
