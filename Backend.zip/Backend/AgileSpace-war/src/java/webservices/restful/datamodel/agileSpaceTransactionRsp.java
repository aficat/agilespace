/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.EntityStatusEnum;
import util.enumeration.TransactionTypeEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "agileSpaceTransactionRsp", propOrder = {
    "tId",
    "transactionDate",
    "totalAmount",
    "transactionTypeEnum",
    "entityStatusEnum",
    "customer",
    "booking"
})
public class agileSpaceTransactionRsp {
    private Long tId;
    private Date transactionDate;    
    private Double totalAmount;
    private TransactionTypeEnum transactionTypeEnum;
    private EntityStatusEnum entityStatusEnum;
    private customerRsp customer;
    private bookingRsp booking;    

    public agileSpaceTransactionRsp() {
    }
    
    public agileSpaceTransactionRsp(Long tId, Date transactionDate, Double totalAmount, TransactionTypeEnum transactionTypeEnum, EntityStatusEnum entityStatusEnum) {
        this.tId = tId;
        this.transactionDate = transactionDate;
        this.totalAmount = totalAmount;
        this.transactionTypeEnum = transactionTypeEnum;
        this.entityStatusEnum = entityStatusEnum;
    }

    public Long gettId() {
        return tId;
    }

    public void settId(Long tId) {
        this.tId = tId;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
//        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        this.transactionDate = transactionDate;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public TransactionTypeEnum getTransactionTypeEnum() {
        return transactionTypeEnum;
    }

    public void setTransactionTypeEnum(TransactionTypeEnum transactionTypeEnum) {
        this.transactionTypeEnum = transactionTypeEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public customerRsp getCustomer() {
        return customer;
    }

    public void setCustomer(customerRsp customer) {
        this.customer = customer;
    }

    public bookingRsp getBooking() {
        return booking;
    }

    public void setBooking(bookingRsp booking) {
        this.booking = booking;
    }
}
