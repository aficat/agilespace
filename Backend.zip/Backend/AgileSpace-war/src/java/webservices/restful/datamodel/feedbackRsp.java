/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.EntityStatusEnum;
import util.enumeration.FeedbackTypeEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "feedbackRsp", propOrder = {
    "fId",
    "rating",
    "feedbackTypeEnum",
    "entityStatusEnum",
    "remarks",
    "postingDateTime",
    "feedbacker",
    "listing"
})
public class feedbackRsp {
    
    private Long fId;
    private Integer rating;
    private FeedbackTypeEnum feedbackTypeEnum;
    private EntityStatusEnum entityStatusEnum;
    private String remarks;
    private Date postingDateTime;
    private customerRsp feedbacker; //one giving the feedback
    private listingRsp listing;    

    public feedbackRsp() {
    }

    public feedbackRsp(Long fId, Integer rating, FeedbackTypeEnum feedbackTypeEnum, EntityStatusEnum entityStatusEnum, String remarks, Date postingDateTime) {
        this.fId = fId;
        this.rating = rating;
        this.feedbackTypeEnum = feedbackTypeEnum;
        this.entityStatusEnum = entityStatusEnum;
        this.remarks = remarks;
        this.postingDateTime = postingDateTime;
    }

    public Long getfId() {
        return fId;
    }

    public void setfId(Long fId) {
        this.fId = fId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public FeedbackTypeEnum getFeedbackTypeEnum() {
        return feedbackTypeEnum;
    }

    public void setFeedbackTypeEnum(FeedbackTypeEnum feedbackTypeEnum) {
        this.feedbackTypeEnum = feedbackTypeEnum;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getPostingDateTime() {
        return postingDateTime;
    }

    public void setPostingDateTime(Date postingDateTime) {
        this.postingDateTime = postingDateTime;
    }

    public customerRsp getFeedbacker() {
        return feedbacker;
    }

    public void setFeedbacker(customerRsp feedbacker) {
        this.feedbacker = feedbacker;
    }

    public listingRsp getListing() {
        return listing;
    }

    public void setListing(listingRsp listing) {
        this.listing = listing;
    }
        
}
