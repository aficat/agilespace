/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "customerRsp", propOrder = {
    "id",
    "email",
    "password",
    "firstName",
    "lastName",
    "phoneNum",
    "rating",
    "entityStatusEnum",
    "photoUrls",
    "listings",
    "bookings",
    "feedbacks",
    "hostDoorSystems"
})
public class customerRsp {
   
    private Long id;
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String phoneNum;
    private Integer rating;
    private EntityStatusEnum entityStatusEnum;
    private List<String> photoUrls;
    private List<listingRsp> listings;
    private List<bookingRsp> bookings;
    private List<feedbackRsp> feedbacks;
    private List<hostDoorSystemsRsp> hostDoorSystems;    


    public customerRsp() {
    }  

    public customerRsp(Long id, String email, String password, String firstName, String lastName, String phoneNum, Integer rating, EntityStatusEnum entityStatusEnum) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNum = phoneNum;
        this.rating = rating;
        this.entityStatusEnum = entityStatusEnum;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }    

    public List<listingRsp> getListings() {
        return listings;
    }

    public void setListings(List<listingRsp> listings) {
        this.listings = listings;
    }

    public List<String> getPhotoUrls() {
        return photoUrls;
    }

    public void setPhotoUrls(List<String> photoUrls) {
        this.photoUrls = photoUrls;
    }

    public List<bookingRsp> getBookings() {
        return bookings;
    }

    public void setBookings(List<bookingRsp> bookings) {
        this.bookings = bookings;
    }

    public List<feedbackRsp> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<feedbackRsp> feedbacks) {
        this.feedbacks = feedbacks;
    }

    public List<hostDoorSystemsRsp> getHostDoorSystems() {
        return hostDoorSystems;
    }

    public void setHostDoorSystems(List<hostDoorSystemsRsp> hostDoorSystems) {
        this.hostDoorSystems = hostDoorSystems;
    }
    
}
