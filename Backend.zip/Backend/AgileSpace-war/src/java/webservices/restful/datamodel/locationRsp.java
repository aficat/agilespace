/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful.datamodel;

import entity.Listing;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import util.enumeration.EntityStatusEnum;

/**
 *
 * @author vincentyeo
 */
@XmlRootElement
@XmlType(name = "locationRsp", propOrder = {
    "lId",
    "address",
    "postalCode",
    "longitude",
    "latitude",
    "entityStatusEnum",
    "listing"
})
public class locationRsp {

    private Long lId;
    private String address;
    private String postalCode;
    private Double longitude;
    private Double latitude;   
    private EntityStatusEnum entityStatusEnum;
    private listingRsp listing;
      
    public locationRsp() {
    }  

    public locationRsp(String address, String postalCode, Double longitude, Double latitude) {
        this.address = address;
        this.postalCode = postalCode;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public Long getlId() {
        return lId;
    }

    public void setlId(Long lId) {
        this.lId = lId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public EntityStatusEnum getEntityStatusEnum() {
        return entityStatusEnum;
    }

    public void setEntityStatusEnum(EntityStatusEnum entityStatusEnum) {
        this.entityStatusEnum = entityStatusEnum;
    }

    public listingRsp getListing() {
        return listing;
    }

    public void setListing(listingRsp listing) {
        this.listing = listing;
    }
    
    
}
