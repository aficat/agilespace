/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Booking;
import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import session.stateless.BookingSessionLocal;
import session.stateless.CustomerSessionLocal;
import session.stateless.FeedbackSessionLocal;
import session.stateless.HostDoorSystemSessionLocal;
import session.stateless.ListingSessionLocal;
import util.exception.AgileNoResultException;
import webservices.restful.datamodel.bookingRsp;
import webservices.restful.datamodel.customerRsp;
import webservices.restful.datamodel.feedbackRsp;
import webservices.restful.datamodel.hostDoorSystemsRsp;
import webservices.restful.datamodel.listingRsp;

/**
 * REST Web Service
 *
 * @author vincentyeo
 */
@Path("customers")
public class CustomersResource {

    @EJB
    private CustomerSessionLocal customerSessionLocal;

    @EJB
    private ListingSessionLocal listingSessionLocal;

    @EJB
    private BookingSessionLocal bookingSessionLocal;

    @EJB
    private FeedbackSessionLocal feedbackSessionLocal;

    @EJB
    private HostDoorSystemSessionLocal hostDoorSystemSessionLocal;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCustomer(Customer c) {
        try {
            System.out.println("Create Customer at CustomerResource");
            customerSessionLocal.retrieveCustomerByEmail(c.getEmail());

            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Email has already been used. Please use another one.")
                    .build();

            return Response.status(400).entity(exception).build();
            
        } catch (Exception e) {
            c.setEmail(c.getEmail().trim().toLowerCase());
            c.setPassword(c.getPassword().trim());

            Customer customer = customerSessionLocal.createCustomer(c);

            customerRsp cust = wrapCustomer(customer);

            return Response.status(Status.OK).entity(cust).build();
        }
    } //end createCustomer   

    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchCustomers(@QueryParam("all") String all,
            @QueryParam("email") String email,
            @QueryParam("firstName") String firstName,
            @QueryParam("lastName") String lastName,
            @QueryParam("phoneNum") String phoneNum,
            @QueryParam("rating") Integer rating) {
        
        if (all != null && all.equals("active")) {            
                List<Customer> results = customerSessionLocal.retrieveAllActiveCustomers();

                List<customerRsp> customers = wrapCustomers(results);

                GenericEntity<List<customerRsp>> entity = new GenericEntity<List<customerRsp>>(customers) {
                };

                return Response.status(Status.OK).entity(entity).build();
            
        }
        if (email != null) {
            //validate here
            try {
                Customer customer = customerSessionLocal.retrieveCustomerByEmail(email);

                if (customer == null) {
                    JsonObject exception = Json.createObjectBuilder()
                            .add("error", "Customer is not found.")
                            .build();

                    return Response.status(400).entity(exception).build();
                }
                  customerRsp cust = wrapCustomer(customer);

                return Response.status(Status.OK).entity(cust).build();

            } catch (AgileNoResultException ex) {
                JsonObject exception = Json.createObjectBuilder()
                        .add("error", "Customer is not found.")
                        .build();

                return Response.status(400).entity(exception).build();
            }
        }
        
        //Not working
        if(firstName != null || lastName != null || phoneNum != null)
        {
            //validate here
            
            Customer searchCustomer = new Customer();
            
            if(firstName != null)
            {
                searchCustomer.setFirstName(firstName);
            }
            
            if(lastName != null)
            {
                searchCustomer.setLastName(lastName);
            }            

            if(phoneNum != null)
            {
                searchCustomer.setPhoneNum(phoneNum);
            }
            
            List<Customer> results = customerSessionLocal.retrieveCustomerByAttributes(searchCustomer);
            
            if(results == null)
            {
                JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Customer is not found.")
                    .build();

                return Response.status(400).entity(exception).build();
            }
            
            List<customerRsp> customers = new ArrayList<>();
            results.forEach((customer)->{         
                customers.add(new customerRsp(customer.getId(), customer.getEmail(), customer.getPassword(), customer.getFirstName(), customer.getLastName(), customer.getPhoneNum(), customer.getRating(), customer.getEntityStatusEnum()));
            });
            GenericEntity<List<customerRsp>> entity = new GenericEntity<List<customerRsp>>(customers) {
            };

            return Response.status(200).entity(
                    entity
            ).build();             
        }
       
        JsonObject exception = Json.createObjectBuilder()
                .add("error", "No query conditions")
                .build();

        return Response.status(400).entity(exception).build();
        
    } //end searchCustomers

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchAllCustomers() {
        List<Customer> results = customerSessionLocal.retrieveAllCustomersForStaff();

        List<customerRsp> customers = wrapCustomers(results);

        GenericEntity<List<customerRsp>> entity = new GenericEntity<List<customerRsp>>(customers) {
        };

        return Response.status(Status.OK).entity(entity).build();
    }

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response customerLogin(Customer c) {
        if (!c.getEmail().isEmpty() && !c.getPassword().isEmpty()) {        
            try {
                //valid here
                Customer customer = customerSessionLocal.login(c.getEmail().toLowerCase(), c.getPassword());
                System.out.println("customer with " + customer.getId());
                customerRsp cust = wrapCustomer(customer);                

                return Response.status(Status.OK).entity(cust).build();
            } 
            catch (AgileNoResultException ex) 
            {
                JsonObject exception = Json.createObjectBuilder()
                        .add("error", "No Results Found")
                        .build();

                return Response.status(400).entity(exception).build();
            }            
            catch (Exception ex) 
            {
                JsonObject exception = Json.createObjectBuilder()
                        .add("error", ex.getMessage())
                        .build();

                return Response.status(400).entity(exception).build();
            }
        } else {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "No fields supplied")
                    .build();

            return Response.status(400).entity(exception).build();
        }

    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCustomerById(@PathParam("id") Long cId) {
        try {
            System.out.println("Get Customer at CustomerResource");
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);

            System.out.println("Customer c with id" + customer.getId() + " and email " + customer.getEmail());

            customerRsp cust = wrapCustomer(customer);

            return Response.status(Status.OK).entity(cust).build();

        } catch (AgileNoResultException e) {
            System.out.println("Error received " + e.getMessage());
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Customer Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
            
        } catch (Exception ex) {
            System.out.println("Error received " + ex.getMessage());
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", ex.getMessage())
                    .build();

            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getCustomer

    //Not working
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editCustomer(@PathParam("id") Long cId, Customer c) {
        c.setId(cId);

        if (!c.getEmail().isEmpty()) {
            c.setEmail(c.getEmail().trim().toLowerCase());
        }
        if (!c.getPassword().isEmpty()) {
            c.setPassword(c.getPassword().trim());
        }
        if (!c.getFirstName().isEmpty()) {
            c.setFirstName(c.getFirstName().trim().toLowerCase());
        }
        if (!c.getLastName().isEmpty()) {
            c.setLastName(c.getLastName().trim().toLowerCase());
        }

        try {
            customerSessionLocal.updateCustomer(c);
            return Response.status(Status.OK).build();
        } 
        catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Customer Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end editCustomer   

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteCustomer(@PathParam("id") Long cId) {
        try {
            //check for any assoicated item and do disassociation here or should it be done at session bean level?
            System.out.println("Delete Customer is triggered at customerResources");
            customerSessionLocal.deleteCustomer(cId);
            return Response.status(Status.OK).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Either Customer is not found or not disassociated with other objects first")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteCustomer    

    @POST
    @Path("/{customer_id}/url")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addPhotoUrl(@PathParam("customer_id") Long cId, String url) {
        try {
            customerSessionLocal.addPhotoUrlToCustomer(cId, url);
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            customerRsp cust = wrapCustomer(customer);
            
            return Response.status(200).entity(cust).build();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Photourl already existing")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addPhotoUrl   

    @POST
    @Path("/{customer_id}/listing")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addListing(@PathParam("customer_id") Long cId, Listing listing) {
        try {
            customerSessionLocal.addListingToCustomer(cId, listing);
            System.out.println("addedListing");
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
        System.out.println("customer: " + customer.toString());
            customerRsp cust = wrapCustomer(customer);
            return Response.status(200).entity(cust).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addListing   

    @POST
    @Path("/{customer_id}/booking")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addBooking(@PathParam("customer_id") Long cId, Booking booking) {
        try {
            customerSessionLocal.addBooking(cId, booking);
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            customerRsp cust = wrapCustomer(customer);
            return Response.status(200).entity(cust).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addBooking 

    @POST
    @Path("/{customer_id}/feedback")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addFeedback(@PathParam("customer_id") Long cId, Feedback feedback) {
        try {
            customerSessionLocal.addFeedback(cId, feedback);
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            customerRsp cust = wrapCustomer(customer);
            return Response.status(200).entity(cust).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addPhotoUrl   

    @POST
    @Path("/{customer_id}/hostDoorSystem")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addHostDoorSystem(@PathParam("customer_id") Long cId, HostDoorSystem hostDoorSystem) {
        try {
            customerSessionLocal.addHostDoorSystem(cId, hostDoorSystem);
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            customerRsp cust = wrapCustomer(customer);
            return Response.status(200).entity(cust).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addHostDoorSystem  

    @DELETE
    @Path("/{customer_id}/url")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePhotoUrl(@PathParam("customer_id") Long cId, String url) {
        try {
            System.out.println("deletePhotoUrl");
            System.out.println("url is " + url);
            customerSessionLocal.removePhotoUrlToCustomer(cId, url);
            System.out.println("removePhotoUrl is done");
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deletePhotoUrl   

    @DELETE
    @Path("/{customer_id}/listing/{listing_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteListing(@PathParam("customer_id") Long cId,
            @PathParam("listing_id") Long lId) {
        try {
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            customerSessionLocal.removeListing(cId, listing);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteListing 

    @DELETE
    @Path("/{customer_id}/booking/{booking_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteBooking(@PathParam("customer_id") Long cId,
            @PathParam("booking_id") Long bId) {
        try {
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            customerSessionLocal.removeBooking(cId, booking);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteVBooking

    @DELETE
    @Path("/{customer_id}/feedback/{feedback_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteFeedback(@PathParam("customer_id") Long cId,
            @PathParam("feedback_id") Long fId) {
        try {
            Feedback feedback = feedbackSessionLocal.retrieveFeedbackbyId(fId);
            customerSessionLocal.removeFeedback(cId, feedback);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteFeedback

    @DELETE
    @Path("/{customer_id}/hostDoorSystem/{hostDoorSystem_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteHostDoorSystem(@PathParam("customer_id") Long cId,
            @PathParam("hostDoorSystem_id") Long hId) {
        try {
            HostDoorSystem hostDoorSystem = hostDoorSystemSessionLocal.retrieveHostDoorSystemAccountById(hId);
            customerSessionLocal.removeHostDoorSystem(cId, hostDoorSystem);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Customer Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteHostDoorSystem   
    
    private List<customerRsp> wrapCustomers(List<Customer> results)
    {
        List<customerRsp> customers = new ArrayList<>();
        results.forEach((customer) -> {
              customerRsp cust = wrapCustomer(customer);
              customers.add(cust);
        });      

        return customers;
    }

    private customerRsp wrapCustomer(Customer customer)
    {

            List<listingRsp> lists = new ArrayList<listingRsp>();
            List<hostDoorSystemsRsp> hostDoorSystems = new ArrayList<hostDoorSystemsRsp>();
            List<bookingRsp> bookings = new ArrayList<>();
            List<feedbackRsp> feedbacks = new ArrayList<>();
           
            if(!customer.getListings().isEmpty())
            {
                customer.getListings().forEach((listing) -> {
                    lists.add(new listingRsp(listing.getId(), listing.getBuildingTypeEnum(), listing.getHeader(), listing.getDescription(), listing.getPrice(), listing.getUnitLevel(), listing.getUnitNumber(), listing.getEntityStatusEnum()));
                });
            }
            
            if(!customer.getHostDoorSystems().isEmpty())
            {
                customer.getHostDoorSystems().forEach((hostDoor) -> {
                    hostDoorSystems.add(new hostDoorSystemsRsp(hostDoor.getId(), hostDoor.getEmail(), hostDoor.getPassword(), hostDoor.getMasterQrCode(), hostDoor.getEntityStatusEnum()));
                });
            }
            
            if(!customer.getBookings().isEmpty())
            {            
                customer.getBookings().forEach((booking) -> {
                    bookings.add(new bookingRsp(booking.getId(), booking.getQrCode(), booking.getBookingStatusEnum(), booking.getEntityStatusEnum()));
                });
            }
            
            if(!customer.getFeedbacks().isEmpty())
            {
                customer.getFeedbacks().forEach((feedback) -> {
                    feedbacks.add(new feedbackRsp(feedback.getId(), feedback.getRating(), feedback.getFeedbackTypeEnum(), feedback.getEntityStatusEnum(), feedback.getRemarks(), feedback.getPostingDateTime()));
                });            
            }          
            
            customerRsp cust = new customerRsp(customer.getId(), customer.getEmail(), customer.getPassword(), customer.getFirstName(), customer.getLastName(), customer.getPhoneNum(), customer.getRating(), customer.getEntityStatusEnum());
             
            cust.setListings(lists);
            cust.setHostDoorSystems(hostDoorSystems);            
            cust.setPhotoUrls(customer.getPhotoUrls());
            cust.setBookings(bookings);
            cust.setFeedbacks(feedbacks);                       
            
        return cust;
    }
    

}
