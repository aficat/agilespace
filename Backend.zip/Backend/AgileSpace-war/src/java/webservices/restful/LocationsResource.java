/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Listing;
import entity.Location;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.ListingSessionLocal;
import session.stateless.LocationSessionLocal;
import util.enumeration.EntityStatusEnum;
import webservices.restful.datamodel.listingRsp;
import webservices.restful.datamodel.locationRsp;

/**
 * REST Web Service
 *
 * @author vincentyeo
 */
@Path("locations")
public class LocationsResource {
    @EJB
    private LocationSessionLocal locationSessionLocal;
    
    @EJB
    private ListingSessionLocal listingSessionLocal;    
    
    @POST
    @Path("/listing/{listing_id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createLocation(@PathParam("listing_id") Long lId, Location l) 
    {                      
        try {            
            Location location = locationSessionLocal.createLocation(l);
            
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            System.out.println("retrievedListing");          
            listingSessionLocal.assignLocation(lId, location);
            System.out.println("Location is assigned to listing");  
            location = locationSessionLocal.assignListing(lId, listing);
            System.out.println("Listing is assigned to location"); 
            
            locationRsp loc = wrapLocation(location);
            
            return Response.status(200).entity(loc).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end createLocation 
   
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllLocations() {
        try 
        {
            List<Location> results = locationSessionLocal.retrieveAllLocationForStaff();
            
            List<locationRsp> locations = wrapLocations(results);

            GenericEntity<List<locationRsp>> entity = new GenericEntity<List<locationRsp>>(locations) {
            };            
            
            return Response.status(200).entity(entity).type(MediaType.APPLICATION_JSON).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getAllLocations
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLocationById(@PathParam("id") Long lId) {
        try 
        {
            Location location = locationSessionLocal.retrieveLocationById(lId);
            locationRsp loc = wrapLocation(location);
                 
            return Response.status(200).entity(loc).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getLocationById
    
    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLocationByAttributes(@QueryParam("address") String address,
                                           @QueryParam("postalCode") String postalCode,
                                           @QueryParam("longtitude") Double longtitude,
                                           @QueryParam("latitude") Double langtitude,        
                                           @QueryParam("entityStatusEnum") EntityStatusEnum entityStatusEnum) 
    {                
        Location location = new Location(address, postalCode, longtitude, langtitude);
        location.setEntityStatusEnum(entityStatusEnum);
        
        try 
        {
            List<Location> results = locationSessionLocal.retrieveByAttributes(location);
            List<locationRsp> locations = wrapLocations(results);
            
            GenericEntity<List<locationRsp>> entity = new GenericEntity<List<locationRsp>>(locations) {
            };            
            
            return Response.status(200).entity(entity).type(MediaType.APPLICATION_JSON).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getLocationByAttributes  
    
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editLocation(@PathParam("id") Long lId, Location l) {
        l.setId(lId);
        
        try 
        {
            locationSessionLocal.updateLocation(l);
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end editLocation 
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteLocation(@PathParam("id") Long lId) {
        try 
        {
            //check for any assoicated item and do disassociation here or should it be done at session bean level?
            
            locationSessionLocal.deleteLocation(lId);
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteLocation
    
    @POST
    @Path("/{listing_id}/listing")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addListing(@PathParam("listing_id") Long lId, Listing listing) {
        try 
        {
            locationSessionLocal.assignListing(lId, listing);
            Location location = locationSessionLocal.retrieveLocationById(lId);
            locationRsp loc = wrapLocation(location);
            return Response.status(200).entity(loc).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addListing
      
    
    @DELETE
    @Path("/{location_id}/listing/{listing_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeListing(@PathParam("location_id") Long locId,
                                   @PathParam("listing_id") Long lId) 
    {
        try 
        {
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            locationSessionLocal.removeListing(lId, listing);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Location Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeListing 

    private List<locationRsp> wrapLocations(List<Location> results)
    {
        List<locationRsp> locations = new ArrayList<>();
        
        results.forEach((location)->{              
            locationRsp l = wrapLocation(location);
            locations.add(l);
        });
        
        return locations;
    }
    
    private locationRsp wrapLocation(Location location)
    {
        listingRsp listing = null;
        
        if(location.getListing() != null)
        {
            listing = new listingRsp(location.getListing().getId(),
                            location.getListing().getBuildingTypeEnum(),
                            location.getListing().getHeader(), 
                            location.getListing().getDescription(), 
                            location.getListing().getPrice(), 
                            location.getListing().getUnitLevel(), 
                            location.getListing().getUnitNumber(),
                            location.getListing().getEntityStatusEnum());
        }
        
        locationRsp loc = new locationRsp(location.getAddress(),location.getPostalCode(),location.getLongitude(), location.getLatitude());
        loc.setListing(listing);
        
        return loc;
    }
}
