/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.AgileSpaceTransaction;
import entity.Booking;
import entity.Customer;
import entity.Listing;
import entity.Slot;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.AgileSpaceTransactionSessionLocal;
import session.stateless.BookingSessionLocal;
import session.stateless.CustomerSessionLocal;
import util.enumeration.EntityStatusEnum;
import util.enumeration.TransactionTypeEnum;
import util.exception.AgileNoResultException;
import webservices.restful.datamodel.agileSpaceTransactionRsp;
import webservices.restful.datamodel.bookingRsp;
import webservices.restful.datamodel.customerRsp;


/**
 * REST Web Service
 *
 * @author aw chin siong
 */
@Path("transactions")
public class TransactionsResource {
    
    @EJB
    private AgileSpaceTransactionSessionLocal transactionSessionLocal;
    
    @EJB
    private CustomerSessionLocal customerSessionLocal; 
    
    @EJB
    private BookingSessionLocal bookingSessionLocal; 
            
    @POST
    @Path("/customer/{customerId}/booking/{bookingId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAgileSpaceTransaction(@PathParam("customerId") Long cId, @PathParam("bookingId") Long bId, AgileSpaceTransaction t ) {
     try{ 
        t.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currDate = new Date(); 
        System.out.println(currDate);
        t.setTransactionDate(currDate);
        
       Customer buyer = customerSessionLocal.retrieveCustomerById(cId);
       Booking booking = bookingSessionLocal.retrieveBookingById(bId); 
       Slot slot = booking.getSlots().get(0); 
       Listing listing = slot.getListing();
       Customer seller = listing.getListingOwner(); 
        //buyer 
       t.setCustomer(buyer);
       t.setBooking(booking);
       AgileSpaceTransaction buyerT = transactionSessionLocal.createTransaction(t);
       buyerT.setTransactionTypeEnum(TransactionTypeEnum.CREDIT);
       
         
       //seller 
       AgileSpaceTransaction sellerT = new AgileSpaceTransaction(currDate,buyerT.getTotalAmount(),TransactionTypeEnum.CREDIT,EntityStatusEnum.ACTIVATED);
       sellerT.setCustomer(seller);
       sellerT.setBooking(booking);
       sellerT = transactionSessionLocal.createTransaction(sellerT);
       
       
        agileSpaceTransactionRsp agileSpaceTransaction = wrapAgileSpaceTransaction(buyerT);
        return Response.status(200).entity(agileSpaceTransaction).build();
     }catch (AgileNoResultException e) {
            JsonObject exception = Json.createObjectBuilder().add("error", e.getMessage()).build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    } 
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTransactionById(@PathParam("id") Long tId) {
        try {
            AgileSpaceTransaction t = transactionSessionLocal.retrieveTransactionById(tId);
            agileSpaceTransactionRsp agileSpaceTransaction = wrapAgileSpaceTransaction(t);
        
            return Response.status(200).entity(agileSpaceTransaction).build();
        } catch (AgileNoResultException e) {
            JsonObject exception = Json.createObjectBuilder().add("error", "Not found").build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTransactions() {   
        List<AgileSpaceTransaction> results = transactionSessionLocal.retrieveAllTransactionForStaff();
        List<agileSpaceTransactionRsp> agileSpaceTransactions = wrapAgileSpaceTransactions(results);
        GenericEntity<List<agileSpaceTransactionRsp>> entity = new GenericEntity<List<agileSpaceTransactionRsp>>(agileSpaceTransactions) {
        };             
        return Response.status(200).entity(entity).build();
    } //end getAllTransaction
    
    @GET
    @Path("/query")
    public  Response retrieveTransactionByAttributes(
            @QueryParam("transactionDate") String date,
            @QueryParam("totalAmount") Double totalAmount,
            @QueryParam("transactionTypeEnum") String transactionType,
            @QueryParam("entityStatusEnum") String entityStatusEnum){
     try{  
        AgileSpaceTransaction transaction = new AgileSpaceTransaction(); 
       if(date!=null&&!date.trim().isEmpty()){
           SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
          try{ 
           Date newDate = formatter.parse(date);
           transaction.setTransactionDate(newDate);
          }catch(ParseException e){
              throw new IllegalArgumentException("Wrong date"); 
          }
       }
       if(totalAmount!=null){
           transaction.setTotalAmount(totalAmount);
       }
       if(transactionType !=null && !transactionType.trim().isEmpty()){
           TransactionTypeEnum type = TransactionTypeEnum.valueOf(transactionType.trim().toUpperCase());
           transaction.setTransactionTypeEnum(type);
       } 
       if(entityStatusEnum!=null&&!entityStatusEnum.trim().isEmpty()){
            EntityStatusEnum type = EntityStatusEnum.valueOf(entityStatusEnum.trim().toUpperCase());
            transaction.setEntityStatusEnum(type);
       } 
        List<AgileSpaceTransaction> transactions = transactionSessionLocal.retrieveByAttribute(transaction); 
        List<agileSpaceTransactionRsp> transactionRsp = wrapAgileSpaceTransactions(transactions);
        GenericEntity<List<agileSpaceTransactionRsp>> entity = new GenericEntity<List<agileSpaceTransactionRsp>>(transactionRsp) {};
        
        return Response.status(200).entity(entity).build();
       }catch (IllegalArgumentException e){
           JsonObject exception = Json.createObjectBuilder().add("error", "Transaction not found").build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
       }
    }
    
    
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editTransaction(@PathParam("id") Long tId, AgileSpaceTransaction t) {
        t.setId(tId);
        try {
            transactionSessionLocal.updateTransaction(t); 
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Not found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end edit Transaction
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTransaction(@PathParam("id") Long tId) {
        try {
            //System.out.println("delete");
            AgileSpaceTransaction transact = transactionSessionLocal.retrieveTransactionById(tId); 
            transact.setBooking(null);
            transact.setCustomer(null);
            transactionSessionLocal.deleteTransaction(tId);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteHostDoorSystem
    
    private List<agileSpaceTransactionRsp> wrapAgileSpaceTransactions(List<AgileSpaceTransaction> results)
    {
        List<agileSpaceTransactionRsp> agileSpaceTransactions = new ArrayList<>();
        results.forEach((trans) -> {
              agileSpaceTransactionRsp t = wrapAgileSpaceTransaction(trans);
              agileSpaceTransactions.add(t);
        });      

        return agileSpaceTransactions;        
    }     
    
    private agileSpaceTransactionRsp wrapAgileSpaceTransaction(AgileSpaceTransaction agileSpaceTransaction)
    {
        customerRsp customer = null;
        bookingRsp booking = null;
        //System.out.println(agileSpaceTransaction.getCustomer().getId());
        if(agileSpaceTransaction.getCustomer() != null){
            customer = new customerRsp(agileSpaceTransaction.getCustomer().getId(),
                                        agileSpaceTransaction.getCustomer().getEmail(),
                                        agileSpaceTransaction.getCustomer().getPassword(),
                                        agileSpaceTransaction.getCustomer().getFirstName(),
                                        agileSpaceTransaction.getCustomer().getLastName(),
                                        agileSpaceTransaction.getCustomer().getPhoneNum(),
                                        agileSpaceTransaction.getCustomer().getRating(),
                                        agileSpaceTransaction.getCustomer().getEntityStatusEnum()
            );
        }

        if(agileSpaceTransaction.getBooking() != null){
            booking = new bookingRsp(agileSpaceTransaction.getBooking().getId(),
                                    agileSpaceTransaction.getBooking().getQrCode(),
                                    agileSpaceTransaction.getBooking().getBookingStatusEnum(),
                                    agileSpaceTransaction.getBooking().getEntityStatusEnum());
        }        
        
        agileSpaceTransactionRsp aSTransaction = new agileSpaceTransactionRsp(agileSpaceTransaction.getId(), agileSpaceTransaction.getTransactionDate(), agileSpaceTransaction.getTotalAmount(), agileSpaceTransaction.getTransactionTypeEnum(), agileSpaceTransaction.getEntityStatusEnum());
        aSTransaction.setCustomer(customer);
        aSTransaction.setBooking(booking);
        return aSTransaction;
    }    
}
