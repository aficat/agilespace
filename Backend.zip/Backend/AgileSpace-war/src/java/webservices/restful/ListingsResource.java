/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Customer;
import entity.Feedback;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Location;
import entity.Slot;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import session.stateless.CustomerSessionLocal;
import session.stateless.FeedbackSessionLocal;
import session.stateless.HostDoorSystemSessionLocal;
import session.stateless.ListingSessionLocal;
import session.stateless.LocationSessionLocal;
import session.stateless.SlotSessionLocal;
import util.enumeration.AvaliabilityEnum;
import util.enumeration.BuildingTypeEnum;
import util.enumeration.EntityStatusEnum;
import webservices.restful.datamodel.customerRsp;
import webservices.restful.datamodel.feedbackRsp;
import webservices.restful.datamodel.hostDoorSystemsRsp;
import webservices.restful.datamodel.listingRsp;
import webservices.restful.datamodel.locationRsp;
import webservices.restful.datamodel.slotRsp;

/**
 * REST Web Service
 *
 * @author vincentyeo
 */
@Path("listings")
public class ListingsResource {
    
    @EJB
    private ListingSessionLocal listingSessionLocal;
    
    @EJB
    private FeedbackSessionLocal feedbackSessionLocal;
    
    @EJB
    private CustomerSessionLocal customerSessionLocal;
    
    @EJB
    private SlotSessionLocal slotSessionLocal;    
    
    @EJB
    private HostDoorSystemSessionLocal hostDoorSystemLocal; 
    
    @EJB
    private LocationSessionLocal locationSessionLocal;     

    @POST
    @Path("/customer/{customer_id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createListing(@PathParam("customer_id") Long cId, Listing l) {              
        
        try {            
            Listing listing = listingSessionLocal.createListing(l);
            System.out.println("listing is created");
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            System.out.println("customer is retrieved");         
            customerSessionLocal.addListingToCustomer(cId, listing);  
            System.out.println("listing is assigned to customer");   
            listing = listingSessionLocal.assignCustomer(listing.getId(), customer);
            System.out.println("customer is assigned");   
            listingRsp list = new listingRsp(listing.getId(), listing.getBuildingTypeEnum(),listing.getHeader(), listing.getDescription(), listing.getPrice(), listing.getUnitLevel(), listing.getUnitNumber(), listing.getEntityStatusEnum());
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            System.out.println("exception  " + e.getMessage());   
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end createListing 
   
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllListings() 
    {
        try 
        {
            List<Listing> results = listingSessionLocal.retrieveAllListingForStaff();
            
            List<listingRsp> listings = wrapListings(results);      
            
            GenericEntity<List<listingRsp>> entity = new GenericEntity<List<listingRsp>>(listings) {
            };
            
            return Response.status(Status.OK).entity(entity).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder().add("error", "Listing Not Found").build();

            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    } //end getAllListings 
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getListingById(@PathParam("id") Long lId) {
        try 
        {
            Listing listing = listingSessionLocal.retrieveListingById(lId);   
            
            listingRsp l = wrapListing(listing);
                                  
            return Response.status(Status.OK).entity(l).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getListingById
    
    @GET
    @Path("/query")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getListingByAttributes(@QueryParam("buildingType") BuildingTypeEnum buildingTypeEnum,
                                           @QueryParam("header") String header,
                                           @QueryParam("description") String description,
                                           @QueryParam("price") Double price,
                                           @QueryParam("unitLevel") String unitLevel,
                                           @QueryParam("unitNumber") String unitNumber,
                                           @QueryParam("entityStatusEnum") EntityStatusEnum entityStatusEnum) 
    {              
        Listing l = new Listing(buildingTypeEnum, header, description, null, null, null, null);
        
        try 
        {
            List<Listing> results = listingSessionLocal.retrieveListingByAttributes(l);
            
            List<listingRsp> listings = wrapListings(results);            
            
            GenericEntity<List<listingRsp>> entity = new GenericEntity<List<listingRsp>>(listings) {
            };
            
            return Response.status(Status.OK).entity(entity).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getListingByAttributes  
    
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editListing(@PathParam("id") Long lId, Listing l) {
        l.setId(lId);
        
        try 
        {
            listingSessionLocal.updateListing(l);
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end editListing  
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteListing(@PathParam("id") Long lId) {
        try 
        {
            //check for any assoicated item and do disassociation here or should it be done at session bean level?
            
            listingSessionLocal.deleteListing(lId);
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteListing 
    
    @POST
    @Path("/{listing_id}/customer")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addCustomer(@PathParam("listing_id") Long lId, Customer customer) {
        try 
        {
            listingSessionLocal.assignCustomer(lId, customer);
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            listingRsp list = wrapListing(listing);
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addCustomer
    
    @POST
    @Path("/{listing_id}/feedback")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addFeedback(@PathParam("listing_id") Long lId, Feedback feedback) {
        try 
        {
            listingSessionLocal.addFeedback(lId, feedback);
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            listingRsp list = wrapListing(listing);
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addSlot

   @POST
    @Path("/{listing_id}/slot")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addSlot(@PathParam("listing_id") Long lId, Slot slot) {
        try 
        {
            listingSessionLocal.addSlot(lId, slot);
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            listingRsp list = wrapListing(listing);
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addCustomer
    
    @POST
    @Path("/{listing_id}/hostDoorSystem")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addHostDoorSystem(@PathParam("listing_id") Long lId, HostDoorSystem hostDoorSystem) {
        try 
        {
            listingSessionLocal.assignHostDoorSystem(lId, hostDoorSystem);
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            listingRsp list = wrapListing(listing);
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addHostDoorSystem    
    
    @POST
    @Path("/{listing_id}/location")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addLocation(@PathParam("listing_id") Long lId, Location location) {
        try 
        {
            listingSessionLocal.assignLocation(lId, location);
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            listingRsp list = wrapListing(listing);
            
            return Response.status(Status.OK).entity(list).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addHostDoorSystem        
    
    @DELETE
    @Path("/{listing_id}/customer/{customer_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeCustomer(@PathParam("listing_id") Long lId,
                                   @PathParam("customer_id") Long cId) 
    {
        try 
        {
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            listingSessionLocal.removeCustomer(lId, customer);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeCustomer
    
    @DELETE
    @Path("/{listing_id}/feedback/{feedback_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeFeedback(@PathParam("listing_id") Long lId,
                                   @PathParam("feedback_id") Long fId) 
    {
        try 
        {
            Feedback feedback = feedbackSessionLocal.retrieveFeedbackbyId(fId);
            listingSessionLocal.removeFeedback(lId, feedback);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeFeedback      
    
    @DELETE
    @Path("/{listing_id}/slot/{slot_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeSlot(@PathParam("listing_id") Long lId,
                               @PathParam("slot_id") Long sId) 
    {
        try 
        {
            Slot slot = slotSessionLocal.retrieveSlotById(sId);
            listingSessionLocal.removeSlot(lId, slot);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeSlot      
    
    @DELETE
    @Path("/{listing_id}/hostDoorSystem/{hostDoorSystem_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeHostDoorSystem(@PathParam("listing_id") Long lId,
                                        @PathParam("hostDoorSystem_id") Long hId) 
    {
        try 
        {
            HostDoorSystem hostDoorSystem = hostDoorSystemLocal.retrieveHostDoorSystemAccountById(hId);
            listingSessionLocal.removeHostDoorSystem(lId, hostDoorSystem);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeHostDoorSystem       
    
    @DELETE
    @Path("/{listing_id}/location/{location_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeLocation(@PathParam("listing_id") Long lId,
                                   @PathParam("location_id") Long locId) 
    {
        try 
        {
            Location location = locationSessionLocal.retrieveLocationById(locId);
            listingSessionLocal.removeLocation(lId, location);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeLocation     
    
    private List<listingRsp> wrapListings(List<Listing> results)
    {
        List<listingRsp> listings = new ArrayList<>();
        
        results.forEach((listing)->{              
            listingRsp l = wrapListing(listing);
            listings.add(l);
        });
        
        return listings;
    }
    
    private listingRsp wrapListing(Listing listing)
    {
        customerRsp cust = null;
        hostDoorSystemsRsp hostDoor = null;
        locationRsp location = null;
        List<feedbackRsp> feedbacks = new ArrayList<>();
        List<slotRsp> slots = new ArrayList<>();
        
        if(listing.getListingOwner() != null)
        {                    
            cust = new customerRsp(listing.getListingOwner().getId(), 
                                                listing.getListingOwner().getEmail(), 
                                                listing.getListingOwner().getPassword(), 
                                                listing.getListingOwner().getFirstName(), 
                                                listing.getListingOwner().getLastName(), 
                                                listing.getListingOwner().getPhoneNum(), 
                                                listing.getListingOwner().getRating(), 
                                                listing.getListingOwner().getEntityStatusEnum());
        }
        
        if(listing.getHostDoorSystem() != null)
        {
            hostDoor = new hostDoorSystemsRsp(listing.getHostDoorSystem().getId(), listing.getHostDoorSystem().getEmail(), listing.getHostDoorSystem().getPassword(), listing.getHostDoorSystem().getMasterQrCode(), listing.getEntityStatusEnum());
        }

        if(listing.getLocation() != null)
        {
            location = new locationRsp(listing.getLocation().getAddress(), listing.getLocation().getPostalCode(), listing.getLocation().getLongitude(),listing.getLocation().getLatitude());
        } 
        
        if(!listing.getFeedbacks().isEmpty())
        {
            listing.getFeedbacks().forEach((feedback) -> {
                feedbacks.add(new feedbackRsp(feedback.getId(), feedback.getRating(), feedback.getFeedbackTypeEnum(), feedback.getEntityStatusEnum(), feedback.getRemarks(), feedback.getPostingDateTime()));
            });            
        }            

        if(listing.getAvaliableSlots() != null)
        {
           listing.getAvaliableSlots().forEach((slot) -> {
                slots.add(new slotRsp(slot.getId(), slot.getStartDate(), slot.getEndDate(), /*slot.getStartTime(), slot.getEndTime(),*/ slot.getAvaliabilityEnum(), slot.getEntityStatusEnum()));
            });             
        }        

        listingRsp list = new listingRsp(listing.getId(), listing.getBuildingTypeEnum(),listing.getHeader(), listing.getDescription(), listing.getPrice(), listing.getUnitLevel(), listing.getUnitNumber(), listing.getEntityStatusEnum());
        list.setPhotoUrls(listing.getPhotoUrls());
        list.setListingOwner(cust);
        list.setHostDoorSystem(hostDoor);
        list.setLocation(location);
        list.setFeedbacks(feedbacks);
        list.setAvaliableSlots(slots);
                
        return list;        
    }    
  
}
