/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Booking;
import entity.Listing;
import entity.Slot;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.BookingSessionLocal;
import session.stateless.ListingSessionLocal;
import session.stateless.SlotSessionLocal;
import util.enumeration.AvaliabilityEnum;
import util.enumeration.EntityStatusEnum;
import webservices.restful.datamodel.bookingRsp;
import webservices.restful.datamodel.listingRsp;
import webservices.restful.datamodel.slotRsp;

/**
 * REST Web Service
 *
 * @author vincentyeo
 */
@Path("slots")
public class SlotsResource {
    @EJB 
    private SlotSessionLocal slotSessionLocal;
    
    @EJB 
    private ListingSessionLocal listingSessionLocal;
    
    @EJB 
    private BookingSessionLocal bookingSessionLocal;
    
    @POST
    @Path("/listing/{listing_id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createSlot(Slot s, @PathParam("listing_id") Long lId) {
        //start date and end date must not be equal and start date must not be bigger than end date. 
        
        try {
           
            //check if input is in
            if(s==null){
                throw new Exception(" No Slot details");
            }
            
            // Check input start date < end date 
            if(s.getStartDate()!=null&&s.getEndDate()!=null){
                Date startDate = s.getStartDate(); 
                System.out.println("inputDate"+startDate);
                Date endDate = s.getEndDate(); 
                System.out.println("inputendDate"+endDate);
                //current Date 
                Date currDate = new Date(); 
                
                //start date should be before endDate 
                //start and end date be after currDate 
                if(startDate.before(currDate)||startDate.before(currDate)||(!startDate.before(endDate))){
                    throw new Exception("Invalid date input");
                }             
            }else{
                throw new Exception("Missing date");
            }
            Listing listing = listingSessionLocal.retrieveListingById(lId);

            //Check if slot exist 
            List<Slot> slots = listing.getAvaliableSlots(); 
            
            Date inputStart = removeTimeZone(s.getStartDate());

            Date inputEnd = removeTimeZone(s.getEndDate()); 
           
            for(Slot slot: slots ){

                // if they are in the same slot 
                if(slot.getStartDate().equals(inputStart)&&slot.getEndDate().equals(inputEnd)){
                    throw new Exception("slot taken");  
                }
                //if taken slot is bigger than intended slot 
                else if(slot.getStartDate().before(inputStart)&&slot.getEndDate().after(inputEnd)){
                    throw new Exception("slot taken"); 
                }
                //taken slot is smaller than intended slot
                else if(slot.getStartDate().after(inputStart)&&slot.getEndDate().before(inputEnd)){
                    throw new Exception("slot taken");
                    
                }//taken slot overlap intended slot at the back
                else if(slot.getStartDate().before(inputEnd)&&slot.getEndDate().after(inputEnd)){
                    throw new Exception("slot taken");
                    
                }//taken slot overlap intended slot at the front
                else if(slot.getStartDate().before(inputStart)&&slot.getEndDate().after(inputStart)){
                    throw new Exception("slot taken");
                    
                }// ensure that the start date for both taken slot and intended slot is the same but intended slot is longer
                else if(slot.getStartDate().equals(inputStart)&&slot.getEndDate().before(inputEnd)){
                    throw new Exception("slot taken");
                }// ensure that the end date for both taken slot and intended slot is the same but intended slot is earlier
                if(slot.getStartDate().after(inputStart)&&slot.getEndDate().equals(inputEnd)){
                    throw new Exception("slot taken");
                }
                
            }
            
            s.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
            
            s= slotSessionLocal.createSlot(s);
            listingSessionLocal.addSlot(lId, s);
            
            s = slotSessionLocal.assignListing(s.getId(), listing);
            
            slotRsp slot = wrapSlot(s);
            
           
            return Response.status(200).entity(slot).build();
           //return Response.status(200).build();
           
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end createSlot  
    
    @GET
    @Path("/{slot_id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSlotById(@PathParam("slot_id") Long sId) {
                             
        try 
        {

            Slot s = slotSessionLocal.retrieveSlotById(sId);
            slotRsp slot = wrapSlot(s);

            return Response.status(200).entity(slot).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end getSlotById
    
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllSlots() {
                             
        try 
        {
            List<Slot> results = slotSessionLocal.retrieveAllSlotForStaff();
            
            List<slotRsp> slots = wrapSlots(results);

            GenericEntity<List<slotRsp>> entity = new GenericEntity<List<slotRsp>>(slots) {
            };            
            
            return Response.status(200).entity(entity).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end getAllSlots
    
    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSlotByAttributes(@QueryParam("startDate") Date startDate,
                                        @QueryParam("endDate") Date endDate,            
                                        //@QueryParam("startTime") Date startTime,
                                        //@QueryParam("endTime") Date endTime,
                                        @QueryParam("avaliabilityEnum") AvaliabilityEnum avaliabilityEnum,
                                        @QueryParam("entityStatusEnum") EntityStatusEnum entityStatusEnum)                                    
    {
        if (startDate != null || endDate != null || /*startTime != null || endTime != null ||*/ avaliabilityEnum != null || entityStatusEnum != null) 
        {
            Slot slot =  new Slot(startDate, endDate, /*startTime, endTime,*/ avaliabilityEnum);
            
            List<Slot> results = slotSessionLocal.retrieveSlotByAttributes(slot);  
            
            List<slotRsp> slots = wrapSlots(results);

            GenericEntity<List<slotRsp>> entity = new GenericEntity<List<slotRsp>>(slots) {
            };            
            
            return Response.status(200).entity(entity).build();         
        }        
        else {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "No query conditions")
                    .build();

            return Response.status(400).entity(exception).build();
        }
    } //end getSlotByAttributes  
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editSlot(@PathParam("id") Long sId, Slot s) {
        s.setId(sId);
        try 
        {
             if(s==null){
                throw new Exception(" No Slot details");
            }
            
            // Check input start date < end date 
            if(s.getStartDate()!=null&&s.getEndDate()!=null){
                Date startDate = s.getStartDate(); 
                System.out.println("inputDate"+startDate);
                Date endDate = s.getEndDate(); 
                System.out.println("inputendDate"+endDate);
                //current Date 
                Date currDate = new Date(); 
                
                //start date should be before endDate 
                //start and end date be after currDate 
                if(startDate.before(currDate)||startDate.before(currDate)||(!startDate.before(endDate))){
                    throw new Exception("Invalid date input");
                }             
            }else{
                throw new Exception("Missing date");
            }
            Slot currentSlot = slotSessionLocal.retrieveSlotById(sId);
            Listing listing = currentSlot.getListing(); 
            if(listing==null){
                throw new Exception("No listing found");
            }         
                        //Check if slot exist 
            List<Slot> slots = listing.getAvaliableSlots(); 
            
            Date inputStart = removeTimeZone(s.getStartDate());

            Date inputEnd = removeTimeZone(s.getEndDate()); 
           
            for(Slot slot: slots ){

                // if they are in the same slot 
                if(slot.getStartDate().equals(inputStart)&&slot.getEndDate().equals(inputEnd)){
                    throw new Exception("slot taken");  
                }
                //if taken slot is bigger than intended slot 
                else if(slot.getStartDate().before(inputStart)&&slot.getEndDate().after(inputEnd)){
                    throw new Exception("slot taken"); 
                }
                //taken slot is smaller than intended slot
                else if(slot.getStartDate().after(inputStart)&&slot.getEndDate().before(inputEnd)){
                    throw new Exception("slot taken");
                    
                }//taken slot overlap intended slot at the back
                else if(slot.getStartDate().before(inputEnd)&&slot.getEndDate().after(inputEnd)){
                    throw new Exception("slot taken");
                    
                }//taken slot overlap intended slot at the front
                else if(slot.getStartDate().before(inputStart)&&slot.getEndDate().after(inputStart)){
                    throw new Exception("slot taken");
                    
                }// ensure that the start date for both taken slot and intended slot is the same but intended slot is longer
                else if(slot.getStartDate().equals(inputStart)&&slot.getEndDate().before(inputEnd)){
                    throw new Exception("slot taken");
                }// ensure that the end date for both taken slot and intended slot is the same but intended slot is earlier
                if(slot.getStartDate().after(inputStart)&&slot.getEndDate().equals(inputEnd)){
                    throw new Exception("slot taken");
                }
                
            }
            
            s.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
            
            s = slotSessionLocal.updateSlot(s);
            
            s = slotSessionLocal.retrieveSlotById(sId);
                       
            slotRsp slot = wrapSlot(s);

            return Response.status(200).entity(slot).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end editSlot  
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteSlot(@PathParam("id") Long sId) {
        try 
        {
            //check for any assoicated item and do disassociation here or should it be done at session bean level?
            Slot slot = slotSessionLocal.retrieveSlotById(sId); 
            Booking booking = slot.getBooking(); 
            Listing listing = slot.getListing(); 
            if(booking!=null){
                if(!booking.getSlots().isEmpty()){
                    if(booking.getSlots().contains(slot)){
                        bookingSessionLocal.removeSlot(booking.getId(), slot); 
                    }
                }
                slotSessionLocal.removeBooking(sId, booking); 
            }
            if(listing!=null){
                if(!listing.getAvaliableSlots().isEmpty()){
                    if(listing.getAvaliableSlots().contains(slot)){
                        listingSessionLocal.removeSlot(listing.getId(), slot); 
                    }
                }
                slotSessionLocal.removeListing(listing.getId(), listing); 
            }
            
            slotSessionLocal.deleteSlot(sId);
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteSlot 
    
    @POST
    @Path("/{slot_id}/listing")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addListing(@PathParam("slot_id") Long sId, Listing listing) {
        
        try {                       
            slotSessionLocal.assignListing(sId, listing);
            
            Slot s = slotSessionLocal.retrieveSlotById(sId);
            slotRsp slot = wrapSlot(s);

            return Response.status(200).entity(slot).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addListing     
    
    @POST
    @Path("/{slot_id}/booking")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addBooking(@PathParam("slot_id") Long sId, Booking booking) {
        
        try {                       
            slotSessionLocal.assignBooking(sId, booking);
            
            Slot s = slotSessionLocal.retrieveSlotById(sId);
            slotRsp slot = wrapSlot(s);

            return Response.status(200).entity(slot).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addBooking

    @DELETE
    @Path("/{slot_id}/listing/{listing_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeListing(@PathParam("slot_id") Long sId,
                                   @PathParam("listing_id") Long lId) 
    {
        try 
        {
            Listing listing = listingSessionLocal.retrieveListingById(lId);
            slotSessionLocal.removeListing(sId, listing);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeListing     

    @DELETE
    @Path("/{slot_id}/booking/{booking_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeBooking(@PathParam("slot_id") Long sId,
                                   @PathParam("booking_id") Long bId) 
    {
        try 
        {
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            slotSessionLocal.removeBooking(sId, booking);
        
            return Response.status(204).build();
        } 
        catch (Exception e) 
        {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end removeBooking 
    
    private List<slotRsp> wrapSlots(List<Slot> results)
    {
        List<slotRsp> slots= new ArrayList<>();
        results.forEach((slot) -> {
              slotRsp s = wrapSlot(slot);
              slots.add(s);
        });      

        return slots;
    }
    private Date removeTimeZone(Date newDate){
        Calendar cal = Calendar.getInstance();
        cal.setTime(newDate);
        TimeZone currTime = cal.getTimeZone(); 
        int milliseconds = currTime.getRawOffset(); 
        int hour = (int) ((milliseconds / (1000*60*60)) % 24);
        cal.add(Calendar.HOUR_OF_DAY, hour*-1);
        Date convertDate = cal.getTime(); 
        return convertDate; 
        
    }


    private slotRsp wrapSlot(Slot slot)
    {      
        listingRsp listing = null;
        bookingRsp booking = null;
            
        if(slot.getListing() != null)
        { 
            listing = new listingRsp(slot.getListing().getId(),
                                            slot.getListing().getBuildingTypeEnum(),
                                            slot.getListing().getHeader(),
                                            slot.getListing().getDescription(),
                                            slot.getListing().getPrice(),
                                            slot.getListing().getUnitLevel(),
                                            slot.getListing().getUnitNumber(),
                                            slot.getListing().getEntityStatusEnum()
                                        );
        }       
        
        if(slot.getBooking() != null)
        { 
            booking = new bookingRsp(slot.getBooking().getId(),
                                            slot.getBooking().getQrCode(),
                                            slot.getBooking().getBookingStatusEnum(),
                                            slot.getBooking().getEntityStatusEnum());
        } 
        
        slotRsp s = new slotRsp(slot.getId(), slot.getStartDate(), slot.getEndDate(), /*slot.getStartTime(), slot.getEndTime(),*/ slot.getAvaliabilityEnum(), slot.getEntityStatusEnum());
        s.setListing(listing);
        s.setBooking(booking);
        
        return s;
    }      
    
    
    
}
