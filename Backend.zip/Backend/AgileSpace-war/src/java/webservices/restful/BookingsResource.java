/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.AgileSpaceTransaction;
import entity.Booking;
import entity.Customer;
import entity.HostDoorSystem;
import entity.Listing;
import entity.Slot;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.AgileSpaceTransactionSession;
import session.stateless.AgileSpaceTransactionSessionLocal;
import session.stateless.BookingSessionLocal;
import session.stateless.CustomerSessionLocal;
import session.stateless.HostDoorSystemSessionLocal;
import session.stateless.SlotSessionLocal;
import util.enumeration.BookingStatusEnum;
import util.exception.AgileNoResultException;
import webservices.restful.datamodel.bookingRsp;
import webservices.restful.datamodel.customerRsp;
import webservices.restful.datamodel.slotRsp;

/**
 * REST Web Service
 *
 * @author vincentyeo
 */
@Path("bookings")
public class BookingsResource {

    @EJB
    private BookingSessionLocal bookingSessionLocal;
    
    @EJB
    private HostDoorSystemSessionLocal hostDoorSessionLocal;    

    @EJB
    private CustomerSessionLocal customerSessionLocal;

    @EJB
    private SlotSessionLocal slotSessionLocal;
    
    @EJB
    private AgileSpaceTransactionSessionLocal agileSpaceTransactionSessionLocal; 

    @POST
    @Path("/customer/{customer_id}/slot/{slot_id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createBooking(Booking b, @PathParam("customer_id") Long cId, @PathParam("slot_id") Long sId) {

        //generate QR Code here (To create a qr Code generator)          
        try {
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);

            Slot slot = slotSessionLocal.retrieveSlotById(sId);

            if (slot.getBooking() != null) {
                JsonObject exception = Json.createObjectBuilder()
                        .add("error", "Slot has already been booked. Please try another slot")
                        .build();

                return Response.status(404).entity(exception).build();
            }

            String qrCode = generateQRCodeString(slot);           
            b.setQrCode(qrCode.replaceAll("\\s+",""));
            //setbooking enum
            b.setBookingStatusEnum(BookingStatusEnum.CHECKED_IN);

            Booking booking = bookingSessionLocal.createBooking(b);

            //customer add booking 
            customer = customerSessionLocal.addBooking(cId, booking);
            //assign Customer to booking 
            booking = bookingSessionLocal.assignCustomer(booking.getId(), customer);
            System.out.println(booking.getGuest().getId());
            //assign booking to slot  
            slot = slotSessionLocal.assignBooking(sId, booking);
            //add slot to booking 
            booking = bookingSessionLocal.addSlot(booking.getId(), slot);

            bookingRsp book = wrapBooking(booking);
            return Response.status(200).entity(book).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end createBooking 

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBookingById(@PathParam("id") Long bId) {
        try {
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            bookingRsp book = wrapBooking(booking);
            return Response.status(200).entity(book).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end getBookingById  

    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBookingByQrCode(@QueryParam("qrCode") String qrCode) {
        try {
            Booking booking = bookingSessionLocal.retrieveBookingByQrCode(qrCode);
            bookingRsp book = wrapBooking(booking);
            return Response.status(200).entity(book).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getBookingByQrCode  

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBookings() {
        try {
            List<Booking> results = bookingSessionLocal.retrieveAllBookingForStaff();
            List<bookingRsp> bookings = wrapBookings(results);

            GenericEntity<List<bookingRsp>> entity = new GenericEntity<List<bookingRsp>>(bookings) {
            };

            return Response.status(200).entity(entity).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking Not Found")
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end getAllBookings

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editBooking(@PathParam("id") Long bId, Booking b) {
        b.setId(bId);

        if (!b.getQrCode().isEmpty()) {
            b.setQrCode(b.getQrCode().trim());
        }

        try {
            bookingSessionLocal.updateBookingAttributes(b);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end editBooking    

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteBooking(@PathParam("id") Long bId) {
        try {
            //check for any assoicated item and do disassociation here or should it be done at session bean level?
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            System.out.println("booking"+booking.toString());
            Customer customer = booking.getGuest();
            System.out.println("booking"+booking.toString());
            List<Slot> slots = booking.getSlots();
            //remove slot 
            if (slots != null && !slots.isEmpty()){
                for (Slot slot : slots) {
                   if(slot.getBooking()!=null){ 
                    slot = slotSessionLocal.removeBooking(slot.getId(), booking);
                    booking = bookingSessionLocal.removeSlot(bId, slot);
                   }
                }
            }
            //remove Custsomer from booking 
            if(customer!=null){
               if(customer.getBookings()!=null){
                    customer = customerSessionLocal.removeBooking(customer.getId(), booking); 
               }
                booking = bookingSessionLocal.removeCustomer(bId, booking.getGuest());
            }
            //if transactions is tied to the booking it will not be removed  
            List<AgileSpaceTransaction> agileSpaceTransactions = agileSpaceTransactionSessionLocal.retrieveAllTransactionForStaff(); 
            for(AgileSpaceTransaction transaction: agileSpaceTransactions){
                if(transaction.getBooking()!=null){
                    Booking checkBooking = transaction.getBooking(); 
                    if(checkBooking.getId().equals(bId)){
                        throw new Exception("Recorded in system, unable to delete ");
                    }
                }
            }
            bookingSessionLocal.deleteBooking(bId);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteBooking  

    @POST
    @Path("/{booking_id}/slot")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addSlot(@PathParam("booking_id") Long bId, Slot slot) {
        try {
            Slot newSlot = slotSessionLocal.createSlot(slot);
            bookingSessionLocal.addSlot(bId, newSlot);
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            newSlot = slotSessionLocal.assignBooking(newSlot.getId(), booking);
            bookingRsp book = wrapBooking(booking);
            return Response.status(200).entity(book).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking not found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end addSlot

//should call slotResource instead
//    @GET
//    @Path("/slot")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public Response getBookingBySlot(Slot slot) {
//        try 
//        {
//            List<Booking> bookings = bookingSessionLocal.retrieveBookingsBySlotAttributes(slot);            
//            List<bookingRsp> bookings = wrapBookings(results);
//            
//            GenericEntity<List<bookingRsp>> entity = new GenericEntity<List<bookingRsp>>(bookings) {
//            };
//                
//            return Response.status(200).entity(entity).build();
//        } 
//        catch (Exception e) 
//        {
//            JsonObject exception = Json.createObjectBuilder()
//                    .add("error", "Booking Not Found")
//                    .build();
//
//            return Response.status(404).entity(exception).build();
//        }
//    } //end addSlot
    @DELETE
    @Path("/{booking_id}/slot/{slot_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeSlot(@PathParam("booking_id") Long bId,
            @PathParam("slot_id") Long sId) {
        try {
            Slot slot = slotSessionLocal.retrieveSlotById(sId);
            Booking booking = bookingSessionLocal.retrieveBookingById(bId);
            bookingSessionLocal.removeSlot(bId, slot);
            slotSessionLocal.removeBooking(sId, booking);

            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Booking Not Found")
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end deleteBooking  
    
    @POST
    @Path("/qrCode/hostDoorSystem/{hostDoorSystem_id}/{qrCode}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response scanQRCode(@PathParam("hostDoorSystem_id") Long hId, @PathParam("qrCode") String qrCode)
    {
        System.out.println("QRCODE is " + qrCode);
        HostDoorSystem h;        
        try 
        {
            h = hostDoorSessionLocal.retrieveHostDoorSystemAccountById(hId);
            Listing listing = bookingSessionLocal.getListingByQrCode(h.getListing().getId(), qrCode);
            //compare bookingListing and HostDoorListing id()
            Boolean isCorrect = (h.getListing().getId().equals(listing.getId()));       
            
            if(isCorrect)
            {
                JsonObject response = Json.createObjectBuilder()
                    .add("toggleNum", 1)
                    .build();
                
                return Response.status(200).entity(response).build();
            }
            else
            {
                JsonObject response = Json.createObjectBuilder()
                    .add("toggleNum", 0)
                    .build();
                
                return Response.status(200).entity(response).build();               
            }
        } 
        catch (AgileNoResultException ex) 
        {
             JsonObject exception = Json.createObjectBuilder()
                    .add("error", "HostDoorSystem Not Found")
                    .build();

//             return 0;
            return Response.status(404).entity(exception).build();
        }
        catch (Exception ex) {
             JsonObject exception = Json.createObjectBuilder()
                    .add("error", "Listing Not Found")
                    .build();

//             return 0;
            return Response.status(404).entity(exception).build();
        }
//        return 0;
    }

    private String generateQRCodeString(Slot slot) {
        System.out.print("before generate ");
        //String qrCode = slot.getListing().getLocation().getAddress() + slot.getId().toString() + slot.getStartDate().toString() + slot.getStartTime().toString() + slot.getEndDate().toString() + slot.getEndTime().toString();
        String qrCode = "qr"; 
        if(slot.getStartDate()!=null){
           qrCode=  qrCode.concat(slot.getStartDate().toString()).trim(); 
        }
        qrCode = qrCode.concat(randomGenerator(5)).trim(); 
        /*
        if(slot.getStartTime()!=null){
            qrCode = qrCode.concat(slot.getStartTime().toString());
        }*/
        qrCode = qrCode.concat(randomGenerator(5)).trim(); 
        
        if(slot.getEndDate()!=null){
            qrCode = qrCode.concat(slot.getEndDate().toString()).trim(); 
        }
        qrCode = qrCode.concat(randomGenerator(5)).trim(); 
        /*
        if(slot.getEndTime()!=null){
            qrCode = qrCode.concat(slot.getEndTime().toString()); 
        }*/
        qrCode = qrCode.concat(randomGenerator(5)).trim(); 
        
        
        System.out.print("after generate ");
        return qrCode.trim();
    }

    private List<bookingRsp> wrapBookings(List<Booking> results) {
        List<bookingRsp> bookings = new ArrayList<>();

        results.forEach((booking) -> {
            bookingRsp book = wrapBooking(booking);
            bookings.add(book);
        });

        return bookings;
    }

    private bookingRsp wrapBooking(Booking booking) {
        customerRsp customer = null;
        List<slotRsp> slots = new ArrayList<slotRsp>();

        if (booking.getGuest() != null) {
            customer = new customerRsp(booking.getGuest().getId(),
                    booking.getGuest().getEmail(),
                    booking.getGuest().getPassword(),
                    booking.getGuest().getFirstName(),
                    booking.getGuest().getLastName(),
                    booking.getGuest().getPhoneNum(),
                    booking.getGuest().getRating(),
                    booking.getGuest().getEntityStatusEnum());
        }

        if (!booking.getSlots().isEmpty()) {
            booking.getSlots().forEach((slot) -> {
                slots.add(new slotRsp(slot.getId(), slot.getStartDate(), slot.getEndDate(),/* slot.getStartTime(), slot.getEndTime(),*/ slot.getAvaliabilityEnum(), slot.getEntityStatusEnum()));
            });
        }

        bookingRsp book = new bookingRsp(booking.getId(), booking.getQrCode(), booking.getBookingStatusEnum(), booking.getEntityStatusEnum());
        book.setGuest(customer);
        book.setSlots(slots);

        return book;

    }
        private String randomGenerator(int number) {
        String ALPHA_NUMERIC_STRING = "abcdefghijklmnopqrsntuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~!@#$%^&*(){}";
        StringBuilder word = new StringBuilder();
        for (int i = 0; i < number; i++) {            
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            word.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return word.toString();
    }
}
