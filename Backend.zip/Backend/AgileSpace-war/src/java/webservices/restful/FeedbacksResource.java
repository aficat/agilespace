/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices.restful;

import entity.Customer;
import entity.Feedback;
import entity.Listing;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import session.stateless.CustomerSessionLocal;
import session.stateless.FeedbackSessionLocal;
import session.stateless.ListingSessionLocal;
import util.enumeration.EntityStatusEnum;
import util.enumeration.FeedbackTypeEnum;
import util.exception.AgileNoResultException;
import webservices.restful.datamodel.customerRsp;
import webservices.restful.datamodel.feedbackRsp;
import webservices.restful.datamodel.listingRsp;

/**
 * REST Web Service
 *
 * @author aw chin siong
 */
@Path("feedbacks")
public class FeedbacksResource {

    @EJB
    private FeedbackSessionLocal feedbackSessionLocal;
    @EJB
    private CustomerSessionLocal customerSessionLocal;
    @EJB
    private ListingSessionLocal listingSessionLocal;

    @POST
    @Path("/customer/{customerId}/listing/{listingsId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createFeedback(@PathParam("customerId") Long cId, @PathParam("listingsId") Long lId, Feedback f) {
         
       try{ 
           f.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
           Feedback newFeedback = feedbackSessionLocal.createFeedback(f);
           Customer cust = customerSessionLocal.retrieveCustomerById(cId); 
           Listing list = listingSessionLocal.retrieveListingById(lId); 
           
           newFeedback = feedbackSessionLocal.assignFeedbacker(f.getId(), cust);
           newFeedback =feedbackSessionLocal.assignListing(f.getId(), list);
        
            customerSessionLocal.addFeedback(cId, newFeedback);
            listingSessionLocal.addFeedback(lId, newFeedback); 
           
         feedbackRsp feedback = wrapFeedback(newFeedback);
         return Response.status(200).entity(feedback).build();
       }catch(Exception e) {
            JsonObject exception = Json.createObjectBuilder().add("error", e.getMessage()).build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    } //end createFeedback

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getFeedbackById(@PathParam("id") Long fId) {
        try {
            Feedback f = feedbackSessionLocal.retrieveFeedbackbyId(fId);
            
            feedbackRsp feedback = wrapFeedback(f);
            return Response.status(200).entity(feedback).build();
        } catch (AgileNoResultException e) {
            JsonObject exception = Json.createObjectBuilder().add("error", e.getMessage()).build();
            return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllFeedback() {
        List<Feedback> results = feedbackSessionLocal.retrieveAllFeedbackForStaff();
        List<feedbackRsp> feedbacks = wrapFeedbacks(results);
        
        GenericEntity<List<feedbackRsp>> entity = new GenericEntity<List<feedbackRsp>>(feedbacks) {
        };
        
        return Response.status(200).entity(entity).build();
    } //end getAllFeedback

    @GET
    @Path("/query")
    @Produces(MediaType.APPLICATION_JSON)
    public Response retrieveFeedbackByAttributes(@QueryParam("feedbackType") String feedbackType,
                                                    @QueryParam("rating") Integer rating,
                                                    @QueryParam("remarks") String remarks,
                                                    @QueryParam("entityStatusEnum") String entityStatus) 
    {
        if (!feedbackType.isEmpty()) {
            try {
                FeedbackTypeEnum type = FeedbackTypeEnum.valueOf(feedbackType.trim().toUpperCase());
                Feedback feedback = new Feedback();
                feedback.setFeedbackTypeEnum(type);
                List<Feedback> results = feedbackSessionLocal.retrieveFeedbackByAttributes(feedback);
                List<feedbackRsp> feedbacks = wrapFeedbacks(results);
        
                GenericEntity<List<feedbackRsp>> entity = new GenericEntity<List<feedbackRsp>>(feedbacks) {
                };
                
                return Response.status(200).entity(entity).build();
                
            } catch (IllegalArgumentException e) {
                JsonObject exception = Json.createObjectBuilder().add("error", "Feedback not found").build();
                return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
            }
        } else if (!remarks.isEmpty()) {
            try {
                Feedback feedback = new Feedback();
                feedback.setRemarks(remarks);
                List<Feedback> results = feedbackSessionLocal.retrieveFeedbackByAttributes(feedback);
                List<feedbackRsp> feedbacks = wrapFeedbacks(results);
        
                GenericEntity<List<feedbackRsp>> entity = new GenericEntity<List<feedbackRsp>>(feedbacks) {
                };
                
                return Response.status(200).entity(entity).build();
            } catch (IllegalArgumentException e) {
                JsonObject exception = Json.createObjectBuilder().add("error", "Feedback not found").build();
                return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
            }
        } else if (!entityStatus.isEmpty()) {
            try {
                EntityStatusEnum type = EntityStatusEnum.valueOf(entityStatus.trim().toUpperCase());
                Feedback feedback = new Feedback();
                feedback.setEntityStatusEnum(type);
                List<Feedback> results = feedbackSessionLocal.retrieveFeedbackByAttributes(feedback);
                List<feedbackRsp> feedbacks = wrapFeedbacks(results);
        
                GenericEntity<List<feedbackRsp>> entity = new GenericEntity<List<feedbackRsp>>(feedbacks) {
                };
                
                return Response.status(200).entity(entity).build();
            } catch (IllegalArgumentException e) {
                JsonObject exception = Json.createObjectBuilder().add("error", "Feedback not found").build();
                return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
            }
        } else if (rating!=null) {
            try {
                Feedback feedback = new Feedback();
                feedback.setRating(rating);
                List<Feedback> results = feedbackSessionLocal.retrieveFeedbackByAttributes(feedback);
                List<feedbackRsp> feedbacks = wrapFeedbacks(results);
        
                GenericEntity<List<feedbackRsp>> entity = new GenericEntity<List<feedbackRsp>>(feedbacks) {
                };
                
                return Response.status(200).entity(entity).build();
            } catch (IllegalArgumentException e) {
                JsonObject exception = Json.createObjectBuilder().add("error", "Feedback not found").build();
                return Response.status(404).entity(exception).type(MediaType.APPLICATION_JSON).build();
            }
        } else {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", "No query conditions")
                    .build();
            return Response.status(400).entity(exception).build();
        }
    }


    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editFeedback(@PathParam("id") Long fId, Feedback f) {
        f.setId(fId);
        try {
            feedbackSessionLocal.updateFeedback(f);
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    } //end edit Feedback
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteFeedback(@PathParam("id") Long fId) {
        try {
            Feedback feedback = feedbackSessionLocal.retrieveFeedbackbyId(fId); 
            Customer feedbacker = feedback.getFeedbacker(); 
            Listing listing = feedback.getListing(); 
            
            if(feedbacker!=null){
                if(feedbacker.getFeedbacks().contains(feedback)){
                    customerSessionLocal.removeFeedback(feedbacker.getId(), feedback); 
                }
                feedbackSessionLocal.removeCustomer(fId, feedbacker);
            }
           if(listing!=null){
               if(listing.getFeedbacks().contains(feedback)){
                   listingSessionLocal.removeFeedback(listing.getId(), feedback);
               }
               feedbackSessionLocal.removeListing(fId, listing);
           }      
           feedbackSessionLocal.deleteFeedback(fId);
 
            return Response.status(204).build();
        } catch (Exception e) {
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();

            return Response.status(404).entity(exception).build();
        }
    } //end delete Feedback
    
    @POST
    @Path("/{feedback_id}/customer")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response assignCustomer(@PathParam("feedback_id") Long fId, Customer c){
        try {
             //add Customer to feedback 
             Feedback f = feedbackSessionLocal.retrieveFeedbackbyId(fId); 
            System.out.println("after create feedback");
            //Create Customer 
            c.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
            System.out.println("after set entity");
            c.setRating(0);
           try{
              Customer newCustomer =  customerSessionLocal.retrieveCustomerByEmail(c.getEmail());
                  throw new Exception("Email has been used"); 
           }catch(AgileNoResultException e){
               Customer newCustomer = customerSessionLocal.createCustomer(c); 
           
                f = feedbackSessionLocal.assignFeedbacker(fId,newCustomer);
            
                //add feedback to Customer
                customerSessionLocal.addFeedback(newCustomer.getId(), f);
            
                feedbackRsp feedback = wrapFeedback(f);
                return Response.status(200).entity(feedback).build();
           } 
             
         } catch (Exception e) {
             JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                     .build();
 
             return Response.status(404).entity(exception)
                     .type(MediaType.APPLICATION_JSON).build();
         }
    } //end assignCustomerToFeedback 
    
   
    @POST
    @Path("/{feedback_id}/listing")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response assignListing(@PathParam("feedback_id") Long fId, Listing l){
        try {
            //add listing  to feedback 
            Feedback f = feedbackSessionLocal.retrieveFeedbackbyId(fId);
            l.setEntityStatusEnum(EntityStatusEnum.ACTIVATED);
            Listing newListing = listingSessionLocal.createListing(l); 
            f = feedbackSessionLocal.assignListing(fId,newListing);
             //add feedback to listing
            newListing = listingSessionLocal.addFeedback(newListing.getId(), f);
             feedbackRsp feedback = wrapFeedback(f);
             return Response.status(200).entity(feedback).build();
         } catch (Exception e) {
             JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                     .build();
 
             return Response.status(404).entity(exception).build();
        }
    } //end assignListingToFeedback 
    
    @DELETE
    @Path("/{feedback_id}/customer/{customer_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeCustomer(@PathParam("feedback_id") Long fId,
            @PathParam("customer_id") Long cId){
        try{
            //Remove Customer from hostDoorSystem 
            Customer customer = customerSessionLocal.retrieveCustomerById(cId);
            feedbackSessionLocal.removeCustomer(fId,customer);
            
            //Remove hostDoorSystem 
            Feedback feedback = feedbackSessionLocal.retrieveFeedbackbyId(fId); 
            customerSessionLocal.removeFeedback(cId, feedback); 
            
            return Response.status(204).build();
        }catch(Exception e){
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();
            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
    }
    
    @DELETE
    @Path("/{feedback_id}/listing/{listing_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeListing(@PathParam("feedback_id") Long fId,
            @PathParam("listing_id") Long lId){
        try{  
            //Retrieve feedback and listing 
            Feedback feedback = feedbackSessionLocal.retrieveFeedbackbyId(fId);
            Listing listing = listingSessionLocal.retrieveListingById(lId); 
           
            //Remove listing from feedback  
            feedbackSessionLocal.removeListing(fId, feedback.getListing());
            //Remove feedback from listing 
            listingSessionLocal.removeFeedback(lId, feedback); 
            
            //if listing do not contain other feedback delete listing
            if(listing.getFeedbacks().isEmpty()){
                listingSessionLocal.deleteListing(listing.getId());
            }
            return Response.status(204).build();
        }catch(Exception e){
            JsonObject exception = Json.createObjectBuilder()
                    .add("error", e.getMessage())
                    .build();
            return Response.status(404).entity(exception)
                    .type(MediaType.APPLICATION_JSON).build();
        }
        
    }

    private List<feedbackRsp> wrapFeedbacks(List<Feedback> results)
    {    
       List<feedbackRsp> feedbacks = new ArrayList<>();
        results.forEach((feedback) -> {
            feedbackRsp f = wrapFeedback(feedback);
            feedbacks.add(f);      
        });
        
        return feedbacks;
                
    }
    
    private feedbackRsp wrapFeedback(Feedback feedback)
    {    
        customerRsp customer = null;
        listingRsp listing = null;
        
        if(feedback.getFeedbacker() != null)
        {
            customer = new customerRsp(feedback.getFeedbacker().getId(),
                    feedback.getFeedbacker().getEmail(),
                    feedback.getFeedbacker().getPassword(),
                    feedback.getFeedbacker().getFirstName(),
                    feedback.getFeedbacker().getLastName(),
                    feedback.getFeedbacker().getPhoneNum(),
                    feedback.getFeedbacker().getRating(),
                    feedback.getFeedbacker().getEntityStatusEnum()
            );
        }
        
        if(feedback.getListing() != null)
        {
            listing = new listingRsp(feedback.getListing().getId(),
                                    feedback.getListing().getBuildingTypeEnum(),
                                    feedback.getListing().getHeader(),
                                    feedback.getListing().getDescription(),
                                    feedback.getListing().getPrice(),
                                    feedback.getListing().getUnitLevel(),
                                    feedback.getListing().getUnitNumber(),
                                    feedback.getListing().getEntityStatusEnum()
            );
        }
        
        feedbackRsp feedb = new feedbackRsp(feedback.getId(), feedback.getRating(), feedback.getFeedbackTypeEnum(), feedback.getEntityStatusEnum(), feedback.getRemarks(), feedback.getPostingDateTime());
        feedb.setFeedbacker(customer);
        feedb.setListing(listing);
        
        return feedb;
    }
}

